// Empty test because all libboost-spirit libraries are disabled by default.
//

// One day we can handle this by exporting metadata about which components
// are enabled (like we do in libevent). Currently this is tested indirectly
// by other libraries that depend on spirit.

int
main ()
{
  return 0;
}
