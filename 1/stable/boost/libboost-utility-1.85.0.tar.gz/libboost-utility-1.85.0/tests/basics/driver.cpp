#include <boost/utility.hpp>

int
main ()
{
  return 0;
}
