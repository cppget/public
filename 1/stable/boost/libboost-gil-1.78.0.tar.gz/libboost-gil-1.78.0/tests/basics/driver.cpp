#include <boost/gil.hpp>

int
main ()
{
  return 0;
}
