#include <boost/multiprecision/complex_adaptor.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_complex.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/debug_adaptor.hpp>
#include <boost/multiprecision/eigen.hpp>
#include <boost/multiprecision/integer.hpp>
#include <boost/multiprecision/logged_adaptor.hpp>
#include <boost/multiprecision/miller_rabin.hpp>
#include <boost/multiprecision/number.hpp>
#include <boost/multiprecision/rational_adaptor.hpp>

int
main ()
{
  return 0;
}
