#include <boost/mysql.hpp>

int
main ()
{
  return 0;
}
