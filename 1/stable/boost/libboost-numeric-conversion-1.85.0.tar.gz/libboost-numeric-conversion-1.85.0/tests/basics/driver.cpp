#include <boost/cast.hpp>
#include <boost/numeric/conversion/bounds.hpp>
#include <boost/numeric/conversion/cast.hpp>
#include <boost/numeric/conversion/conversion_traits.hpp>
#include <boost/numeric/conversion/converter.hpp>
#include <boost/numeric/conversion/converter_policies.hpp>
#include <boost/numeric/conversion/int_float_mixture_enum.hpp>
#include <boost/numeric/conversion/int_float_mixture.hpp>
#include <boost/numeric/conversion/is_subranged.hpp>
#include <boost/numeric/conversion/numeric_cast_traits.hpp>
#include <boost/numeric/conversion/sign_mixture_enum.hpp>
#include <boost/numeric/conversion/sign_mixture.hpp>
#include <boost/numeric/conversion/udt_builtin_mixture_enum.hpp>
#include <boost/numeric/conversion/udt_builtin_mixture.hpp>

int
main ()
{
  return 0;
}
