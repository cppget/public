#include <boost/signals2.hpp>

int
main ()
{
  return 0;
}
