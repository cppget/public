#include <boost/multi_index/composite_key.hpp>
#include <boost/multi_index_container_fwd.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/global_fun.hpp>
#include <boost/multi_index/hashed_index_fwd.hpp>
#include <boost/multi_index/hashed_index.hpp>
#include <boost/multi_index/identity_fwd.hpp>
#include <boost/multi_index/identity.hpp>
#include <boost/multi_index/indexed_by.hpp>
#include <boost/multi_index/key_extractors.hpp>
#include <boost/multi_index/key.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/mem_fun.hpp>
#include <boost/multi_index/ordered_index_fwd.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/random_access_index_fwd.hpp>
#include <boost/multi_index/random_access_index.hpp>
#include <boost/multi_index/ranked_index_fwd.hpp>
#include <boost/multi_index/ranked_index.hpp>
#include <boost/multi_index/safe_mode_errors.hpp>
#include <boost/multi_index/sequenced_index_fwd.hpp>
#include <boost/multi_index/sequenced_index.hpp>
#include <boost/multi_index/tag.hpp>

int
main ()
{
  return 0;
}
