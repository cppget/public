#define BOOST_TEST_MODULE dummy_test_module

#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE (dummy_test_case) {}
