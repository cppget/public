#include <boost/geometry/geometry.hpp>

int
main ()
{
  return 0;
}
