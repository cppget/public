# libboost-process

The `build2` package of `libboost-process` provides the following libraries:

- `lib{boost_process}`: Boost.Process V2
- `lib{boost_process_v1}`: Boost.Process V1

Note: Boost.Process V1 is scheduled to be deprecated in Boost version 1.88.0
and new projects are advised to use Boost.Process V2.
