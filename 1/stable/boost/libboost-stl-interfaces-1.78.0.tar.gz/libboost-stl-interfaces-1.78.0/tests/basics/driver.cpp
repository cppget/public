#include <boost/stl_interfaces/config.hpp>
#include <boost/stl_interfaces/fwd.hpp>
#include <boost/stl_interfaces/iterator_interface.hpp>
#include <boost/stl_interfaces/reverse_iterator.hpp>
#include <boost/stl_interfaces/sequence_container_interface.hpp>
#include <boost/stl_interfaces/view_interface.hpp>

int
main ()
{
  return 0;
}
