#include <boost/redis.hpp>
#include <boost/redis/src.hpp>

int
main ()
{
  return 0;
}
