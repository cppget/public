# Maintainer

This library is currently maintained by [Richard Hodges](mailto:hodges.r@gmail.com) with generous support 
from the C++ Alliance.

# Build Status

Branch  | Status
--------|-------
develop | [![CI](https://github.com/boostorg/property_tree/actions/workflows/ci.yml/badge.svg?branch=develop)](https://github.com/boostorg/property_tree/actions/workflows/ci.yml)
master  | [![CI](https://github.com/boostorg/property_tree/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/boostorg/property_tree/actions/workflows/ci.yml)

# Licence

This software is distributed under the [Boost Software License, Version 1.0](http://www.boost.org/LICENSE_1_0.txt).

# Original Work

This library is the work of Marcin Kalicinski and Sebastian Redl<br/> 

Copyright (C) 2002-2006 Marcin Kalicinski<br/>
Copyright (C) 2009 Sebastian Redl
