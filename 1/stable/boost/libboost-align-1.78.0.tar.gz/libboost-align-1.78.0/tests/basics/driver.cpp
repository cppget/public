#include <boost/align.hpp>

int
main ()
{
  return 0;
}
