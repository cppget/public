#include <boost/parameter.hpp>

int
main ()
{
  return 0;
}
