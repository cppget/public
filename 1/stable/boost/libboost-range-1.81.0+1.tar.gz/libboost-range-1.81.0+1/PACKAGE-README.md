# libboost-range

The `build2` package of `libboost-range` supports the following
configuration variables:


### `config.libboost_range.regex`

Enable regex support. Default is `false`. Note that enabling this support will
cause the package to depend on `libboost-regex`.
