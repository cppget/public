#include <boost/callable_traits.hpp>

int
main ()
{
  return 0;
}
