#include <boost/tuple/tuple.hpp>

int
main ()
{
  return 0;
}
