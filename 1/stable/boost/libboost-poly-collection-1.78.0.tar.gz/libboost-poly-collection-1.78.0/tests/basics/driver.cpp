#include <boost/poly_collection/algorithm.hpp>
#include <boost/poly_collection/any_collection_fwd.hpp>
#include <boost/poly_collection/any_collection.hpp>
#include <boost/poly_collection/base_collection_fwd.hpp>
#include <boost/poly_collection/base_collection.hpp>
#include <boost/poly_collection/exception.hpp>
#include <boost/poly_collection/function_collection_fwd.hpp>
#include <boost/poly_collection/function_collection.hpp>

int
main ()
{
  return 0;
}
