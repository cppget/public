//
// Copyright (c) 2025 Dmitry Arkhipov (grisumbras@yandex.ru)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Official repository: https://github.com/boostorg/json
//


#include <boost/json/visit.hpp>

namespace boost {
namespace json {
namespace detail {

BOOST_JSON_CONSTINIT
std::nullptr_t stable_np;

} // namespace detail
} // namespace json
} // namespace boost
