// This header allows upstream sources to include Catch2
// with `#include "catch.hpp"`. Internally it forwards to
// Catch2's official inclusion scheme:
//
#include <catch2/catch.hpp>
