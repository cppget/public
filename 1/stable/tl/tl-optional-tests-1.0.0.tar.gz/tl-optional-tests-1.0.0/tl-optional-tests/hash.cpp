#include <catch2/catch.hpp>
#include <tl/optional.hpp>

TEST_CASE("Hashing", "[hash]") {}
