#ifndef OT_LAYOUT_GSUB_CONTEXTSUBST_HH
#define OT_LAYOUT_GSUB_CONTEXTSUBST_HH

// TODO(garretrieger): move to new layout.
#include "../../../hb-ot-layout-gsubgpos.hh"
#include "Common.hh"

namespace OT {
namespace Layout {
namespace GSUB {

struct ContextSubst : Context {};

}
}
}

#endif  /* OT_LAYOUT_GSUB_CONTEXTSUBST_HH */
