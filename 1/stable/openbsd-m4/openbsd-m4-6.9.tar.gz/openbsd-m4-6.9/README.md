# openbsd-m4

OpenBSD `m4` is an implementation of the POSIX `m4` general-purpose macro
processor that supports many GNU `m4` extensions.

Note also that the `openbsd-m4` executable provides `build2` metadata.
