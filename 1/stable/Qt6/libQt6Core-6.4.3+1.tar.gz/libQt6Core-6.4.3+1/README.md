# libQt6Core

This package contains the Qt6 core library.
