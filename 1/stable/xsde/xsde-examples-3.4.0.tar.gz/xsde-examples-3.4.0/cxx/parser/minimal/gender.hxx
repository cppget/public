// file      : cxx/parser/minimal/gender.hxx
// copyright : not copyrighted - public domain

#ifndef GENDER_HXX
#define GENDER_HXX

enum gender
{
  male,
  female
};

#endif // GENDER_HXX
