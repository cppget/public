#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <assert.h>

#include <vulkan/vulkan.h>
#include <vulkan/vulkan.hpp>

int main()
{
   return 0;
}
