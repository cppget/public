#define STB_TEXTEDIT_CHARTYPE char
#include <stb_textedit.h>

int main() {}
