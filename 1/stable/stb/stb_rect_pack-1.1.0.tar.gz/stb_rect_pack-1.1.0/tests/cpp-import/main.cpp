#define STB_RECT_PACK_IMPLEMENTATION
#include <stb_rect_pack.h>

int main() {}
