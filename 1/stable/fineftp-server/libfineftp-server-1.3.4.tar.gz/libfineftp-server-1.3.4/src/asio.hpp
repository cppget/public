#pragma once
#include <boost/asio.hpp>

namespace asio
{
  using namespace boost::asio;
  using error_code = boost::system::error_code;
}
