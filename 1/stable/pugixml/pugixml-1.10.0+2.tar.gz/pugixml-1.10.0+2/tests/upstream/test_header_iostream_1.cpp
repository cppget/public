// Tests compatibility with iostream
#include "../src/pugixml.hpp"
#include <iostream>
