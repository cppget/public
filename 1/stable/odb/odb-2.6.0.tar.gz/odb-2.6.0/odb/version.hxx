// file      : odb/version.hxx.in
// license   : GNU GPL v3; see accompanying LICENSE file

#ifndef ODB_COMPILER_VERSION // Note: using the version macro itself.

// New numeric version format is AAAAABBBBBCCCCCDDDE where:
//
// AAAAA - major version number
// BBBBB - minor version number
// CCCCC - bugfix version number
// DDD   - alpha / beta (DDD + 500) version number
// E     - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAAAABBBBBCCCCC. For example:
//
// Version      AAAAABBBBBCCCCCDDDE
//
// 0.1.0        0000000001000000000
// 0.1.2        0000000001000020000
// 1.2.3        0000100002000030000
// 2.2.0-a.1    0000200001999990010
// 3.0.0-b.2    0000299999999995020
// 2.2.0-a.1.z  0000200001999990011
//
#define ODB_COMPILER_VERSION       200006000000000ULL
#define ODB_COMPILER_VERSION_STR   "2.6.0"
#define ODB_COMPILER_VERSION_ID    "2.6.0"
#define ODB_COMPILER_VERSION_FULL  "2.6.0"

#define ODB_COMPILER_SNAPSHOT      0ULL

// Old/deprecated numeric version format is AABBCCDD where:
//
// AA - major version number
// BB - minor version number
// CC - bugfix version number
// DD - alpha / beta (DD + 50) version number
//
// When DD is not 00, 1 is subtracted from AABBCC. For example:
//
// Version     AABBCCDD
// 2.0.0       02000000
// 2.1.0       02010000
// 2.1.1       02010100
// 2.2.0.a1    02019901
// 3.0.0.b2    02999952
//
#define ODB_COMPILER_VERSION_OLD 2060000

// ODB interface version: minor, major, and alpha/beta versions.
//
#define ODB_VERSION 20600

#endif // ODB_COMPILER_VERSION
