// file      : evolution/combined/driver.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

// Combined schema evolution test.
//

#include <memory>   // std::unique_ptr
#include <iostream>

#include <odb/database.hxx>
#include <odb/transaction.hxx>
#include <odb/schema-catalog.hxx>

#include <libcommon/common.hxx>

#include "test2.hxx"
#include "test3.hxx"
#include "test2-odb.hxx"
#include "test3-odb.hxx"

#undef NDEBUG
#include <cassert>

using namespace std;
using namespace odb::core;

int
main (int argc, char* argv[])
{
  try
  {
    unique_ptr<database> db (create_database (argc, argv, false));

    db->schema_version_table (quote_name ("evo_comb_sv"));

    bool embedded (schema_catalog::exists (*db));

    // 1 - base version
    // 2 - migration
    // 3 - current version
    //
    unsigned short pass (*argv[argc - 1] - '0');

    switch (pass)
    {
    case 1:
      {
        using namespace v2;

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::drop_schema (*db);
          schema_catalog::create_schema (*db, "", false);
          schema_catalog::migrate_schema (*db, 2);
          t.commit ();
        }

        object o ("1");
        o.dui = 1;
        o.anui = 1;
        o.dnui = 1;
        o.dc = 1;
        o.dt.push_back (1);
        o.aui = 1;

#ifndef DATABASE_SQLITE
        o.dfk = new object1 (1);
        o.afk = 1;
#endif

#if !defined(DATABASE_SQLITE) || DATABASE_SQLITE_VERSION >= 3053000
        o.acn = 1;
        o.acnn.reset ();
#endif

        {
          transaction t (db->begin ());
#ifndef DATABASE_SQLITE
          db->persist (o.dfk);
#endif
          db->persist (o);
          t.commit ();
        }
        break;
      }
    case 2:
      {
        using namespace v3;

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::migrate_schema_pre (*db, 3);
          t.commit ();
        }

        {
          transaction t (db->begin ());
          unique_ptr<object> p (db->load<object> ("1"));

          assert (p->ac1 == 999);
          assert (!p->ac2);

#if !defined(DATABASE_SQLITE) || DATABASE_SQLITE_VERSION >= 3053000
          assert (!p->ac3);
#endif
          // Migrate.
          //
          p->at.push_back ("abc");

#ifndef DATABASE_SQLITE
          p->dfk = 999;
#endif

#if !defined(DATABASE_SQLITE) || DATABASE_SQLITE_VERSION >= 3053000
          p->ac3 = 1;
          p->acn.reset ();
          p->acnn = 1;
#endif
          db->update (*p);

          t.commit ();
        }

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::migrate_schema_post (*db, 3);
          t.commit ();
        }
        break;
      }
    case 3:
      {
        using namespace v3;

        {
          transaction t (db->begin ());
          unique_ptr<object> p (db->load<object> ("1"));

          // Check post-migration.
          //
          assert (p->at[0] == "abc");

#ifndef DATABASE_SQLITE
          assert (p->dfk == 999);
#endif

#if !defined(DATABASE_SQLITE) || DATABASE_SQLITE_VERSION >= 3053000
          assert (*p->ac3 == 1);
          assert (!p->acn);
          assert (*p->acnn == 1);
#endif
          t.commit ();
        }
        break;
      }
    default:
      {
        cerr << "unknown pass number '" << argv[argc - 1] << "'" << endl;
        return 1;
      }
    }
  }
  catch (const odb::exception& e)
  {
    cerr << e.what () << endl;
    return 1;
  }
}
