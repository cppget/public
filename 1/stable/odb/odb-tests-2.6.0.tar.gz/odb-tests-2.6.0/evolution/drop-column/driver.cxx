// file      : evolution/drop-column/driver.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

// Test dropping a column.
//

#include <memory>   // std::unique_ptr
#include <iostream>

#include <odb/database.hxx>
#include <odb/transaction.hxx>
#include <odb/schema-catalog.hxx>

#include <libcommon/common.hxx>

#include "test2.hxx"
#include "test3.hxx"
#include "test2-odb.hxx"
#include "test3-odb.hxx"

#undef NDEBUG
#include <cassert>

using namespace std;
using namespace odb::core;

int
main (int argc, char* argv[])
{
  try
  {
    unique_ptr<database> db (create_database (argc, argv, false));

    db->schema_version_table (quote_name ("evo_drop_c_sv"));

    bool embedded (schema_catalog::exists (*db));

    // 1 - base version
    // 2 - migration
    // 3 - current version
    //
    unsigned short pass (*argv[argc - 1] - '0');

    switch (pass)
    {
    case 1:
      {
        using namespace v2;

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::drop_schema (*db);
          schema_catalog::create_schema (*db, "", false);
          schema_catalog::migrate_schema (*db, 2);
          t.commit ();
        }

        object o (1);
        o.str = "abc";
        o.num = 123;
        o.ptr1 = new object1 (1);
        o.ptr2 = new object2 (1, 2);

        {
          transaction t (db->begin ());
          db->persist (*o.ptr1);
          db->persist (*o.ptr2);
          db->persist (o);
          t.commit ();
        }
        break;
      }
    case 2:
      {
        using namespace v3;

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::migrate_schema_pre (*db, 3);
          t.commit ();
        }

        // Things are still there.
        //
        {
          transaction t (db->begin ());
          unique_ptr<object> p (db->load<object> (1));

          assert (p->str == "abc");
          assert (p->num == 123);
          assert (p->ptr1->id == 1);
          assert (p->ptr2->id.x == 1 && p->ptr2->id.y == 2);

          t.commit ();
        }

        if (embedded)
        {
          transaction t (db->begin ());
          schema_catalog::migrate_schema_post (*db, 3);
          t.commit ();
        }
        break;
      }
    case 3:
      {
        using namespace v3;

        // Now they are gone.
        //
        {
          transaction t (db->begin ());
          unique_ptr<object> p (db->load<object> (1));
          assert (p->str == "" && p->ptr1 == nullptr && p->ptr2 == nullptr);
          db->erase<object1> (1);            // SQLite logical delete test.
          db->erase<object2> (value (1, 2)); // SQLite logical delete test.
          t.commit ();
        }
        break;
      }
    default:
      {
        cerr << "unknown pass number '" << argv[argc - 1] << "'" << endl;
        return 1;
      }
    }
  }
  catch (const odb::exception& e)
  {
    cerr << e.what () << endl;
    return 1;
  }
}
