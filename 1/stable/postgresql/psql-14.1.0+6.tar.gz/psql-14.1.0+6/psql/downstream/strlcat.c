/* file      : psql/downstream/strlcat.c -*- C -*-
 * license   : PostgreSQL License; see accompanying COPYRIGHT file
 */
#if !HAVE_DECL_STRLCAT
# include <src/port/strlcat.c>
#endif
