#pragma once

// The numeric version format is AAAAABBBBBCCCCCDDDE where:
//
// AAAAA - major version number
// BBBBB - minor version number
// CCCCC - bugfix version number
// DDD   - alpha / beta (DDD + 500) version number
// E     - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAAAABBBBBCCCCC. For example:
//
// Version      AAAAABBBBBCCCCCDDDE
//
// 0.1.0        0000000001000000000
// 0.1.2        0000000001000020000
// 1.2.3        0000100002000030000
// 2.2.0-a.1    0000200001999990010
// 3.0.0-b.2    0000299999999995020
// 2.2.0-a.1.z  0000200001999990011
//
#define LIBPDJSON5_VERSION       100000000010000ULL
#define LIBPDJSON5_VERSION_STR   "1.0.1"
#define LIBPDJSON5_VERSION_ID    "1.0.1"
#define LIBPDJSON5_VERSION_FULL  "1.0.1"

#define LIBPDJSON5_VERSION_MAJOR 1
#define LIBPDJSON5_VERSION_MINOR 0
#define LIBPDJSON5_VERSION_PATCH 1

#define LIBPDJSON5_PRE_RELEASE   false

#define LIBPDJSON5_SNAPSHOT_SN   0ULL
#define LIBPDJSON5_SNAPSHOT_ID   ""
