# libQt5WidgetsTests

Tests for package libQt5Widgets.
