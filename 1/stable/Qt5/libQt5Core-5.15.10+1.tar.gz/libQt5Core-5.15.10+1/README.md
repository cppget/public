# libQt5Core

This package contains the Qt5 core library.
