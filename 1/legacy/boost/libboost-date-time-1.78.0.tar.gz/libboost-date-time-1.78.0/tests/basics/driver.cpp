#include <boost/date_time.hpp>

int
main ()
{
  return 0;
}
