#include <boost/smart_ptr.hpp>

int
main ()
{
  return 0;
}
