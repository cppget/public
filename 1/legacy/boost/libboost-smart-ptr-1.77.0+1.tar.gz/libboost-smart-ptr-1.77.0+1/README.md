# Boost.SmartPtr

Branch   | Travis | Appveyor
---------|--------|---------
Develop  | [![Build Status](https://travis-ci.org/boostorg/smart_ptr.svg?branch=develop)](https://travis-ci.org/boostorg/smart_ptr) | [![Build Status](https://ci.appveyor.com/api/projects/status/github/boostorg/smart_ptr?branch=develop&svg=true)](https://ci.appveyor.com/project/pdimov/smart-ptr)
Master   | [![Build Status](https://travis-ci.org/boostorg/smart_ptr.svg?branch=master)](https://travis-ci.org/boostorg/smart_ptr) | [![Build Status](https://ci.appveyor.com/api/projects/status/github/boostorg/smart_ptr?branch=master&svg=true)](https://ci.appveyor.com/project/pdimov/smart-ptr)
