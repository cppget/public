#include <boost/concept_check.hpp>

int
main ()
{
  return 0;
}
