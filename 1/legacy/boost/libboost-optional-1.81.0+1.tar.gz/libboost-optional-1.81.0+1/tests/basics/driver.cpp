#include <boost/optional/optional.hpp>

int
main ()
{
  return 0;
}
