#include <boost/histogram.hpp>

int
main ()
{
  return 0;
}
