#include <boost/endian.hpp>

int
main ()
{
  return 0;
}
