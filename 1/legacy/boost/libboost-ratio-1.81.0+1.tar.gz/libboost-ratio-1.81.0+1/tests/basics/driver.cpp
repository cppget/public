#include <boost/ratio.hpp>

int
main ()
{
  return 0;
}
