# Boost.Bind

Branch   | Travis | Appveyor
---------|--------|---------
Develop  | [![Build Status](https://travis-ci.org/boostorg/bind.svg?branch=develop)](https://travis-ci.org/boostorg/bind) | [![Build Status](https://ci.appveyor.com/api/projects/status/github/boostorg/bind?branch=develop&svg=true)](https://ci.appveyor.com/project/pdimov/bind)
Master   | [![Build Status](https://travis-ci.org/boostorg/bind.svg?branch=master)](https://travis-ci.org/boostorg/bind) | [![Build Status](https://ci.appveyor.com/api/projects/status/github/boostorg/bind?branch=master&svg=true)](https://ci.appveyor.com/project/pdimov/bind)
