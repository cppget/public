# pXart: <br> Packed Extensions for <br> Advanced Random Techniques
**C++ Header-Only Library and Applications for Fast Random Number Generators**

![](https://img.shields.io/github/languages/top/lyrahgames/pxart.svg?style=for-the-badge)
![](https://img.shields.io/github/license/lyrahgames/pxart.svg?style=for-the-badge&color=blue)
[![Website lyrahgames.github.io/pxart](https://img.shields.io/website/https/lyrahgames.github.io/pxart.svg?down_message=offline&label=Documentation&style=for-the-badge&up_color=blue&up_message=online)](https://lyrahgames.github.io/pxart)