#include <string>
#include <vector>

#include <zug/into.hpp>
#include <zug/transducer/map.hpp>
#include <zug/transducer/filter.hpp>

#undef NDEBUG
#include <cassert>

int main ()
{
  using namespace std;

  // Smoke test.
  //
  // Filter positives, then convert to string.
  //
  auto xf (zug::filter ([] (int x) { return x > 0; }) |
           zug::map    ([] (int x) { return to_string (x); }));

  vector i ({3, -2, 42, -10});
  assert (zug::into (vector<string> (), xf, i) == vector ({ "3"s, "42"s }));
}
