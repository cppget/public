# libzug - Transducers for C++

This is a `build2` package for the [`zug`](https://github.com/arximboldi/zug)
C++ library. It provides composable sequential transformations.

## Usage

To start using `libzug` in your project, add the following [`depends`](https://build2.org/bpkg/doc/build2-package-manager-manual.xhtml#manifest-package-depends) value to your [`manifest`](https://build2.org/bpkg/doc/build2-package-manager-manual.xhtml#manifests), adjusting the version constraint as appropriate:

```
depends: libzug ^0.1.1
```

Then import the library in your `buildfile`:

```
import libs = libzug%lib{zug}
```

## Importable targets

This package provides the following importable targets:

```
lib{zug}
```

### Importable targets description

* `zug` - Transducers C++ library.
