No Contracts
------------

This C++ library provides assertion macros facilities that I intend to use while there is no Contracts in C++ (they are being worked on but are not finished or published yet).
The name is because this library is useful only while there is no contracts.

Note: We use [Build2](https://build2.org) to build, generate headers (version for example) and package this library.
