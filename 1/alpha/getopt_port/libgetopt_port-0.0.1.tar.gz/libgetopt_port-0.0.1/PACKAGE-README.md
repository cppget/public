# libgetopt_port - getopt/getopt_long C library

This is a `build2` package for the
[`getopt_port`](https://github.com/kimgr/getopt_port) C library. It provides
an original implementation of `getopt` and `getopt_long` with limited GNU
extensions, under a BSD license, so that non-GPL projects can use getopt-style
command-line parsing.

Upstream does not version or tag releases. This package is based on commit
`9d3d387087d252970923db7f297f681622c4e026`.


## Usage

To start using `libgetopt_port` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libgetopt_port ^0.0.1
```

Then import the library in your `buildfile`:

```
import libs = libgetopt_port%lib{getopt_port}
```

On Windows only the static variant is provided. The shared variant cannot
bind `optarg` / `optind` without `dllimport` in the upstream header, and the
MinGW CRT already defines `getopt`.

Public headers are installed into the `getopt_port/` subdirectory and must be
included with that prefix:

```
#include <getopt_port/getopt.h>
```

A system-installed `getopt` (`#include <getopt.h>` / `sys:libgetopt_port`)
cannot be used as a substitute, because that header has no library-name
prefix.


## Importable targets

This package provides the following importable targets:

```
lib{getopt_port}
```

On Windows only the static member is available.


## Configuration variables

This package has no configuration variables.
