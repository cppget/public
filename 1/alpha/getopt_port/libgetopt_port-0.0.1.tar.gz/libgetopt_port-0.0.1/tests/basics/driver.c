#include <getopt_port/getopt.h>

#include <stddef.h>
#include <string.h>

#undef NDEBUG
#include <assert.h>

int main ()
{
  /* getopt: short option with required argument. */
  {
    char arg0[] = "prog";
    char arg1[] = "-a";
    char arg2[] = "value";
    char* argv[] = {arg0, arg1, arg2, NULL};
    int argc = 3;

    optind = 1;
    assert (getopt (argc, argv, "a:") == 'a');
    assert (optarg != NULL && strcmp (optarg, "value") == 0);
    assert (getopt (argc, argv, "a:") == -1);
  }

  /* getopt_long: long option with required argument. */
  {
    char arg0[] = "prog";
    char arg1[] = "--second";
    char arg2[] = "value";
    char* argv[] = {arg0, arg1, arg2, NULL};
    int argc = 3;

    static const struct option opts[] = {
      {"first", no_argument, 0, 'f'},
      {"second", required_argument, 0, 's'},
      {"third", optional_argument, 0, 't'},
      {0, 0, 0, 0}
    };

    optind = 1;
    assert (getopt_long (argc, argv, "fs:t::", opts, NULL) == 's');
    assert (optarg != NULL && strcmp (optarg, "value") == 0);
    assert (getopt_long (argc, argv, "fs:t::", opts, NULL) == -1);
  }

  return 0;
}
