// file      : libbutl/version.hxx.in -*- C++ -*-
// copyright : Copyright (c) 2014-2019 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#pragma once

// Note: using build2 standard versioning scheme. The numeric version format
// is AAABBBCCCDDDE where:
//
// AAA - major version number
// BBB - minor version number
// CCC - bugfix version number
// DDD - alpha / beta (DDD + 500) version number
// E   - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAABBBCCC. For example:
//
// Version      AAABBBCCCDDDE
//
// 0.1.0        0000010000000
// 0.1.2        0000010010000
// 1.2.3        0010020030000
// 2.2.0-a.1    0020019990010
// 3.0.0-b.2    0029999995020
// 2.2.0-a.1.z  0020019990011
//
#define LIBBUTL_VERSION       90000000ULL
#define LIBBUTL_VERSION_STR   "0.9.0"
#define LIBBUTL_VERSION_ID    "0.9.0"

#define LIBBUTL_VERSION_MAJOR 0
#define LIBBUTL_VERSION_MINOR 9
#define LIBBUTL_VERSION_PATCH 0

#define LIBBUTL_PRE_RELEASE   false

#define LIBBUTL_SNAPSHOT      0ULL
#define LIBBUTL_SNAPSHOT_ID   ""
