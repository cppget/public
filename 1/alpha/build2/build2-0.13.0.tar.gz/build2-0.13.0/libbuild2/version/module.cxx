// file      : libbuild2/version/module.cxx -*- C++ -*-
// license   : MIT; see accompanying LICENSE file

#include <libbuild2/version/module.hxx>

using namespace std;

namespace build2
{
  namespace version
  {
    const string module::name ("version");
  }
}
