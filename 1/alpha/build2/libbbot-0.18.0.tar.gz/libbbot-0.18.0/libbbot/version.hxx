// file      : libbbot/version.hxx.in -*- C++ -*-
// license   : MIT; see accompanying LICENSE file

#ifndef LIBBBOT_VERSION // Note: using the version macro itself.

// The numeric version format is AAAAABBBBBCCCCCDDDE where:
//
// AAAAA - major version number
// BBBBB - minor version number
// CCCCC - bugfix version number
// DDD   - alpha / beta (DDD + 500) version number
// E     - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAAAABBBBBCCCCC. For example:
//
// Version      AAAAABBBBBCCCCCDDDE
//
// 0.1.0        0000000001000000000
// 0.1.2        0000000001000020000
// 1.2.3        0000100002000030000
// 2.2.0-a.1    0000200001999990010
// 3.0.0-b.2    0000299999999995020
// 2.2.0-a.1.z  0000200001999990011
//
#define LIBBBOT_VERSION       18000000000ULL
#define LIBBBOT_VERSION_STR   "0.18.0"
#define LIBBBOT_VERSION_ID    "0.18.0"

#define LIBBBOT_VERSION_MAJOR 0
#define LIBBBOT_VERSION_MINOR 18
#define LIBBBOT_VERSION_PATCH 0

#define LIBBBOT_PRE_RELEASE   false

#define LIBBBOT_SNAPSHOT      0ULL
#define LIBBBOT_SNAPSHOT_ID   ""

#include <libbutl/version.hxx>

#ifdef LIBBUTL_VERSION
#  if !(LIBBUTL_VERSION >= 18000000000ULL && LIBBUTL_VERSION < 18999990001ULL)
#    error incompatible libbutl version, libbutl ^0.18.0 is required
#  endif
#endif

#include <libbpkg/version.hxx>

#ifdef LIBBPKG_VERSION
#  if !(LIBBPKG_VERSION >= 18000000000ULL && LIBBPKG_VERSION < 18999990001ULL)
#    error incompatible libbpkg version, libbpkg ^0.18.0 is required
#  endif
#endif

#endif // LIBBBOT_VERSION
