// file      : libbuild2/test/module.cxx -*- C++ -*-
// license   : MIT; see accompanying LICENSE file

#include <libbuild2/test/module.hxx>

namespace build2
{
  namespace test
  {
    const string module::name ("test");
  }
}
