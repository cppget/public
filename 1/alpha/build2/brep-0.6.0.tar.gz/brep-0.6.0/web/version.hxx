// file      : web/version.hxx.in -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#ifndef WEB_VERSION_HXX_IN
#define WEB_VERSION_HXX_IN

#include <libstudxml/version.hxx>

#ifdef LIBSTUDXML_VERSION
#  if !(LIBSTUDXML_VERSION == 10009995020ULL)
#    error incompatible libstudxml version, libstudxml == 1.1.0-b.2 is required
#  endif
#endif

#endif // WEB_VERSION_HXX_IN
