// file      : libbrep/version.hxx.in -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#ifndef BREP_VERSION // Note: using the version macro itself.

// Note: using build2 standard versioning scheme. The numeric version format
// is AAABBBCCCDDDE where:
//
// AAA - major version number
// BBB - minor version number
// CCC - bugfix version number
// DDD - alpha / beta (DDD + 500) version number
// E   - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAABBBCCC. For example:
//
// Version      AAABBBCCCDDDE
//
// 0.1.0        0000010000000
// 0.1.2        0000010010000
// 1.2.3        0010020030000
// 2.2.0-a.1    0020019990010
// 3.0.0-b.2    0029999995020
// 2.2.0-a.1.z  0020019990011
//
#define BREP_VERSION       60000000ULL
#define BREP_VERSION_STR   "0.6.0"
#define BREP_VERSION_ID    "0.6.0"

#define BREP_VERSION_MAJOR 0
#define BREP_VERSION_MINOR 6
#define BREP_VERSION_PATCH 0

#define BREP_PRE_RELEASE   false

#define BREP_SNAPSHOT      0ULL
#define BREP_SNAPSHOT_ID   ""

#include <libbutl/version.hxx>

#ifdef LIBBUTL_VERSION
#  if !(LIBBUTL_VERSION >= 60000000ULL && LIBBUTL_VERSION < 69990001ULL)
#    error incompatible libbutl version, libbutl [0.6.0 0.7.0-) is required
#  endif
#endif

#include <libbpkg/version.hxx>

#ifdef LIBBPKG_VERSION
#  if !(LIBBPKG_VERSION >= 60000000ULL && LIBBPKG_VERSION < 69990001ULL)
#    error incompatible libbpkg version, libbpkg [0.6.0 0.7.0-) is required
#  endif
#endif

#include <libbbot/version.hxx>

#ifdef LIBBBOT_VERSION
#  if !(LIBBBOT_VERSION >= 60000000ULL && LIBBBOT_VERSION < 69990001ULL)
#    error incompatible libbbot version, libbbot [0.6.0 0.7.0-) is required
#  endif
#endif

#include <odb/version.hxx>

#ifdef LIBODB_VERSION
#  if !(LIBODB_VERSION == 20049995050ULL)
#    error incompatible libodb version, libodb == 2.5.0-b.5 is required
#  endif
#endif

#include <odb/pgsql/version.hxx>

#ifdef LIBODB_PGSQL_VERSION
#  if !(LIBODB_PGSQL_VERSION == 20049995050ULL)
#    error incompatible libodb-pgsql version, libodb-pgsql == 2.5.0-b.5 is required
#  endif
#endif

// For now these are the same.
//
#define LIBBREP_VERSION BREP_VERSION
#define LIBBREP_VERSION_STR BREP_VERSION_STR
#define LIBBREP_VERSION_ID BREP_VERSION_ID

#endif // BREP_VERSION
