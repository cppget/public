// file      : libbrep/common.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2019 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#include <libbrep/common.hxx>

namespace brep
{
  const version wildcard_version (0, "0", nullopt, nullopt, 0);
}
