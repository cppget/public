# libbuild2-autoconf-tests

Tests package for the Autoconf emulation build system module for `build2`.
