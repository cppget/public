#!/bin/bash

# open -a Terminal -n -F ~/bbot-bootstrap-macos.sh

~/bbot-bootstrap.sh --cxx clang++ --build /tmp \
  --environments "$HOME/environments"
