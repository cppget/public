// file      : tests/buildtab/driver.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2018 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#include <ios>      // ios::failbit, ios::badbit
#include <cassert>
#include <iostream>

#include <libbutl/utility.mxx> // operator<<(ostream,exception)

#include <libbbot/build-config.hxx>

using namespace std;
using namespace butl;
using namespace bbot;

// Usage: argv[0]
//
// Read and parse buildtab from STDIN and serialize the resulted build
// configuration to STDOUT.
//
int
main ()
try
{
  cin.exceptions  (ios::failbit | ios::badbit);
  cout.exceptions (ios::failbit | ios::badbit);

  for (const auto& c: parse_buildtab (cin, "cin"))
  {
    cout << c.machine_pattern << ' ' << c.name << ' ' << c.target;

    for (const auto& v: c.vars)
      cout << ' ' << v;

    for (const auto& r: c.warning_regexes)
      cout << " ~" << r;

    cout << '\n';
  }

  return 0;
}
catch (const tab_parsing& e)
{
  cerr << e << endl;
  return 1;
}
