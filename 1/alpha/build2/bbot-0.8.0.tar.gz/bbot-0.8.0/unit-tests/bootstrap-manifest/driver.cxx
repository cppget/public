// file      : unit-tests/bootstrap-manifest/driver.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2018 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#include <ios>      // ios_base::failbit, ios_base::badbit
#include <iostream>

#include <libbutl/manifest-parser.mxx>
#include <libbutl/manifest-serializer.mxx>

#include <bbot/types.hxx>
#include <bbot/utility.hxx>

#include <bbot/bootstrap-manifest.hxx>

using namespace std;
using namespace butl;
using namespace bbot;

// Usage: argv[0]
//
// Read and parse bootstrap manifest from STDIN and serialize it to STDOUT.
//
int
main ()
try
{
  cin.exceptions  (ios_base::failbit | ios_base::badbit);
  cout.exceptions (ios_base::failbit | ios_base::badbit);

  manifest_parser     p (cin,  "stdin");
  manifest_serializer s (cout, "stdout");

  bootstrap_manifest (p).serialize (s);
  return 0;
}
catch (const manifest_parsing& e)
{
  cerr << e << endl;
  return 1;
}
catch (const manifest_serialization& e)
{
  cerr << e << endl;
  return 1;
}
