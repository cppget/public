#! /usr/bin/env bash

version=0.8.0
date="$(date +"%B %Y")"

trap 'exit 1' ERR
set -o errtrace # Trap in functions.

function info () { echo "$*" 1>&2; }
function error () { info "$*"; exit 1; }

while [ $# -gt 0 ]; do
  case $1 in
    --clean)
      rm -f build2-build-bot-manual.xhtml
      rm -f *.ps *.pdf
      exit 0
      ;;
    *)
      error "unexpected $1"
      ;;
  esac
done

function compile ()
{
  local n=$1; shift

  # Use a bash array to handle empty arguments.
  #
  local o=()
  while [ $# -gt 0 ]; do
    o=("${o[@]}" "$1")
    shift
  done

  cli -I .. -v project="bbot" -v version="$version" -v date="$date" \
--include-base-last "${o[@]}" --generate-html --html-prologue-file \
man-prologue.xhtml --html-epilogue-file man-epilogue.xhtml --html-suffix \
.xhtml ../$n.cli

  cli -I .. -v project="bbot" -v version="$version" -v date="$date" \
--include-base-last "${o[@]}" --generate-man --man-prologue-file \
man-prologue.1 --man-epilogue-file man-epilogue.1 --man-suffix .1 \
../$n.cli
}

o="--output-prefix bbot-"

# A few special cases.
#
#compile "bbot" $o --output-prefix ""

pages="bbot/agent/agent bbot/worker/worker"

for p in $pages; do
  compile $p $o
done

# Manuals.
#

function compile_doc () # <file> <prefix> <suffix>
{
  cli -I .. \
-v version="$(echo "$version" | sed -e 's/^\([^.]*\.[^.]*\).*/\1/')" \
-v date="$date" \
--generate-html --html-suffix .xhtml \
--html-prologue-file doc-prologue.xhtml \
--html-epilogue-file doc-epilogue.xhtml \
--output-prefix "$2" \
--output-suffix "$3" \
"$1"

  local n="$2$(basename -s .cli $1)$3"

  html2ps -f doc.html2ps:a4.html2ps -o "$n-a4.ps" "$n.xhtml"
  ps2pdf14 -sPAPERSIZE=a4 -dOptimize=true -dEmbedAllFonts=true "$n-a4.ps" "$n-a4.pdf"

  html2ps -f doc.html2ps:letter.html2ps -o "$n-letter.ps" "$n.xhtml"
  ps2pdf14 -sPAPERSIZE=letter -dOptimize=true -dEmbedAllFonts=true "$n-letter.ps" "$n-letter.pdf"
}

compile_doc manual.cli 'build2-build-bot-'
