// file      : libbbot/build-config.hxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#ifndef LIBBBOT_BUILD_CONFIG_HXX
#define LIBBBOT_BUILD_CONFIG_HXX

#include <string>
#include <vector>
#include <iosfwd>

#include <libbutl/path.hxx>
#include <libbutl/optional.hxx>
#include <libbutl/tab-parser.hxx>
#include <libbutl/target-triplet.hxx>

#include <libbbot/export.hxx>
#include <libbbot/version.hxx>

namespace bbot
{
  // Build configuration matching specific machine names. Used by bbot
  // controllers.
  //
  struct build_config
  {
    std::string machine_pattern; // Machine name pattern.
    std::string name;            // Configuration name.

    butl::optional<butl::target_triplet> target;

    std::vector<std::string> vars;
  };

  using build_configs = std::vector<build_config>;

  // Parse buildtab stream or file. Throw tab_parsing on parsing error,
  // ios::failure on the underlying OS error.
  //
  // buildtab consists of lines in the following format:
  //
  // <machine-name-pattern> <config-name> [<target>] [<config-vars>]
  //
  using butl::tab_parsing;

  LIBBBOT_EXPORT build_configs
  parse_buildtab (std::istream&, const std::string& name);

  LIBBBOT_EXPORT build_configs
  parse_buildtab (const butl::path&);
}

#endif // LIBBBOT_BUILD_CONFIG_HXX
