# libbuild2-hello-tests
Tests for the test build system module for build2
