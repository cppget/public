// file      : bpkg/pkg-unpack.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#include <bpkg/pkg-unpack.hxx>

#include <libbutl/process.hxx>

#include <libbpkg/manifest.hxx>

#include <bpkg/package.hxx>
#include <bpkg/package-odb.hxx>
#include <bpkg/database.hxx>
#include <bpkg/diagnostics.hxx>

#include <bpkg/pkg-purge.hxx>
#include <bpkg/pkg-verify.hxx>

using namespace std;
using namespace butl;

namespace bpkg
{
  shared_ptr<selected_package>
  pkg_unpack (const dir_path& c,
              transaction& t,
              const dir_path& d,
              bool replace,
              bool purge)
  {
    tracer trace ("pkg_unpack");

    database& db (t.database ());
    tracer_guard tg (db, trace);

    if (!exists (d))
      fail << "package directory " << d << " does not exist";

    // Verify the directory is a package and get its manifest.
    //
    package_manifest m (pkg_verify (d, true));
    l4 ([&]{trace << d << ": " << m.name << " " << m.version;});

    // Make the package and configuration paths absolute and normalized.
    // If the package is inside the configuration, use the relative path.
    // This way we can move the configuration around.
    //
    dir_path ac (c), ad (d);
    ac.complete ().normalize ();
    ad.complete ().normalize ();

    if (ad.sub (ac))
      ad = ad.leaf (ac);

    // See if this package already exists in this configuration.
    //
    const string& n (m.name);
    shared_ptr<selected_package> p (db.find<selected_package> (n));

    if (p != nullptr)
    {
      bool s (p->state == package_state::fetched ||
              p->state == package_state::unpacked);

      if (!replace || !s)
      {
        diag_record dr (fail);

        dr << "package " << n << " already exists in configuration " << c <<
          info << "version: " << p->version_string ()
           << ", state: " << p->state
           << ", substate: " << p->substate;

        if (s) // Suitable state for replace?
          dr << info << "use 'pkg-unpack --replace|-r' to replace";
      }

      // Clean up the source directory and archive of the package we are
      // replacing. Once this is done, there is no going back. If things
      // go badly, we can't simply abort the transaction.
      //
      pkg_purge_fs (c, t, p);

      // Use the special root repository as the repository of this package.
      //
      p->version = move (m.version);
      p->state = package_state::unpacked;
      p->repository = repository_location ();
      p->src_root = move (ad);
      p->purge_src = purge;

      db.update (p);
    }
    else
    {
      p.reset (new selected_package {
        move (m.name),
        move (m.version),
        package_state::unpacked,
        package_substate::none,
        false,   // hold package
        false,   // hold version
        repository_location (), // Root repository.
        nullopt,    // No archive
        false,      // Don't purge archive.
        move (ad),
        purge,
        nullopt,    // No output directory yet.
        {}});       // No prerequisites captured yet.

      db.persist (p);
    }

    t.commit ();
    return p;
  }

  shared_ptr<selected_package>
  pkg_unpack (const common_options& co,
              const dir_path& c,
              transaction& t,
              const string& name)
  {
    tracer trace ("pkg_unpack");

    database& db (t.database ());
    tracer_guard tg (db, trace);

    shared_ptr<selected_package> p (db.find<selected_package> (name));

    if (p == nullptr)
      fail << "package " << name << " does not exist in configuration " << c;

    if (p->state != package_state::fetched)
      fail << "package " << name << " is " << p->state <<
        info << "expected it to be fetched";

    l4 ([&]{trace << *p;});

    assert (p->archive); // Should have archive in the fetched state.

    // If the archive path is not absolute, then it must be relative
    // to the configuration.
    //
    path a (p->archive->absolute () ? *p->archive : c / *p->archive);

    l4 ([&]{trace << "archive: " << a;});

    // Extract the package directory. Currently we always extract it
    // into the configuration directory. But once we support package
    // cache, this will need to change.
    //
    // Also, since we must have verified the archive during fetch,
    // here we can just assume what the resulting directory will be.
    //
    dir_path d (c / dir_path (p->name + '-' + p->version.string ()));

    if (exists (d))
      fail << "package directory " << d << " already exists";

    // What should we do if tar or something after it fails? Cleaning
    // up the package directory sounds like the right thing to do.
    //
    auto_rm_r arm (d);

    cstrings args;

    // See if we need to decompress.
    //
    {
      string e (a.extension ());

      if      (e == "gz")    args.push_back ("gzip");
      else if (e == "bzip2") args.push_back ("bzip2");
      else if (e == "xz")    args.push_back ("xz");
      else if (e != "tar")
        fail << "unknown compression method in package " << a;
    }

    size_t i (0); // The tar command line start.
    if (!args.empty ())
    {
      args.push_back ("-dc");
      args.push_back (a.string ().c_str ());
      args.push_back (nullptr);
      i = args.size ();
    }

    args.push_back (co.tar ().string ().c_str ());

    // Add extra options.
    //
    for (const string& o: co.tar_option ())
      args.push_back (o.c_str ());

    // -C/--directory -- change to directory.
    //
    args.push_back ("-C");
    args.push_back (c.string ().c_str ());

    // An archive name that has a colon in it specifies a file or device on a
    // remote machine. That makes it impossible to use absolute Windows paths
    // unless we add the --force-local option. Note that BSD tar doesn't
    // support this option.
    //
#ifdef _WIN32
    args.push_back ("--force-local");
#endif

    args.push_back ("-xf");
    args.push_back (i == 0 ? a.string ().c_str () : "-");
    args.push_back (nullptr);
    args.push_back (nullptr); // Pipe end.

    size_t what;
    try
    {
      process_path dpp;
      process_path tpp;

      process dpr;
      process tpr;

      if (i != 0)
        dpp = process::path_search (args[what = 0]);

      tpp = process::path_search (args[what = i]);

      if (verb >= 2)
        print_process (args);

      if (i != 0)
      {
        dpr = process (dpp, &args[what = 0], 0, -1);
        tpr = process (tpp, &args[what = i], dpr);
      }
      else
        tpr = process (tpp, &args[what = 0]);

      // While it is reasonable to assuming the child process issued
      // diagnostics, tar, specifically, doesn't mention the archive name.
      //
      if (!(what = i, tpr.wait ()) ||
          !(what = 0, dpr.wait ()))
        fail << "unable to extract package archive " << a;
    }
    catch (const process_error& e)
    {
      error << "unable to execute " << args[what] << ": " << e;

      if (e.child)
        exit (1);

      throw failed ();
    }

    p->src_root = d.leaf (); // For now assuming to be in configuration.
    p->purge_src = true;

    p->state = package_state::unpacked;

    db.update (p);
    t.commit ();

    arm.cancel ();

    return p;
  }

  int
  pkg_unpack (const pkg_unpack_options& o, cli::scanner& args)
  {
    tracer trace ("pkg_unpack");

    if (o.replace () && !o.existing ())
      fail << "--replace|-r can only be specified with --existing|-e";

    const dir_path& c (o.directory ());
    l4 ([&]{trace << "configuration: " << c;});

    database db (open (c, trace));
    transaction t (db.begin ());

    shared_ptr<selected_package> p;

    if (o.existing ())
    {
      // The package directory case.
      //
      if (!args.more ())
        fail << "package directory argument expected" <<
          info << "run 'bpkg help pkg-unpack' for more information";

      p = pkg_unpack (
        c, t, dir_path (args.next ()), o.replace (), o.purge ());
    }
    else
    {
      // The package name case.
      //
      if (!args.more ())
        fail << "package name argument expected" <<
          info << "run 'bpkg help pkg-unpack' for more information";

      p = pkg_unpack (o, c, t, args.next ());
    }

    if (verb)
      text << "unpacked " << *p;

    return 0;
  }
}
