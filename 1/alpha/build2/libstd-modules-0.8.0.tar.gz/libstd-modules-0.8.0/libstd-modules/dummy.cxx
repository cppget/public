// file      : libstd-modules/dummy.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2018 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

// Dummy translation unit used to create dummy std.lib for VC.
