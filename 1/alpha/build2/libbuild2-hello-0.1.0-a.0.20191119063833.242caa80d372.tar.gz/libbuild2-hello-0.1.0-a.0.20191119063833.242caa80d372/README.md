# libbuild2-hello
Test build system module for build2
