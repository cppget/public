// file      : bbot/utility.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#include <bbot/utility.hxx>

#include <bbot/diagnostics.hxx>

using namespace std;
using namespace butl;

namespace bbot
{
  void
  run_trace (tracer& t, const char* cmd[], size_t n)
  {
    if (verb >= 3)
    {
      diag_record dr (t);
      process::print (dr.os, cmd, n);
    }
  }
}
