// file      : bbot/diagnostics.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#include <bbot/diagnostics.hxx>

#include <bbot/utility.hxx>

using namespace std;
using namespace butl;

namespace bbot
{
  // Diagnostics verbosity level.
  //
  uint16_t verb;

  // Diagnostic facility, project specifics.
  //

  void simple_prologue_base::
  operator() (const diag_record& r) const
  {
    if (type_ != nullptr)
      r << type_;

    if (name_ != nullptr)
      r << name_ << ": ";
  }

  const char* trace_type = "trace: ";
  const char* trace_indent = "\n  ";

  trace_mark_base::
  trace_mark_base (const char* name, const void* data)
      : basic_mark_base (trace_type, trace_indent, name, data)
  {
  }

  basic_mark error ("error: ");
  basic_mark warn  ("warning: ");
  basic_mark info  ("info: ");
  basic_mark text  (nullptr);
  fail_mark  fail  ("error: ");

  const fail_end endf;

  // Right arrow followed by newline.
  //
  const char systemd_indent[] = "\xE2\x86\xB2\n";

  void
  systemd_diagnostics (bool with_critical)
  {
    trace_indent    =
      fail.indent_  =
      error.indent_ =
      warn.indent_  =
      info.indent_  =
      text.indent_  = systemd_indent;

    fail.type_  = with_critical ? "<2>" : "<3>";
    error.type_ = "<3>";
    warn.type_  = "<4>";
    info.type_  = "<6>";
    trace_type  = "<7>";
  }
}
