// file      : bbot/version.hxx.in -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#ifndef BBOT_VERSION // Note: using the version macro itself.

// Note: using build2 standard versioning scheme. The numeric version format
// is AAABBBCCCDDDE where:
//
// AAA - major version number
// BBB - minor version number
// CCC - bugfix version number
// DDD - alpha / beta (DDD + 500) version number
// E   - final (0) / snapshot (1)
//
// When DDDE is not 0, 1 is subtracted from AAABBBCCC. For example:
//
// Version      AAABBBCCCDDDE
//
// 0.1.0        0000010000000
// 0.1.2        0000010010000
// 1.2.3        0010020030000
// 2.2.0-a.1    0020019990010
// 3.0.0-b.2    0029999995020
// 2.2.0-a.1.z  0020019990011
//
#define BBOT_VERSION       50000000ULL
#define BBOT_VERSION_STR   "0.5.0"
#define BBOT_VERSION_ID    "0.5.0"

#define BBOT_VERSION_MAJOR 0
#define BBOT_VERSION_MINOR 5
#define BBOT_VERSION_PATCH 0

#define BBOT_PRE_RELEASE   false

#define BBOT_SNAPSHOT      0ULL
#define BBOT_SNAPSHOT_ID   ""

#include <libbutl/version.hxx>

#ifdef LIBBUTL_VERSION
#  if !(LIBBUTL_VERSION >= 50000000ULL && LIBBUTL_VERSION < 59990001ULL)
#    error incompatible libbutl version, libbutl [0.5.0 0.6.0-) is required
#  endif
#endif

#include <libbbot/version.hxx>

#ifdef LIBBBOT_VERSION
#  if !(LIBBBOT_VERSION >= 50000000ULL && LIBBBOT_VERSION < 59990001ULL)
#    error incompatible libbbot version, libbbot [0.5.0 0.6.0-) is required
#  endif
#endif

// User agent.
//
#if   defined(_WIN32)
# if defined(__MINGW32__)
#  define BBOT_OS "MinGW"
# else
#  define BBOT_OS "Windows"
# endif
#elif defined(__linux)
#  define BBOT_OS "GNU/Linux"
#elif defined(__APPLE__)
#  define BBOT_OS "MacOS"
#elif defined(__CYGWIN__)
#  define BBOT_OS "Cygwin"
#elif defined(__FreeBSD__)
#  define BBOT_OS "FreeBSD"
#elif defined(__OpenBSD__)
#  define BBOT_OS "OpenBSD"
#elif defined(__NetBSD__)
#  define BBOT_OS "NetBSD"
#elif defined(__sun)
#  define BBOT_OS "Solaris"
#elif defined(__hpux)
#  define BBOT_OS "HP-UX"
#elif defined(_AIX)
#  define BBOT_OS "AIX"
#elif defined(__unix)
#  define BBOT_OS "Unix"
#elif defined(__posix)
#  define BBOT_OS "Posix"
#else
#  define BBOT_OS "Other"
#endif

#define BBOT_USER_AGENT                                              \
  "bbot/" BBOT_VERSION_STR " (" BBOT_OS "; +https://build2.org)"     \
  " libbbot/" LIBBBOT_VERSION_STR                                    \
  " libbutl/" LIBBUTL_VERSION_STR

#endif // BBOT_VERSION
