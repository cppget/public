#!/bin/bash

# open -a Terminal -n -F ~/bbot-bootstrap-macos.sh

if ~/bbot-bootstrap.sh --cxx clang++ --build /tmp \
		       --environments "$HOME/environments"; then
  sleep 2
  sudo shutdown -h now
fi
