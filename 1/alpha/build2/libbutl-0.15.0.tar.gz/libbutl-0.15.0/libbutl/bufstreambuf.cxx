// file      : libbutl/bufstreambuf.cxx -*- C++ -*-
// license   : MIT; see accompanying LICENSE file

#include <libbutl/bufstreambuf.hxx>

namespace butl
{
  bufstreambuf::
  ~bufstreambuf ()
  {
    // Vtable.
  }
}
