// file      : tests/driver.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

import std.core;
import std.io;

using namespace std;

int
main ()
{
  cout << string ("Hello, World!") << endl;
}
