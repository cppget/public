// file      : dummy.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

// Dummy translation unit used to create dummy std.lib for VC.
