// file      : mod/database-module.hxx -*- C++ -*-
// copyright : Copyright (c) 2014-2018 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#ifndef MOD_DATABASE_MODULE_HXX
#define MOD_DATABASE_MODULE_HXX

#include <map>

#include <odb/forward.hxx> // database

#include <libbutl/utility.mxx> // compare_c_string

#include <libbrep/types.hxx>
#include <libbrep/utility.hxx>

#include <libbbot/build-config.hxx>

#include <mod/module.hxx>
#include <mod/options.hxx>
#include <mod/build-config.hxx>

namespace brep
{
  // A module that utilises the database. Specifically, it will retry the
  // request in the face of recoverable database failures (deadlock, loss of
  // connection, etc) up to a certain number of times.
  //
  class database_module: public module
  {
  protected:
    database_module () = default;

    // Create a shallow copy (handling instance) if initialized and a deep
    // copy (context exemplar) otherwise.
    //
    explicit
    database_module (const database_module&);

    // Required to avoid getting warning from clang that
    // database_module::init() hides module::init() virtual functions. This
    // way all functions get to the same scope and become overloaded set.
    //
    using module::init;

    // Initialize the package database instance. Throw odb::exception on
    // failure.
    //
    void
    init (const options::package_db&, size_t retry);

    // Initialize the build database instance and parse build configuration
    // file. Throw odb::exception on database failure, tab_parsing on parsing
    // error, system_error on the underlying OS error.
    //
    void
    init (const options::build&, const options::build_db&, size_t retry);

    virtual bool
    handle (request&, response&) = 0;

  protected:
    size_t retry_ = 0; // Max of all retries.

    shared_ptr<odb::core::database> package_db_;

    // These are NULL if not building.
    //
    shared_ptr<odb::core::database>       build_db_;
    shared_ptr<const bbot::build_configs> build_conf_;
    shared_ptr<const cstrings>            build_conf_names_;

    shared_ptr<const std::map<const char*,
                              const bbot::build_config*,
                              butl::compare_c_string>>
    build_conf_map_;

    shared_ptr<const bot_agent_keys> bot_agent_keys_;

  private:
    virtual bool
    handle (request&, response&, log&);
  };
}

#endif // MOD_DATABASE_MODULE_HXX
