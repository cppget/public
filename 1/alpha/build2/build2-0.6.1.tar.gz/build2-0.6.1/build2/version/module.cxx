// file      : build2/version/module.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#include <build2/version/module.hxx>

using namespace std;

namespace build2
{
  namespace version
  {
    const string module::name ("version");
  }
}
