// file      : bbot/agent/agent.hxx -*- C++ -*-
// copyright : Copyright (c) 2014-2017 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#ifndef BBOT_AGENT_AGENT_HXX
#define BBOT_AGENT_AGENT_HXX

#include <sys/types.h> // uid_t

#include <bbot/types.hxx>
#include <bbot/utility.hxx>

#include <bbot/agent/agent-options.hxx>

namespace bbot
{
  extern agent_options ops;

  extern const string bs_prot; // Bootstrap protocol version.

  extern string           tc_name; // Toolchain name.
  extern uint16_t         tc_num;  // Toolchain number.
  extern standard_version tc_ver;  // Toolchain version.
  extern string           tc_id;   // Toolchain id.

  extern string hname; // Our host name.
  extern uid_t  uid;   // Our effective user id.
  extern string uname; // Our effective user name.

  // Random number generator (currently not MT-safe and limited to RAND_MAX).
  //
  size_t
  genrand ();

  template <typename T>
  inline T
  genrand () {return static_cast<T> (genrand ());}

  // Return the IPv4 address of an interface.
  //
  string
  iface_addr (const string&);
}

#endif // BBOT_AGENT_AGENT_HXX
