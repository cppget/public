#include <linenoise.h>

int main() {}
