#define STB_LEAKCHECK_IMPLEMENTATION
#include <stb_leakcheck.h>

int main() {}
