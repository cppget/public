#define STBCC_GRID_COUNT_X_LOG2 10
#define STBCC_GRID_COUNT_Y_LOG2 10
#define STB_CONNECTED_COMPONENTS_IMPLEMENTATION
#include <stb_connected_components.h>

int main() {}
