#define STBVOX_CONFIG_MODE 0
#define STB_VOXEL_RENDER_IMPLEMENTATION
#include <stb_voxel_render.h>

int main() {}
