#define STB_DIVIDE_IMPLEMENTATION
#include <stb_divide.h>

int main() {}
