#include <stb_image_resize.h>

int main ()
{
}
