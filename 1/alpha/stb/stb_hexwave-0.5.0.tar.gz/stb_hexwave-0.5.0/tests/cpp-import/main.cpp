#define STB_HEXWAVE_IMPLEMENTATION
#include <stb_hexwave.h>

int main() {}
