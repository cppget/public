// For now, we cannot test the implementation.
// So, we restrict ourselves to test the importation.
//
// #define STB_TILEMAP_EDITOR_IMPLEMENTATION
#include <stb_tilemap_editor.h>

int main() {}
