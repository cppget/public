#define STB_INCLUDE_IMPLEMENTATION
#include <stb_include.h>

int main() {}
