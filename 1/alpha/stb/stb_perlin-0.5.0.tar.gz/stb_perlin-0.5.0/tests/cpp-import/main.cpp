#define STB_PERLIN_IMPLEMENTATION
#include <stb_perlin.h>

int main() {}
