#define STB_C_LEXER_IMPLEMENTATION
#include <stb_c_lexer.h>

int main() {}
