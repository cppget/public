#define STB_HERRINGBONE_WANG_TILE_IMPLEMENTATION
#include <stb_herringbone_wang_tile.h>

int main() {}
