/*-
 * Copyright 2012-2018-2014 Matthew Endsley
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted providing that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <tinystl/vector.h>
#include <UnitTest++.h>

TEST(vector_shrinktofit) {
	typedef tinystl::vector<int> vector;

	{
		vector v;
		CHECK(v.capacity() == 0);
		v.clear();
		v.shrink_to_fit();
		CHECK(v.capacity() == 0);
	}

	{
		vector v(10, 0);
		CHECK(v.capacity() >= 10);
		v.shrink_to_fit();
		CHECK(v.capacity() == 10);
	}

	{
		vector v(10, 0);
		CHECK(v.capacity() >= 10);
		v.erase(v.end() - 1, v.end());
		CHECK(v.size() == 9);
		CHECK(v.capacity() >= 10);
		v.shrink_to_fit();
		CHECK(v.capacity() == 9);
	}

	{
		vector v(10, 0);
		CHECK(v.capacity() >= 10);
		const int* ptr = v.data();
		v.shrink_to_fit();
		CHECK(v.capacity() >= 10);
		CHECK(v.data() == ptr);
	}
}

TEST(vector_shrinktofit_multiple) {
	typedef tinystl::vector<int> vector;

	vector v(10, 0);
	v.clear();
	v.shrink_to_fit();
	v.shrink_to_fit();
}
