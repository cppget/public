bool f();
bool g();
int main()
{
    f();
    g();
}
