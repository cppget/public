#pragma once
#define PSTLD_HEADER_ONLY
#define PSTLD_HACK_INTO_STD
#include <pstld/pstld.h>
#include <Cocoa/Cocoa.h> // to check that this file is compiled as Objective-C++
