// file      : odb/pgsql/prepared-query.cxx
// copyright : Copyright (c) 2005-2015 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/pgsql/prepared-query.hxx>

namespace odb
{
  namespace pgsql
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
