# kconfig-qconf

Linux kernel configuration system (Kconfig) graphical configurator based on
Qt.
