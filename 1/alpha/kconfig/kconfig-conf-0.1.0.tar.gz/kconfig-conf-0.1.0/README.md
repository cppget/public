# kconfig-conf

Linux kernel configuration system (Kconfig) basic configurator.

This configurator provides a number of non-interactive configuration modes
(default, random, etc), as well as a question and answer-based interactive
mode.
