/*
 * file      : libcmark-gfm/cmark-gfm_version.h
 * copyright : Copyright (c) 2016-2019 Code Synthesis Ltd
 * license   : FreeBSD License; see accompanying COPYING file
 */

#include <libcmark-gfm/version.h>
