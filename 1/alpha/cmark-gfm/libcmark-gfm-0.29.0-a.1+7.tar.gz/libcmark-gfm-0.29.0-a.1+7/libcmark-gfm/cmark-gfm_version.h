/*
 * file      : libcmark-gfm/cmark-gfm_version.h
 * license   : FreeBSD License; see accompanying COPYING file
 */

#include <libcmark-gfm/version.h>
