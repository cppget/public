/* file      : libcmark-gfm/cmark-gfm_version.h
 * license   : BSD 2-Clause "Simplified" License; see accompanying COPYING file
 */

#include <libcmark-gfm/version.h>
