// file      : libxsd-frontend/traversal/namespace.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <libxsd-frontend/traversal/namespace.hxx>

namespace XSDFrontend
{
  namespace Traversal
  {
  }
}
