// file      : libxsd-frontend/traversal/fundamental.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <libxsd-frontend/traversal/fundamental.hxx>

namespace XSDFrontend
{
  namespace Traversal
  {
  }
}
