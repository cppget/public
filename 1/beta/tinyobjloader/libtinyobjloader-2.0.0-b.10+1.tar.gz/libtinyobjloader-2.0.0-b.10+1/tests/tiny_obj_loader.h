// The tester includes the tinyobjloader header
// by refering to the relative path '../tiny_obj_loader.h'.
// Hence, we use this dummy file at this location
// to include the library without issues.
//
#include <tiny_obj_loader.h>
