/* file      : cutl/details/build2/config-stub.h
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <cutl/details/config.h>
