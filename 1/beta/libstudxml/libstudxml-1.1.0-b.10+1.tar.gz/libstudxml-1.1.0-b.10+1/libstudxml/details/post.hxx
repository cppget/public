// file      : libstudxml/details/post.hxx
// license   : MIT; see accompanying LICENSE file

#ifdef _MSC_VER
#  pragma warning (pop)
#endif
