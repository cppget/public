// file      : odb/qt/mutable-list-iterator.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef ODB_QT_MUTABLE_LIST_ITERATOR_HXX
#define ODB_QT_MUTABLE_LIST_ITERATOR_HXX

#include <odb/qt/containers/mutable-list-iterator.hxx>

#endif // ODB_QT_MUTABLE_LIST_ITERATOR_HXX
