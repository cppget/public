/* file      : odb/details/build2/config-stub.h
 * copyright : Copyright (c) 2009-2018 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/details/config.h>
