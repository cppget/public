// file      : odb/sqlite/simple-object-statements.cxx
// copyright : Copyright (c) 2005-2018 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/sqlite/simple-object-statements.hxx>

namespace odb
{
  namespace sqlite
  {
    object_statements_base::
    ~object_statements_base ()
    {
    }
  }
}
