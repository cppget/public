/* file      : odb/oracle/details/build2/config-vc-stub.h
 * license   : ODB NCUEL; see accompanying LICENSE file
 */

#include <odb/oracle/details/config-vc.h>
