// file      : odb/version-build2-stub.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/version.hxx>
