// file      : odb/oracle/statements-base.cxx
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/oracle/statements-base.hxx>

namespace odb
{
  namespace oracle
  {
    statements_base::
    ~statements_base ()
    {
    }
  }
}
