/* file      : odb/oracle/details/build2/config-stub.h
 * license   : ODB NCUEL; see accompanying LICENSE file
 */

#include <odb/oracle/details/config.h>
