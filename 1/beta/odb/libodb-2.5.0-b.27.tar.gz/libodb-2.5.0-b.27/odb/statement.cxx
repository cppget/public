// file      : odb/statement.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/statement.hxx>

namespace odb
{
  statement::
  ~statement ()
  {
  }
}
