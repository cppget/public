// file      : odb/boost/lazy-ptr.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef ODB_BOOST_LAZY_PTR_HXX
#define ODB_BOOST_LAZY_PTR_HXX

#include <odb/boost/smart-ptr/lazy-ptr.hxx>

#endif // ODB_BOOST_LAZY_PTR_HXX
