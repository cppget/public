// file      : odb/mssql/version-build2-stub.hxx
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/version.hxx>
