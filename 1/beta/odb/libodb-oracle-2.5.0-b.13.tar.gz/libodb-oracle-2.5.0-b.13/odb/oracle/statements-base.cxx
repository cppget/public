// file      : odb/oracle/statements-base.cxx
// copyright : Copyright (c) 2005-2019 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/oracle/statements-base.hxx>

namespace odb
{
  namespace oracle
  {
    statements_base::
    ~statements_base ()
    {
    }
  }
}
