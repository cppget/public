/* file      : odb/mysql/details/build2/config-stub.h
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/mysql/details/config.h>
