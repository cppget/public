// file      : odb/mssql/prepared-query.cxx
// copyright : Copyright (c) 2005-2019 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/prepared-query.hxx>

namespace odb
{
  namespace mssql
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
