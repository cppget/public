// file      : odb/oracle/version-build2-stub.hxx
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/oracle/version.hxx>
