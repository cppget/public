// file      : odb/mssql/simple-object-statements.cxx
// copyright : Copyright (c) 2005-2019 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/simple-object-statements.hxx>

namespace odb
{
  namespace mssql
  {
    object_statements_base::
    ~object_statements_base ()
    {
    }
  }
}
