// file      : odb/mysql/prepared-query.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/mysql/prepared-query.hxx>

namespace odb
{
  namespace mysql
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
