/* file      : odb/pgsql/details/build2/config-vc-stub.h
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/pgsql/details/config-vc.h>
