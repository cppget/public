/* file      : odb/sqlite/details/build2/config-stub.h
 * copyright : Copyright (c) 2009-2017 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/sqlite/details/config.h>
