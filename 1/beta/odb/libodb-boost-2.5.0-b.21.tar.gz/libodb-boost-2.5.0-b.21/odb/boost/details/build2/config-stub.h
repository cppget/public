/* file      : odb/boost/details/build2/config-stub.h
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/boost/details/config.h>
