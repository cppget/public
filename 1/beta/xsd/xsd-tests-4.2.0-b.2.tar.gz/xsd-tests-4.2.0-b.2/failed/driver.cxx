// file      : failed/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test-00.hxx"

int
main (int, char*[])
{
}
