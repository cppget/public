// file      : schema/import/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "importer.hxx"

int
main (int, char*[])
{
}
