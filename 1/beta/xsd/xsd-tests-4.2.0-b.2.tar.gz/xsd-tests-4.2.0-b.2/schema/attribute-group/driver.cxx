// file      : schema/attribute-group/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "global.hxx"

int
main (int, char*[])
{
}
