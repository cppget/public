// file      : schema/chameleon/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "includer.hxx"
#include "schemas/includee.hxx"

int
main (int, char*[])
{
}
