// file      : schema/any-type/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test.hxx"

int
main (int, char*[])
{
}
