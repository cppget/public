// file      : schema/import/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "importer.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
