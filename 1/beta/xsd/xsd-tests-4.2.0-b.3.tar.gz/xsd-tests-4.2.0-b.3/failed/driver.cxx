// file      : failed/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test-00.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
