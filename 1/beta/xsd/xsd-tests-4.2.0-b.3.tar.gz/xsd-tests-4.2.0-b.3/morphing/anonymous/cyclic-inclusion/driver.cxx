// file      : morphing/anonymous/cyclic-inclusion/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "includee.hxx"
#include "includer.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
