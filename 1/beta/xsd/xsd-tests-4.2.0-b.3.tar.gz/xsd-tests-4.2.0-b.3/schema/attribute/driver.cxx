// file      : schema/attribute/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "ref.hxx"
#include "global.hxx"
#include "local.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
