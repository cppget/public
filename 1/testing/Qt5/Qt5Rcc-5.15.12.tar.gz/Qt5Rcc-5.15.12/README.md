# Qt5Rcc

This package contains the Qt5 resource compiler (`rcc`).
