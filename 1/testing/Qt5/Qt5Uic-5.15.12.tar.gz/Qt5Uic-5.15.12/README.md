# Qt5Uic

This package contains the Qt5 user interface compiler (`uic`).
