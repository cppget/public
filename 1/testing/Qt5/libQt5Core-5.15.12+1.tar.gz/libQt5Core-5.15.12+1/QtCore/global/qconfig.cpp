// This file is included by corelib/global/qlibraryinfo.cpp only (never
// compiled). In the upstream build it is auto-generated. In our build it
// provides declarations with definitions auto-generated in
// qconfig-{install,develop}.cpp. See the buildfile and then qconfig.cpp.in
// for details.

extern const char qt_configure_prefix_path_str[12 + 256];
#define QT_CONFIGURE_PREFIX_PATH qt_configure_prefix_path_str + 12

extern const short qt_configure_str_offsets[13];
extern const char* qt_configure_strs;

extern const char* QT_CONFIGURE_SETTINGS_PATH;
extern const char* QT_CONFIGURE_LIBLOCATION_TO_PREFIX_PATH;
