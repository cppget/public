# Qt5Moc

This package contains the Qt5 meta object compiler (`moc`).
