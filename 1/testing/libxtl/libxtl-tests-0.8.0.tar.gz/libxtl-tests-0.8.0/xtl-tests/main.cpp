#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#if defined(XTL_NO_EXCEPTIONS)
    #define DOCTEST_CONFIG_NO_EXCEPTIONS
#endif
#include "doctest/doctest.h"

