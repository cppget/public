# libtinyfiledialogs - Native file and message dialog C library

This is a `build2` package for the [`tinyfiledialogs`](https://tinyfiledialogs.sourceforge.net)
C library. It provides a single-file C implementation of native dialog boxes
(message, input, file open/save, folder, color picker, notification, and beep)
on Windows, macOS, Unix, and the console.


## Usage

To start using `libtinyfiledialogs` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libtinyfiledialogs ^3.21.4
```

Then import the library in your `buildfile`:

```
import libs = libtinyfiledialogs%lib{tinyfiledialogs}
```


## Importable targets

This package provides the following importable targets:

```
lib{tinyfiledialogs}
```

The compiled tinyfiledialogs C library. Include the public header as
`<tinyfiledialogs/tinyfiledialogs.h>`. On Windows, linking the static
variant also pulls in comdlg32, ole32, user32, and shell32. On Unix and
macOS the library shells out to tools such as osascript, zenity, or
kdialog, and needs no extra link libraries.


## Configuration variables

This package has no configuration variables.
