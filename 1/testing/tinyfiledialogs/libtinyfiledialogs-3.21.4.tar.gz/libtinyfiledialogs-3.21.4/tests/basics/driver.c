#include <tinyfiledialogs/tinyfiledialogs.h>

#include <string.h>

#undef NDEBUG
#include <assert.h>

int main (void)
{
  char const *v = tinyfd_getGlobalChar ("tinyfd_version");
  assert (v != NULL);
  assert (strcmp (v, "3.21.4") == 0);

  assert (tinyfd_getGlobalInt ("tinyfd_verbose") == 0);
  assert (tinyfd_getGlobalInt ("tinyfd_silent") == 1);
  assert (tinyfd_setGlobalInt ("tinyfd_verbose", 0) == 0);

  return 0;
}
