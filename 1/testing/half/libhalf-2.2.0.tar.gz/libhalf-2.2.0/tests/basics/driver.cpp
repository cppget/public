#include <half.hpp>

#undef NDEBUG
#include <cassert>

int main ()
{
  using half_float::half;

  half a (1.5f);
  half b (2.0f);
  half c = a * b;

  assert (static_cast<float> (a) == 1.5f);
  assert (static_cast<float> (b) == 2.0f);
  assert (static_cast<float> (c) == 3.0f);

  // 0.5 is exactly representable in binary16.
  //
  float x = 0.5f;
  half hx (x);
  assert (static_cast<float> (hx) == x);

  half n (-2.0f);
  assert (static_cast<float> (n) == -2.0f);

  half assigned;
  assigned = 4.0f;
  assert (static_cast<float> (assigned) == 4.0f);
}
