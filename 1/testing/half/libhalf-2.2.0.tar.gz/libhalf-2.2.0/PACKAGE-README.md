# libhalf - IEEE 754 half-precision floating-point C++ library

This is a `build2` package for the [half](https://half.sourceforge.net/)
C++ library. It provides a header-only IEEE 754 conformant 16-bit
half-precision floating-point type along with corresponding arithmetic
operators, type conversions and common mathematical functions.

This package tracks Debian `half` 2.2.0-1 (upstream half 2.2.0). Debian
ships no quilt patches for this version. Public headers are installed as
`<half.hpp>`, matching Debian `libhalf-dev`.


## Usage

To start using `libhalf` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libhalf ^2.2.0
```

Then import the library in your `buildfile`:

```
import libs = libhalf%lib{half}
```


## Importable targets

This package provides the following importable targets:

```
lib{half}
```

This is a binless (header-only) library. The public header is included as
`<half.hpp>`.


## Configuration variables

This package has no configuration variables.
