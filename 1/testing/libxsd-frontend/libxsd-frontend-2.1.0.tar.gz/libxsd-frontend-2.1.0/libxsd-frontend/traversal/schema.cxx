// file      : libxsd-frontend/traversal/schema.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <libxsd-frontend/traversal/schema.hxx>

namespace XSDFrontend
{
  namespace Traversal
  {
  }
}
