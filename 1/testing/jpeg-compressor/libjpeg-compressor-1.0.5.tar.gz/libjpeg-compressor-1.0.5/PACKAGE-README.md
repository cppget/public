# libjpeg-compressor - C++ JPEG compression and decompression library

This is a `build2` package for the [`jpeg-compressor`](https://github.com/richgel999/jpeg-compressor)
C++ library. It provides a public-domain (or Apache 2.0) baseline JPEG
encoder (`jpge.cpp`/`jpge.h`) and a stand-alone decoder (`jpgd.cpp`/`jpgd.h`)
with progressive image support.

This package builds the encoder and decoder as one compiled library. It does
not ship the upstream example tool. Upstream last tagged `v104` (1.0.4) in
2012. This package uses `1.0.5` and pins the later master commit `aeb7d3b`
(May 2020).

Public headers install under `include/jpeg-compressor/`. Include them as
`<jpeg-compressor/jpge.h>` and `<jpeg-compressor/jpgd.h>`. Unqualified names
such as `<jpge.h>` are not exported. Debian's header-only
`libjpeg-compressor-cpp-dev` (`jpeg-compressor-cpp` 104) uses a different
layout and is not this package's include path.

`jpgd_idct.h` is a private SSE2 helper (Intel copyright, 2009) included only
from `jpgd.cpp`. It is not installed. The package combines that Intel notice
with either Apache-2.0 or public domain.


## Usage

To start using `libjpeg-compressor` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libjpeg-compressor ^1.0.5
```

Then import the library in your `buildfile`:

```
import libs = libjpeg-compressor%lib{jpeg-compressor}
```


## Importable targets

This package provides the following importable targets:

```
lib{jpeg-compressor}
```

The compiled encoder plus decoder library (`jpge` and `jpgd`). Automatic DLL
symbol exporting is enabled because upstream has no export macros.


## Configuration variables

This package has no configuration variables.
