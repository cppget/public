#include <jpeg-compressor/jpge.h>
#include <jpeg-compressor/jpgd.h>

#include <cstdlib>
#include <vector>

#undef NDEBUG
#include <cassert>

int main ()
{
  const int width = 16;
  const int height = 16;
  const int channels = 3;

  std::vector<jpge::uint8> rgb (static_cast<size_t> (width * height * channels));
  for (int y = 0; y < height; ++y)
  {
    for (int x = 0; x < width; ++x)
    {
      const size_t i = static_cast<size_t> ((y * width + x) * channels);
      rgb[i + 0] = static_cast<jpge::uint8> (x * 16);
      rgb[i + 1] = static_cast<jpge::uint8> (y * 16);
      rgb[i + 2] = 128;
    }
  }

  // Encode a generated RGB buffer to JPEG in memory, then decode it back.
  //
  std::vector<jpge::uint8> jpeg (64 * 1024);
  int buf_size = static_cast<int> (jpeg.size ());

  const bool encoded = jpge::compress_image_to_jpeg_file_in_memory (
    jpeg.data (), buf_size, width, height, channels, rgb.data ());
  assert (encoded);
  assert (buf_size > 0);

  int out_width = 0;
  int out_height = 0;
  int actual_comps = 0;
  unsigned char* decoded = jpgd::decompress_jpeg_image_from_memory (
    jpeg.data (), buf_size, &out_width, &out_height, &actual_comps, channels);
  assert (decoded != nullptr);
  assert (out_width == width);
  assert (out_height == height);
  assert (actual_comps == 3);

  std::free (decoded);
}
