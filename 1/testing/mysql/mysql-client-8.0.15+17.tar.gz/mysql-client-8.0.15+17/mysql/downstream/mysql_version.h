/* file      : mysql/downstream/mysql_version.h
 * license   : GPLv2 with Universal FOSS Exception; see accompanying LICENSE file
 */

#include <mysql/mysql_version.h>
