#include <Zycore/Zycore.h>

#undef NDEBUG
#include <assert.h>

int
main ()
{
  return 0;
}
