// Copyright (c) 2018 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Validates correctness of extension SPIR-V instructions.
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <sstream>
#include <string>
#include <vector>

#include "OpenCLDebugInfo100.h"
#include "source/common_debug_info.h"
#include "source/extensions.h"
#include "source/latest_version_glsl_std_450_header.h"
#include "source/latest_version_opencl_std_header.h"
#include "source/opcode.h"
#include "source/spirv_constant.h"
#include "source/table2.h"
#include "source/val/instruction.h"
#include "source/val/validate.h"
#include "source/val/validation_state.h"
#include "spirv-tools/libspirv.h"
#include "spirv/unified1/ArmExperimentalMLOperations.h"
#include "spirv/unified1/NonSemanticClspvReflection.h"
#include "spirv/unified1/NonSemanticGraphDebugInfo.h"
#include "spirv/unified1/NonSemanticShaderDebugInfo.h"

namespace spvtools {
namespace val {
namespace {

std::string ReflectionInstructionName(const Instruction* inst) {
  const ExtInstDesc* desc = nullptr;
  if (LookupExtInst(SPV_EXT_INST_TYPE_NONSEMANTIC_CLSPVREFLECTION,
                    inst->word(4), &desc) != SPV_SUCCESS ||
      !desc) {
    return std::string("Unknown ExtInst");
  }
  std::ostringstream ss;
  ss << desc->name().data();

  return ss.str();
}

uint32_t GetSizeTBitWidth(const ValidationState_t& _) {
  if (_.addressing_model() == spv::AddressingModel::Physical32) return 32;

  if (_.addressing_model() == spv::AddressingModel::Physical64) return 64;

  return 0;
}

bool IsIntScalar(ValidationState_t& _, uint32_t id, bool must_len32,
                 bool must_unsigned) {
  auto type = _.FindDef(id);
  if (!type || type->opcode() != spv::Op::OpTypeInt) {
    return false;
  }

  if (must_len32 && type->GetOperandAs<uint32_t>(1) != 32) {
    return false;
  }

  return !must_unsigned || type->GetOperandAs<uint32_t>(2) == 0;
}

bool IsUint32Constant(ValidationState_t& _, uint32_t id) {
  auto inst = _.FindDef(id);
  if (!inst || inst->opcode() != spv::Op::OpConstant) {
    return false;
  }

  return IsIntScalar(_, inst->type_id(), true, true);
}

bool IsGraphDebugInfoDebugGraph(const Instruction* inst) {
  return spvIsExtendedInstruction(inst->opcode()) &&
         inst->ext_inst_type() ==
             SPV_EXT_INST_TYPE_NONSEMANTIC_GRAPH_DEBUGINFO &&
         inst->word(4) == NonSemanticGraphDebugInfoDebugGraph;
}

bool IsTopLevelCompositeOfTensors(ValidationState_t& _, uint32_t type_id) {
  const auto* type = _.FindDef(type_id);
  if (!type) return false;

  if (type->opcode() == spv::Op::OpTypeArray ||
      type->opcode() == spv::Op::OpTypeRuntimeArray) {
    const auto* element_type = _.FindDef(type->word(2));
    return element_type && element_type->opcode() == spv::Op::OpTypeTensorARM;
  }

  if (type->opcode() == spv::Op::OpTypeStruct) {
    for (uint32_t word_index = 2; word_index < type->words().size();
         ++word_index) {
      const auto* member_type = _.FindDef(type->word(word_index));
      if (!member_type || member_type->opcode() != spv::Op::OpTypeTensorARM) {
        return false;
      }
    }
    return true;
  }

  return false;
}

bool IsInstructionInGraph(ValidationState_t& _, uint32_t inst_id,
                          uint32_t graph_id) {
  bool in_graph = false;
  for (const auto& module_inst : _.ordered_instructions()) {
    if (module_inst.opcode() == spv::Op::OpGraphARM) {
      in_graph = module_inst.id() == graph_id;
    }

    if (in_graph && module_inst.id() == inst_id) return true;

    if (in_graph && module_inst.opcode() == spv::Op::OpGraphEndARM) {
      in_graph = false;
    }
  }

  return false;
}

uint32_t GetUint32Constant(ValidationState_t& _, uint32_t id) {
  auto inst = _.FindDef(id);
  return inst->word(3);
}

std::string GetExtInstName(const ValidationState_t& _,
                           const Instruction* inst) {
  const uint32_t ext_inst_set = inst->word(3);
  const uint32_t ext_inst_index = inst->word(4);
  const spv_ext_inst_type_t ext_inst_type =
      spv_ext_inst_type_t(inst->ext_inst_type());

  const ExtInstDesc* desc = nullptr;
  if (LookupExtInst(ext_inst_type, ext_inst_index, &desc) != SPV_SUCCESS ||
      !desc) {
    return std::string("Unknown ExtInst");
  }

  auto* import_inst = _.FindDef(ext_inst_set);
  assert(import_inst);

  std::ostringstream ss;
  ss << import_inst->GetOperandAs<std::string>(1);
  ss << " ";
  ss << desc->name().data();

  return ss.str();
}

// Returns the declared NSDI version from the OpExtInstImport referenced by
// |inst|.  Returns 0 if not a NonSemantic.Shader.DebugInfo import.
uint32_t GetNSDIVersion(const ValidationState_t& _, const Instruction* inst) {
  const auto* import_inst = _.FindDef(inst->word(3));
  if (!import_inst) return 0;
  const std::string name = import_inst->GetOperandAs<std::string>(1);
  const char kPrefix[] = "NonSemantic.Shader.DebugInfo.";
  if (name.find(kPrefix) != 0) return 0;
  return static_cast<uint32_t>(
      std::strtoul(name.c_str() + sizeof(kPrefix) - 1, nullptr, 10));
}

// Check that the operand of a debug info instruction |inst| at |word_index|
// is a result id of an instruction with |expected_opcode|.
spv_result_t ValidateOperandForDebugInfo(ValidationState_t& _,
                                         const std::string& operand_name,
                                         spv::Op expected_opcode,
                                         const Instruction* inst,
                                         uint32_t word_index) {
  auto* operand = _.FindDef(inst->word(word_index));
  if (operand->opcode() != expected_opcode) {
    const spvtools::InstructionDesc* desc = nullptr;
    if (spvtools::LookupOpcodeForEnv(_.context()->target_env, expected_opcode,
                                     &desc) != SPV_SUCCESS ||
        !desc) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << GetExtInstName(_, inst) << ": " << "expected operand "
             << operand_name << " is invalid";
    }
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": " << "expected operand "
           << operand_name << " must be a result id of " << "Op"
           << desc->name().data();
  }
  return SPV_SUCCESS;
}

// For NonSemantic.Shader.DebugInfo.100 check that the operand of a debug info
// instruction |inst| at |word_index| is a result id of a 32-bit integer
// OpConstant instruction. For OpenCL.DebugInfo.100 the parameter is a literal
// word so cannot be validated.
spv_result_t ValidateUint32ConstantOperandForDebugInfo(
    ValidationState_t& _, const std::string& operand_name,
    const Instruction* inst, uint32_t word_index,
    bool allow_spec_const = false) {
  const uint32_t id = inst->word(word_index);
  if (!IsUint32Constant(_, id)) {
    if (allow_spec_const) {
      auto* def = _.FindDef(id);
      if (def && spvOpcodeIsSpecConstant(def->opcode()) &&
          IsIntScalar(_, def->type_id(), true, true))
        return SPV_SUCCESS;
    }
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": expected operand " << operand_name
           << " must be a result id of "
           << (allow_spec_const
                   ? "a 32-bit unsigned integer constant or specialization"
                     " constant"
                   : "32-bit unsigned OpConstant");
  }
  return SPV_SUCCESS;
}

#define CHECK_OPERAND(NAME, opcode, index)                                   \
  do {                                                                       \
    auto result = ValidateOperandForDebugInfo(_, NAME, opcode, inst, index); \
    if (result != SPV_SUCCESS) return result;                                \
  } while (0)

#define CHECK_CONST_UINT_OPERAND(NAME, index)                            \
  if (vulkanDebugInfo) {                                                 \
    auto result =                                                        \
        ValidateUint32ConstantOperandForDebugInfo(_, NAME, inst, index); \
    if (result != SPV_SUCCESS) return result;                            \
  }

// Like CHECK_CONST_UINT_OPERAND but also allows spec-constants.  Used for
// NonSemantic.Shader.DebugInfo.101 cooperative type instructions, where
// dimension operands may be specialization constants.
#define CHECK_CONST_OR_SPEC_UINT_OPERAND(NAME, index)                          \
  if (vulkanDebugInfo) {                                                       \
    auto result =                                                              \
        ValidateUint32ConstantOperandForDebugInfo(_, NAME, inst, index, true); \
    if (result != SPV_SUCCESS) return result;                                  \
  }

// Checks that the NSDI version for the current instruction is at least |v|.
// Used to guard opcodes added after version 100.
#define CHECK_NSDI_MIN_VERSION(v)                                       \
  if (nsdi_version < (v)) {                                             \
    return _.diag(SPV_ERROR_INVALID_DATA, inst)                         \
           << GetExtInstName(_, inst)                                   \
           << ": requires NonSemantic.Shader.DebugInfo version " << (v) \
           << " or later";                                              \
  }

// True if the operand of a debug info instruction |inst| at |word_index|
// satisfies |expectation| that is given as a function. Otherwise,
// returns false.
bool DoesDebugInfoOperandMatchExpectation(
    const ValidationState_t& _,
    const std::function<bool(CommonDebugInfoInstructions)>& expectation,
    const Instruction* inst, uint32_t word_index) {
  if (inst->words().size() <= word_index) return false;
  auto* debug_inst = _.FindDef(inst->word(word_index));
  if (!spvIsExtendedInstruction(debug_inst->opcode()) ||
      (debug_inst->ext_inst_type() != SPV_EXT_INST_TYPE_OPENCL_DEBUGINFO_100 &&
       debug_inst->ext_inst_type() !=
           SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100) ||
      !expectation(CommonDebugInfoInstructions(debug_inst->word(4)))) {
    return false;
  }
  return true;
}

// Overload for NonSemanticShaderDebugInfoInstructions.
bool DoesDebugInfoOperandMatchExpectation(
    const ValidationState_t& _,
    const std::function<bool(NonSemanticShaderDebugInfoInstructions)>&
        expectation,
    const Instruction* inst, uint32_t word_index) {
  if (inst->words().size() <= word_index) return false;
  auto* debug_inst = _.FindDef(inst->word(word_index));
  if (!spvIsExtendedInstruction(debug_inst->opcode()) ||
      (debug_inst->ext_inst_type() !=
       SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100) ||
      !expectation(
          NonSemanticShaderDebugInfoInstructions(debug_inst->word(4)))) {
    return false;
  }
  return true;
}

// Check that the operand of a debug info instruction |inst| at |word_index|
// is a result id of an debug info instruction whose debug instruction type
// is |expected_debug_inst|.
spv_result_t ValidateDebugInfoOperand(
    ValidationState_t& _, const std::string& debug_inst_name,
    CommonDebugInfoInstructions expected_debug_inst, const Instruction* inst,
    uint32_t word_index) {
  std::function<bool(CommonDebugInfoInstructions)> expectation =
      [expected_debug_inst](CommonDebugInfoInstructions dbg_inst) {
        return dbg_inst == expected_debug_inst;
      };
  if (DoesDebugInfoOperandMatchExpectation(_, expectation, inst, word_index))
    return SPV_SUCCESS;

  const ExtInstDesc* desc = nullptr;
  if (LookupExtInst(inst->ext_inst_type(), expected_debug_inst, &desc) !=
          SPV_SUCCESS ||
      !desc) {
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": " << "expected operand "
           << debug_inst_name << " is invalid";
  }
  return _.diag(SPV_ERROR_INVALID_DATA, inst)
         << GetExtInstName(_, inst) << ": " << "expected operand "
         << debug_inst_name << " must be a result id of "
         << desc->name().data();
}

#define CHECK_DEBUG_OPERAND(NAME, debug_opcode, index)                \
  do {                                                                \
    auto result =                                                     \
        ValidateDebugInfoOperand(_, NAME, debug_opcode, inst, index); \
    if (result != SPV_SUCCESS) return result;                         \
  } while (0)

// Check that the operand of a debug info instruction |inst| at |word_index|
// is a result id of an debug info instruction with DebugTypeBasic.
spv_result_t ValidateOperandBaseType(ValidationState_t& _,
                                     const Instruction* inst,
                                     uint32_t word_index) {
  return ValidateDebugInfoOperand(_, "Base Type", CommonDebugInfoDebugTypeBasic,
                                  inst, word_index);
}

// Check that the operand of a debug info instruction |inst| at |word_index|
// is a result id of a debug lexical scope instruction which is one of
// DebugCompilationUnit, DebugFunction, DebugLexicalBlock, or
// DebugTypeComposite.
spv_result_t ValidateOperandLexicalScope(ValidationState_t& _,
                                         const std::string& debug_inst_name,
                                         const Instruction* inst,
                                         uint32_t word_index) {
  std::function<bool(CommonDebugInfoInstructions)> expectation =
      [](CommonDebugInfoInstructions dbg_inst) {
        return dbg_inst == CommonDebugInfoDebugCompilationUnit ||
               dbg_inst == CommonDebugInfoDebugFunction ||
               dbg_inst == CommonDebugInfoDebugLexicalBlock ||
               dbg_inst == CommonDebugInfoDebugTypeComposite;
      };
  if (DoesDebugInfoOperandMatchExpectation(_, expectation, inst, word_index))
    return SPV_SUCCESS;

  return _.diag(SPV_ERROR_INVALID_DATA, inst)
         << GetExtInstName(_, inst) << ": " << "expected operand "
         << debug_inst_name << " must be a result id of a lexical scope";
}

// Check that the operand of a debug info instruction |inst| at |word_index|
// is a result id of a debug type instruction (See DebugTypeXXX in
// "4.3. Type instructions" section of OpenCL.DebugInfo.100 spec.
spv_result_t ValidateOperandDebugType(ValidationState_t& _,
                                      const std::string& debug_inst_name,
                                      const Instruction* inst,
                                      uint32_t word_index,
                                      bool allow_template_param) {
  // Check for NonSemanticShaderDebugInfo specific types.
  if (inst->ext_inst_type() ==
      SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100) {
    const uint32_t nsdi_version = GetNSDIVersion(_, inst);
    std::function<bool(NonSemanticShaderDebugInfoInstructions)> expectation =
        [nsdi_version](NonSemanticShaderDebugInfoInstructions dbg_inst) {
          if (dbg_inst == NonSemanticShaderDebugInfoDebugTypeMatrix)
            return true;
          // DebugTypeVectorIdEXT and DebugTypeCooperativeMatrixKHR were added
          // in NonSemantic.Shader.DebugInfo version 101.
          if (nsdi_version >= NonSemanticShaderDebugInfoVersion &&
              (dbg_inst == NonSemanticShaderDebugInfoDebugTypeVectorIdEXT ||
               dbg_inst ==
                   NonSemanticShaderDebugInfoDebugTypeCooperativeMatrixKHR))
            return true;
          return false;
        };
    if (DoesDebugInfoOperandMatchExpectation(_, expectation, inst, word_index))
      return SPV_SUCCESS;
  }

  // Check for common types.
  std::function<bool(CommonDebugInfoInstructions)> expectation =
      [&allow_template_param](CommonDebugInfoInstructions dbg_inst) {
        // TODO - Should DebugTypeTemplateParameterPack be allowed?
        if (allow_template_param &&
            (dbg_inst == CommonDebugInfoDebugTypeTemplateParameter ||
             dbg_inst == CommonDebugInfoDebugTypeTemplateTemplateParameter)) {
          return true;
        } else if (dbg_inst == CommonDebugInfoDebugInfoNone) {
          // DebugInfoNone is a safe "null" type that can be used
          return true;
        }
        return CommonDebugInfoDebugTypeBasic <= dbg_inst &&
               dbg_inst <= CommonDebugInfoDebugTypeTemplate;
      };
  if (DoesDebugInfoOperandMatchExpectation(_, expectation, inst, word_index))
    return SPV_SUCCESS;

  return _.diag(SPV_ERROR_INVALID_DATA, inst)
         << GetExtInstName(_, inst) << ": " << "expected operand "
         << debug_inst_name << " is not a valid debug type";
}

spv_result_t ValidateOperandDebugSource(ValidationState_t& _,
                                        const Instruction* inst,
                                        uint32_t source_index,
                                        uint32_t line_index,
                                        uint32_t column_index,
                                        spv_ext_inst_type_t ext_inst_type) {
  auto* debug_source_inst = _.FindDef(inst->word(source_index));
  const std::vector<uint32_t>& line_lengths =
      _.GetDebugSourceLineLength(debug_source_inst->id());
  if (line_lengths.empty())
    return SPV_SUCCESS;  // Text not provide in DebugSource

  const bool vulkanDebugInfo =
      ext_inst_type == SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100;
  uint32_t line = 0;
  uint32_t column = 0;
  // NonSemantic uses OpConstant for all operands
  if (vulkanDebugInfo) {
    bool is_int32 = false, is_const_int32 = false;
    std::tie(is_int32, is_const_int32, line) =
        _.EvalInt32IfConst(inst->word(line_index));
    std::tie(is_int32, is_const_int32, column) =
        _.EvalInt32IfConst(inst->word(column_index));
  } else {
    line = inst->word(line_index);
    column = inst->word(column_index);
  }

  if (line > line_lengths.size()) {
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": operand Line (" << line
           << ") is larger then the " << line_lengths.size()
           << " lines found in the DebugSource text";
  } else if (line != 0) {
    const uint32_t line_length = line_lengths[line - 1];
    if (column > line_length) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << GetExtInstName(_, inst) << ": operand Column End (" << column
             << ") is larger then Line " << line << " column length of "
             << line_length << " found in the DebugSource text";
    }
  }
  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionKernel(ValidationState_t& _,
                                           const Instruction* inst,
                                           uint32_t version) {
  const auto inst_name = ReflectionInstructionName(inst);
  const auto kernel_id = inst->GetOperandAs<uint32_t>(4);
  const auto kernel = _.FindDef(kernel_id);
  if (kernel->opcode() != spv::Op::OpFunction) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << inst_name << " does not reference a function";
  }

  bool found_kernel = false;
  for (auto entry_point : _.entry_points()) {
    if (entry_point == kernel_id) {
      found_kernel = true;
      break;
    }
  }
  if (!found_kernel) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << inst_name << " does not reference an entry-point";
  }

  const auto* exec_models = _.GetExecutionModels(kernel_id);
  if (!exec_models || exec_models->empty()) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << inst_name << " does not reference an entry-point";
  }
  for (auto exec_model : *exec_models) {
    if (exec_model != spv::ExecutionModel::GLCompute) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << inst_name << " must refer only to GLCompute entry-points";
    }
  }

  auto name = _.FindDef(inst->GetOperandAs<uint32_t>(5));
  if (!name || name->opcode() != spv::Op::OpString) {
    return _.diag(SPV_ERROR_INVALID_ID, inst) << "Name must be an OpString";
  }

  const std::string name_str = name->GetOperandAs<std::string>(1);
  bool found = false;
  for (auto& desc : _.entry_point_descriptions(kernel_id)) {
    if (name_str == desc.name) {
      found = true;
      break;
    }
  }
  if (!found) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Name must match an entry-point for Kernel";
  }

  const auto num_operands = inst->operands().size();
  if (version < 5 && num_operands > 6) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Version " << version << " of the " << inst_name
           << " instruction can only have 2 additional operands";
  }

  if (num_operands > 6) {
    const auto num_args_id = inst->GetOperandAs<uint32_t>(6);
    if (!IsUint32Constant(_, num_args_id)) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "NumArguments must be a 32-bit unsigned integer OpConstant";
    }
  }

  if (num_operands > 7) {
    const auto flags_id = inst->GetOperandAs<uint32_t>(7);
    if (!IsUint32Constant(_, flags_id)) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "Flags must be a 32-bit unsigned integer OpConstant";
    }
  }

  if (num_operands > 8) {
    const auto atts_id = inst->GetOperandAs<uint32_t>(8);
    if (_.GetIdOpcode(atts_id) != spv::Op::OpString) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "Attributes must be an OpString";
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionArgumentInfo(ValidationState_t& _,
                                                 const Instruction* inst) {
  const auto num_operands = inst->operands().size();
  if (_.GetIdOpcode(inst->GetOperandAs<uint32_t>(4)) != spv::Op::OpString) {
    return _.diag(SPV_ERROR_INVALID_ID, inst) << "Name must be an OpString";
  }
  if (num_operands > 5) {
    if (_.GetIdOpcode(inst->GetOperandAs<uint32_t>(5)) != spv::Op::OpString) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "TypeName must be an OpString";
    }
  }
  if (num_operands > 6) {
    if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "AddressQualifier must be a 32-bit unsigned integer "
                "OpConstant";
    }
  }
  if (num_operands > 7) {
    if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "AccessQualifier must be a 32-bit unsigned integer "
                "OpConstant";
    }
  }
  if (num_operands > 8) {
    if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(8))) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "TypeQualifier must be a 32-bit unsigned integer "
                "OpConstant";
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateKernelDecl(ValidationState_t& _, const Instruction* inst) {
  const auto decl_id = inst->GetOperandAs<uint32_t>(4);
  const auto decl = _.FindDef(decl_id);
  if (!decl || !spvIsExtendedInstruction(decl->opcode())) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Kernel must be a Kernel extended instruction";
  }

  if (decl->GetOperandAs<uint32_t>(2) != inst->GetOperandAs<uint32_t>(2)) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Kernel must be from the same extended instruction import";
  }

  const auto ext_inst =
      decl->GetOperandAs<NonSemanticClspvReflectionInstructions>(3);
  if (ext_inst != NonSemanticClspvReflectionKernel) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Kernel must be a Kernel extended instruction";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateArgInfo(ValidationState_t& _, const Instruction* inst,
                             uint32_t info_index) {
  auto info = _.FindDef(inst->GetOperandAs<uint32_t>(info_index));
  if (!info || !spvIsExtendedInstruction(info->opcode())) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "ArgInfo must be an ArgumentInfo extended instruction";
  }

  if (info->GetOperandAs<uint32_t>(2) != inst->GetOperandAs<uint32_t>(2)) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "ArgInfo must be from the same extended instruction import";
  }

  auto ext_inst = info->GetOperandAs<NonSemanticClspvReflectionInstructions>(3);
  if (ext_inst != NonSemanticClspvReflectionArgumentInfo) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "ArgInfo must be an ArgumentInfo extended instruction";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionArgumentBuffer(ValidationState_t& _,
                                                   const Instruction* inst) {
  const auto num_operands = inst->operands().size();
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (num_operands == 9) {
    if (auto error = ValidateArgInfo(_, inst, 8)) {
      return error;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionArgumentOffsetBuffer(
    ValidationState_t& _, const Instruction* inst) {
  const auto num_operands = inst->operands().size();
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(8))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(9))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  if (num_operands == 11) {
    if (auto error = ValidateArgInfo(_, inst, 10)) {
      return error;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionArgumentPushConstant(
    ValidationState_t& _, const Instruction* inst) {
  const auto num_operands = inst->operands().size();
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  if (num_operands == 9) {
    if (auto error = ValidateArgInfo(_, inst, 8)) {
      return error;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionArgumentWorkgroup(ValidationState_t& _,
                                                      const Instruction* inst) {
  const auto num_operands = inst->operands().size();
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "SpecId must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "ElemSize must be a 32-bit unsigned integer OpConstant";
  }

  if (num_operands == 9) {
    if (auto error = ValidateArgInfo(_, inst, 8)) {
      return error;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionSpecConstantTriple(
    ValidationState_t& _, const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "X must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Y must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Z must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionSpecConstantWorkDim(
    ValidationState_t& _, const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Dim must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPushConstant(ValidationState_t& _,
                                                 const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionInitializedData(ValidationState_t& _,
                                                    const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (_.GetIdOpcode(inst->GetOperandAs<uint32_t>(6)) != spv::Op::OpString) {
    return _.diag(SPV_ERROR_INVALID_ID, inst) << "Data must be an OpString";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionSampler(ValidationState_t& _,
                                            const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Mask must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPropertyRequiredWorkgroupSize(
    ValidationState_t& _, const Instruction* inst) {
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "X must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Y must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Z must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionSubgroupMaxSize(ValidationState_t& _,
                                                    const Instruction* inst) {
  const auto size_id = inst->GetOperandAs<uint32_t>(4);
  if (!IsUint32Constant(_, size_id)) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPointerRelocation(ValidationState_t& _,
                                                      const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "ObjectOffset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "PointerOffset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "PointerSize must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionImageMetadataPushConstant(
    ValidationState_t& _, const Instruction* inst) {
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionImageMetadataUniform(
    ValidationState_t& _, const Instruction* inst) {
  if (auto error = ValidateKernelDecl(_, inst)) {
    return error;
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Ordinal must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(7))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(8))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(9))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPushConstantData(ValidationState_t& _,
                                                     const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  if (_.GetIdOpcode(inst->GetOperandAs<uint32_t>(6)) != spv::Op::OpString) {
    return _.diag(SPV_ERROR_INVALID_ID, inst) << "Data must be an OpString";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPrintfInfo(ValidationState_t& _,
                                               const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "PrintfID must be a 32-bit unsigned integer OpConstant";
  }

  if (_.GetIdOpcode(inst->GetOperandAs<uint32_t>(5)) != spv::Op::OpString) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "FormatString must be an OpString";
  }

  for (size_t i = 6; i < inst->operands().size(); ++i) {
    if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(i))) {
      return _.diag(SPV_ERROR_INVALID_ID, inst)
             << "ArgumentSizes must be a 32-bit unsigned integer OpConstant";
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPrintfStorageBuffer(
    ValidationState_t& _, const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "DescriptorSet must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Binding must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionPrintfPushConstant(
    ValidationState_t& _, const Instruction* inst) {
  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(4))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Offset must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(5))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Size must be a 32-bit unsigned integer OpConstant";
  }

  if (!IsUint32Constant(_, inst->GetOperandAs<uint32_t>(6))) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "BufferSize must be a 32-bit unsigned integer OpConstant";
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateClspvReflectionInstruction(ValidationState_t& _,
                                                const Instruction* inst,
                                                uint32_t version) {
  if (!_.IsVoidType(inst->type_id())) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << "Return Type must be OpTypeVoid";
  }

  uint32_t required_version = 0;
  const auto ext_inst =
      inst->GetOperandAs<NonSemanticClspvReflectionInstructions>(3);
  switch (ext_inst) {
    case NonSemanticClspvReflectionKernel:
    case NonSemanticClspvReflectionArgumentInfo:
    case NonSemanticClspvReflectionArgumentStorageBuffer:
    case NonSemanticClspvReflectionArgumentUniform:
    case NonSemanticClspvReflectionArgumentPodStorageBuffer:
    case NonSemanticClspvReflectionArgumentPodUniform:
    case NonSemanticClspvReflectionArgumentPodPushConstant:
    case NonSemanticClspvReflectionArgumentSampledImage:
    case NonSemanticClspvReflectionArgumentStorageImage:
    case NonSemanticClspvReflectionArgumentSampler:
    case NonSemanticClspvReflectionArgumentWorkgroup:
    case NonSemanticClspvReflectionSpecConstantWorkgroupSize:
    case NonSemanticClspvReflectionSpecConstantGlobalOffset:
    case NonSemanticClspvReflectionSpecConstantWorkDim:
    case NonSemanticClspvReflectionPushConstantGlobalOffset:
    case NonSemanticClspvReflectionPushConstantEnqueuedLocalSize:
    case NonSemanticClspvReflectionPushConstantGlobalSize:
    case NonSemanticClspvReflectionPushConstantRegionOffset:
    case NonSemanticClspvReflectionPushConstantNumWorkgroups:
    case NonSemanticClspvReflectionPushConstantRegionGroupOffset:
    case NonSemanticClspvReflectionConstantDataStorageBuffer:
    case NonSemanticClspvReflectionConstantDataUniform:
    case NonSemanticClspvReflectionLiteralSampler:
    case NonSemanticClspvReflectionPropertyRequiredWorkgroupSize:
      required_version = 1;
      break;
    case NonSemanticClspvReflectionSpecConstantSubgroupMaxSize:
      required_version = 2;
      break;
    case NonSemanticClspvReflectionArgumentPointerPushConstant:
    case NonSemanticClspvReflectionArgumentPointerUniform:
    case NonSemanticClspvReflectionProgramScopeVariablesStorageBuffer:
    case NonSemanticClspvReflectionProgramScopeVariablePointerRelocation:
    case NonSemanticClspvReflectionImageArgumentInfoChannelOrderPushConstant:
    case NonSemanticClspvReflectionImageArgumentInfoChannelDataTypePushConstant:
    case NonSemanticClspvReflectionImageArgumentInfoChannelOrderUniform:
    case NonSemanticClspvReflectionImageArgumentInfoChannelDataTypeUniform:
      required_version = 3;
      break;
    case NonSemanticClspvReflectionArgumentStorageTexelBuffer:
    case NonSemanticClspvReflectionArgumentUniformTexelBuffer:
      required_version = 4;
      break;
    case NonSemanticClspvReflectionConstantDataPointerPushConstant:
    case NonSemanticClspvReflectionProgramScopeVariablePointerPushConstant:
    case NonSemanticClspvReflectionPrintfInfo:
    case NonSemanticClspvReflectionPrintfBufferStorageBuffer:
    case NonSemanticClspvReflectionPrintfBufferPointerPushConstant:
      required_version = 5;
      break;
    default:
      break;
  }
  if (version < required_version) {
    return _.diag(SPV_ERROR_INVALID_ID, inst)
           << ReflectionInstructionName(inst) << " requires version "
           << required_version << ", but parsed version is " << version;
  }

  switch (ext_inst) {
    case NonSemanticClspvReflectionKernel:
      return ValidateClspvReflectionKernel(_, inst, version);
    case NonSemanticClspvReflectionArgumentInfo:
      return ValidateClspvReflectionArgumentInfo(_, inst);
    case NonSemanticClspvReflectionArgumentStorageBuffer:
    case NonSemanticClspvReflectionArgumentUniform:
    case NonSemanticClspvReflectionArgumentSampledImage:
    case NonSemanticClspvReflectionArgumentStorageImage:
    case NonSemanticClspvReflectionArgumentSampler:
    case NonSemanticClspvReflectionArgumentStorageTexelBuffer:
    case NonSemanticClspvReflectionArgumentUniformTexelBuffer:
      return ValidateClspvReflectionArgumentBuffer(_, inst);
    case NonSemanticClspvReflectionArgumentPodStorageBuffer:
    case NonSemanticClspvReflectionArgumentPodUniform:
    case NonSemanticClspvReflectionArgumentPointerUniform:
      return ValidateClspvReflectionArgumentOffsetBuffer(_, inst);
    case NonSemanticClspvReflectionArgumentPodPushConstant:
    case NonSemanticClspvReflectionArgumentPointerPushConstant:
      return ValidateClspvReflectionArgumentPushConstant(_, inst);
    case NonSemanticClspvReflectionArgumentWorkgroup:
      return ValidateClspvReflectionArgumentWorkgroup(_, inst);
    case NonSemanticClspvReflectionSpecConstantWorkgroupSize:
    case NonSemanticClspvReflectionSpecConstantGlobalOffset:
      return ValidateClspvReflectionSpecConstantTriple(_, inst);
    case NonSemanticClspvReflectionSpecConstantWorkDim:
      return ValidateClspvReflectionSpecConstantWorkDim(_, inst);
    case NonSemanticClspvReflectionPushConstantGlobalOffset:
    case NonSemanticClspvReflectionPushConstantEnqueuedLocalSize:
    case NonSemanticClspvReflectionPushConstantGlobalSize:
    case NonSemanticClspvReflectionPushConstantRegionOffset:
    case NonSemanticClspvReflectionPushConstantNumWorkgroups:
    case NonSemanticClspvReflectionPushConstantRegionGroupOffset:
      return ValidateClspvReflectionPushConstant(_, inst);
    case NonSemanticClspvReflectionConstantDataStorageBuffer:
    case NonSemanticClspvReflectionConstantDataUniform:
    case NonSemanticClspvReflectionProgramScopeVariablesStorageBuffer:
      return ValidateClspvReflectionInitializedData(_, inst);
    case NonSemanticClspvReflectionLiteralSampler:
      return ValidateClspvReflectionSampler(_, inst);
    case NonSemanticClspvReflectionPropertyRequiredWorkgroupSize:
      return ValidateClspvReflectionPropertyRequiredWorkgroupSize(_, inst);
    case NonSemanticClspvReflectionSpecConstantSubgroupMaxSize:
      return ValidateClspvReflectionSubgroupMaxSize(_, inst);
    case NonSemanticClspvReflectionProgramScopeVariablePointerRelocation:
      return ValidateClspvReflectionPointerRelocation(_, inst);
    case NonSemanticClspvReflectionImageArgumentInfoChannelOrderPushConstant:
    case NonSemanticClspvReflectionImageArgumentInfoChannelDataTypePushConstant:
      return ValidateClspvReflectionImageMetadataPushConstant(_, inst);
    case NonSemanticClspvReflectionImageArgumentInfoChannelOrderUniform:
    case NonSemanticClspvReflectionImageArgumentInfoChannelDataTypeUniform:
      return ValidateClspvReflectionImageMetadataUniform(_, inst);
    case NonSemanticClspvReflectionConstantDataPointerPushConstant:
    case NonSemanticClspvReflectionProgramScopeVariablePointerPushConstant:
      return ValidateClspvReflectionPushConstantData(_, inst);
    case NonSemanticClspvReflectionPrintfInfo:
      return ValidateClspvReflectionPrintfInfo(_, inst);
    case NonSemanticClspvReflectionPrintfBufferStorageBuffer:
      return ValidateClspvReflectionPrintfStorageBuffer(_, inst);
    case NonSemanticClspvReflectionPrintfBufferPointerPushConstant:
      return ValidateClspvReflectionPrintfPushConstant(_, inst);
    default:
      break;
  }

  return SPV_SUCCESS;
}

std::string GetDebugSourceText(ValidationState_t& _, const Instruction* inst,
                               uint32_t ext_inst_opcode) {
  assert(ext_inst_opcode == NonSemanticShaderDebugInfoDebugSource ||
         ext_inst_opcode == NonSemanticShaderDebugInfoDebugSourceContinued);
  const uint32_t string_operand =
      (ext_inst_opcode == NonSemanticShaderDebugInfoDebugSource) ? 6 : 5;
  auto* debug_source_text_insn = _.FindDef(inst->word(string_operand));
  // Validated to be an OpString
  assert(debug_source_text_insn->opcode() == spv::Op::OpString);
  return debug_source_text_insn->GetOperandAs<std::string>(1);
}

// We build up a vector that is length of the DebugSource lines and get how long
// they are to make sure anyone using a DebugSource provides valid Line/Columns
// inside
void BuildDebugSourceLineLength(ValidationState_t& _, const Instruction* inst,
                                uint32_t ext_inst_index) {
  if (ext_inst_index == NonSemanticShaderDebugInfoDebugSource &&
      inst->words().size() < 7) {
    return;  // The optional text was not provided
  }

  std::string debug_source_text = GetDebugSourceText(_, inst, ext_inst_index);

  // walk back to get DebugSource to update it's line length list
  uint32_t debug_source_id = inst->id();
  uint32_t continue_count = 0;

  // There might be
  //   %a = OpString "line starts here"
  //   %b = OpString " and still the same line"
  //
  //   %c = OpExtInst %void %1 DebugSource %_ %a
  //   %d = OpExtInst %void %1 DebugSourceContinued %b
  // So we want to find the previous line for checking if we need to append on
  // to the length of the previous line
  bool start_new_line = true;
  if (ext_inst_index == NonSemanticShaderDebugInfoDebugSourceContinued) {
    auto prev_index = inst - &_.ordered_instructions()[0] - 1;
    auto prev_inst = &_.ordered_instructions()[prev_index];

    std::string previous_line_text =
        GetDebugSourceText(_, prev_inst, prev_inst->GetOperandAs<uint32_t>(3));
    if (!previous_line_text.empty() && previous_line_text.back() != '\n') {
      start_new_line = false;
    }
  }

  while (ext_inst_index == NonSemanticShaderDebugInfoDebugSourceContinued) {
    continue_count++;  // might have multiple Continues in a row
    auto prev_index = inst - &_.ordered_instructions()[0] - continue_count;
    auto prev_inst = &_.ordered_instructions()[prev_index];
    debug_source_id = prev_inst->id();
    ext_inst_index = prev_inst->GetOperandAs<uint32_t>(3);
  }

  std::vector<uint32_t>& line_lengths =
      _.GetDebugSourceLineLength(debug_source_id);
  uint32_t line_start = 0;
  // If we have a line like "abc", it really column 1-to-4.
  // Even an empty line should have a column of 1
  // Add 1 to length to emulate this later
  uint32_t length = 1;

  // Continue from the previous line length
  if (!start_new_line) {
    length = line_lengths.back();
    line_lengths.pop_back();
  }

  for (uint32_t i = 0; i < debug_source_text.size(); ++i) {
    if (debug_source_text[i] == '\n') {
      // Unix-style new line
      line_lengths.push_back(length);
      length = 1;
      line_start = i + 1;
    } else if (debug_source_text[i] == '\r') {
      // Handle Windows-style \r\n
      if (i + 1 < debug_source_text.size() &&
          debug_source_text[i + 1] == '\n') {
        line_lengths.push_back(length);
        ++i;  // Skip '\n'
      } else {
        line_lengths.push_back(length);
      }
      length = 1;
      line_start = i + 1;
    } else {
      ++length;
    }
  }

  // Capture last line if the string does not end in a newline
  if (line_start < debug_source_text.size()) {
    line_lengths.push_back(length);
  }
}

bool IsConstIntScalarTypeWith32Or64Bits(ValidationState_t& _,
                                        Instruction* instr) {
  if (instr->opcode() != spv::Op::OpConstant) return false;
  if (!_.IsIntScalarType(instr->type_id())) return false;
  uint32_t size_in_bits = _.GetBitWidth(instr->type_id());
  return size_in_bits == 32 || size_in_bits == 64;
}

bool IsSpecConstIntScalarTypeWith32Or64Bits(ValidationState_t& _,
                                            Instruction* instr) {
  if (!spvOpcodeIsSpecConstant(instr->opcode())) return false;
  if (!_.IsIntScalarType(instr->type_id())) return false;
  uint32_t size_in_bits = _.GetBitWidth(instr->type_id());
  return size_in_bits == 32 || size_in_bits == 64;
}

bool IsConstWithIntScalarType(ValidationState_t& _, const Instruction* inst,
                              uint32_t word_index) {
  auto* int_scalar_const = _.FindDef(inst->word(word_index));
  if (int_scalar_const->opcode() == spv::Op::OpConstant &&
      _.IsIntScalarType(int_scalar_const->type_id())) {
    return true;
  }
  return false;
}

bool IsDebugVariableWithIntScalarType(ValidationState_t& _,
                                      const Instruction* inst,
                                      uint32_t word_index) {
  auto* dbg_int_scalar_var = _.FindDef(inst->word(word_index));
  if (CommonDebugInfoInstructions(dbg_int_scalar_var->word(4)) ==
          CommonDebugInfoDebugLocalVariable ||
      CommonDebugInfoInstructions(dbg_int_scalar_var->word(4)) ==
          CommonDebugInfoDebugGlobalVariable) {
    auto* dbg_type = _.FindDef(dbg_int_scalar_var->word(6));
    if (CommonDebugInfoInstructions(dbg_type->word(4)) ==
        CommonDebugInfoDebugTypeBasic) {
      const spv_ext_inst_type_t ext_inst_type =
          spv_ext_inst_type_t(inst->ext_inst_type());
      const bool vulkanDebugInfo =
          ext_inst_type == SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100;
      uint32_t encoding = dbg_type->word(7);
      if (!vulkanDebugInfo || IsUint32Constant(_, encoding)) {
        auto ocl_encoding = OpenCLDebugInfo100DebugBaseTypeAttributeEncoding(
            vulkanDebugInfo ? GetUint32Constant(_, encoding) : encoding);
        if (ocl_encoding == OpenCLDebugInfo100Signed ||
            ocl_encoding == OpenCLDebugInfo100Unsigned) {
          return true;
        }
      }
    }
  }
  return false;
}

}  // anonymous namespace

spv_result_t ValidateExtension(ValidationState_t& _, const Instruction* inst) {
  std::string extension = GetExtensionString(&(inst->c_inst()));
  if (_.version() < SPV_SPIRV_VERSION_WORD(1, 3)) {
    if (extension == ExtensionToString(kSPV_KHR_vulkan_memory_model) ||
        extension ==
            ExtensionToString(kSPV_QCOM_cooperative_matrix_conversion)) {
      return _.diag(SPV_ERROR_WRONG_VERSION, inst)
             << extension << " extension requires SPIR-V version 1.3 or later.";
    }
  }
  if (_.version() < SPV_SPIRV_VERSION_WORD(1, 4)) {
    if (extension ==
            ExtensionToString(kSPV_KHR_workgroup_memory_explicit_layout) ||
        extension == ExtensionToString(kSPV_KHR_opacity_micromap) ||
        extension == ExtensionToString(kSPV_EXT_mesh_shader) ||
        extension == ExtensionToString(kSPV_NV_shader_invocation_reorder) ||
        extension == ExtensionToString(kSPV_EXT_shader_invocation_reorder) ||
        extension ==
            ExtensionToString(kSPV_NV_cluster_acceleration_structure) ||
        extension == ExtensionToString(kSPV_NV_linear_swept_spheres) ||
        extension == ExtensionToString(kSPV_QCOM_image_processing) ||
        extension == ExtensionToString(kSPV_QCOM_image_processing2)) {
      return _.diag(SPV_ERROR_WRONG_VERSION, inst)
             << extension << " extension requires SPIR-V version 1.4 or later.";
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstImport(ValidationState_t& _,
                                   const Instruction* inst) {
  const auto name_id = 1;
  const std::string name = inst->GetOperandAs<std::string>(name_id);
  if (_.version() <= SPV_SPIRV_VERSION_WORD(1, 5) &&
      !_.HasExtension(kSPV_KHR_non_semantic_info)) {
    if (name.find("NonSemantic.") == 0) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic extended instruction "
                "sets cannot be declared "
                "without SPV_KHR_non_semantic_info. (This can also be fixed "
                "having SPIR-V 1.6 or later)";
    }
  }

  // Validate the version suffix of a NonSemantic.Shader.DebugInfo import.
  // Accept any version >= kNSDIMinVersion; no upper bound is imposed because
  // later versions are backward-compatible supersets of earlier ones.
  const std::string nsdi_prefix = "NonSemantic.Shader.DebugInfo.";
  if (name.find(nsdi_prefix) == 0) {
    static const uint32_t kNSDIMinVersion = 100;
    auto version_string = name.substr(nsdi_prefix.size());
    if (version_string.empty()) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Shader.DebugInfo import does not encode the "
                "version correctly";
    }
    char* end_ptr;
    uint32_t ver = static_cast<uint32_t>(
        std::strtoul(version_string.c_str(), &end_ptr, 10));
    if (end_ptr && *end_ptr != '\0') {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Shader.DebugInfo import does not encode the "
                "version correctly";
    }
    if (ver < kNSDIMinVersion) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Shader.DebugInfo import version " << ver
             << " is below the minimum supported version " << kNSDIMinVersion;
    }

    _.RegisterShaderDebugInfo(inst->id());
  }

  const std::string nsgdi_prefix = "NonSemantic.Graph.DebugInfo.";
  if (name.find(nsgdi_prefix) == 0) {
    auto version_string = name.substr(nsgdi_prefix.size());
    if (version_string.empty()) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Graph.DebugInfo import does not encode the "
                "version correctly";
    }
    char* end_ptr;
    uint32_t ver = static_cast<uint32_t>(
        std::strtoul(version_string.c_str(), &end_ptr, 10));
    if (end_ptr && *end_ptr != '\0') {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Graph.DebugInfo import does not encode the "
                "version correctly";
    }
    if (ver == 0 || ver > NonSemanticGraphDebugInfoRevision) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Graph.DebugInfo import version " << ver
             << " is not supported";
    }
    if (!_.HasExtension(kSPV_ARM_graph)) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "NonSemantic.Graph.DebugInfo requires SPV_ARM_graph";
    }
  }

  const std::string arm_ml_ops_prefix = "Arm.ExperimentalMLOperations.";
  if (name.find(arm_ml_ops_prefix) == 0) {
    auto version_string = name.substr(arm_ml_ops_prefix.size());
    if (version_string.empty()) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "Missing Arm.ExperimentalMLOperations import version";
    }
    char* end_ptr;
    uint32_t ver = static_cast<uint32_t>(
        std::strtoul(version_string.c_str(), &end_ptr, 10));
    if (end_ptr && *end_ptr != '\0') {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "Arm.ExperimentalMLOperations import does not encode the "
                "version correctly";
    }
    if (ver == 0 || ver > ArmExperimentalMLOperationsRevision) {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "Unknown Arm.ExperimentalMLOperations import version";
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstGlslStd450(ValidationState_t& _,
                                       const Instruction* inst) {
  const uint32_t result_type = inst->type_id();
  const uint32_t num_operands = static_cast<uint32_t>(inst->operands().size());

  const uint32_t ext_inst_index = inst->word(4);
  const GLSLstd450 ext_inst_key = GLSLstd450(ext_inst_index);
  switch (ext_inst_key) {
    case GLSLstd450Round:
    case GLSLstd450RoundEven:
    case GLSLstd450FAbs:
    case GLSLstd450Trunc:
    case GLSLstd450FSign:
    case GLSLstd450Floor:
    case GLSLstd450Ceil:
    case GLSLstd450Fract:
    case GLSLstd450Sqrt:
    case GLSLstd450InverseSqrt:
    case GLSLstd450FMin:
    case GLSLstd450FMax:
    case GLSLstd450FClamp:
    case GLSLstd450FMix:
    case GLSLstd450Step:
    case GLSLstd450SmoothStep:
    case GLSLstd450Fma:
    case GLSLstd450Normalize:
    case GLSLstd450FaceForward:
    case GLSLstd450Reflect:
    case GLSLstd450NMin:
    case GLSLstd450NMax:
    case GLSLstd450NClamp: {
      bool supportsCoopVec =
          (ext_inst_key == GLSLstd450FMin || ext_inst_key == GLSLstd450FMax ||
           ext_inst_key == GLSLstd450FClamp || ext_inst_key == GLSLstd450NMin ||
           ext_inst_key == GLSLstd450NMax || ext_inst_key == GLSLstd450NClamp ||
           ext_inst_key == GLSLstd450Step || ext_inst_key == GLSLstd450Fma);

      if (!_.IsFloatScalarOrVectorType(result_type) &&
          !(supportsCoopVec && _.IsFloatCooperativeVectorNVType(result_type))) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case GLSLstd450SAbs:
    case GLSLstd450SSign:
    case GLSLstd450UMin:
    case GLSLstd450SMin:
    case GLSLstd450UMax:
    case GLSLstd450SMax:
    case GLSLstd450UClamp:
    case GLSLstd450SClamp:
    case GLSLstd450FindILsb:
    case GLSLstd450FindUMsb:
    case GLSLstd450FindSMsb: {
      bool supportsCoopVec =
          (ext_inst_key == GLSLstd450UMin || ext_inst_key == GLSLstd450UMax ||
           ext_inst_key == GLSLstd450UClamp || ext_inst_key == GLSLstd450SMin ||
           ext_inst_key == GLSLstd450SMax || ext_inst_key == GLSLstd450SClamp);

      if (!_.IsIntScalarOrVectorType(result_type) &&
          !(supportsCoopVec && _.IsIntCooperativeVectorNVType(result_type))) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int scalar or vector type";
      }

      const uint32_t result_type_bit_width = _.GetBitWidth(result_type);
      const uint32_t result_type_dimension = _.GetDimension(result_type);

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (!operand_type ||
            (!_.IsIntScalarOrVectorType(operand_type) &&
             !(supportsCoopVec &&
               _.IsIntCooperativeVectorNVType(operand_type)))) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected all operands to be int scalars or vectors";
        }

        if (result_type_dimension != _.GetDimension(operand_type)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected all operands to have the same dimension as "
                 << "Result Type";
        }

        if (result_type_bit_width != _.GetBitWidth(operand_type)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected all operands to have the same bit width as "
                 << "Result Type";
        }

        if (ext_inst_key == GLSLstd450FindUMsb ||
            ext_inst_key == GLSLstd450FindSMsb) {
          if (result_type_bit_width != 32) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": "
                   << "this instruction is currently limited to 32-bit width "
                   << "components";
          }
        }
      }
      break;
    }

    case GLSLstd450Radians:
    case GLSLstd450Degrees:
    case GLSLstd450Sin:
    case GLSLstd450Cos:
    case GLSLstd450Tan:
    case GLSLstd450Asin:
    case GLSLstd450Acos:
    case GLSLstd450Atan:
    case GLSLstd450Sinh:
    case GLSLstd450Cosh:
    case GLSLstd450Tanh:
    case GLSLstd450Asinh:
    case GLSLstd450Acosh:
    case GLSLstd450Atanh:
    case GLSLstd450Exp:
    case GLSLstd450Exp2:
    case GLSLstd450Log:
    case GLSLstd450Log2:
    case GLSLstd450Atan2:
    case GLSLstd450Pow: {
      bool supportsCoopVec =
          (ext_inst_key == GLSLstd450Atan || ext_inst_key == GLSLstd450Tanh ||
           ext_inst_key == GLSLstd450Exp || ext_inst_key == GLSLstd450Log);

      if (!_.IsFloatScalarOrVectorType(result_type) &&
          !(supportsCoopVec && _.IsFloatCooperativeVectorNVType(result_type))) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 16 or 32-bit scalar or "
                  "vector float type";
      }

      const uint32_t result_type_bit_width = _.GetBitWidth(result_type);
      if (result_type_bit_width != 16 && result_type_bit_width != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 16 or 32-bit scalar or "
                  "vector float type";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case GLSLstd450Determinant: {
      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      uint32_t num_rows = 0;
      uint32_t num_cols = 0;
      uint32_t col_type = 0;
      uint32_t component_type = 0;
      if (!_.GetMatrixTypeInfo(x_type, &num_rows, &num_cols, &col_type,
                               &component_type) ||
          num_rows != num_cols) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to be a square matrix";
      }

      if (result_type != component_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X component type to be equal to "
               << "Result Type";
      }
      break;
    }

    case GLSLstd450MatrixInverse: {
      uint32_t num_rows = 0;
      uint32_t num_cols = 0;
      uint32_t col_type = 0;
      uint32_t component_type = 0;
      if (!_.GetMatrixTypeInfo(result_type, &num_rows, &num_cols, &col_type,
                               &component_type) ||
          num_rows != num_cols) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a square matrix";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (result_type != x_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }
      break;
    }

    case GLSLstd450Modf: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or vector float type";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      const uint32_t i_type = _.GetOperandTypeId(inst, 5);

      if (x_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }

      spv::StorageClass i_storage_class;
      uint32_t i_data_type = 0;
      if (!_.GetPointerTypeInfo(i_type, &i_data_type, &i_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand I to be a pointer";
      }

      if (i_data_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand I data type to be equal to Result Type";
      }

      break;
    }

    case GLSLstd450ModfStruct: {
      std::vector<uint32_t> result_types;
      if (!_.GetStructMemberTypes(result_type, &result_types) ||
          result_types.size() != 2 ||
          !_.IsFloatScalarOrVectorType(result_types[0]) ||
          result_types[1] != result_types[0]) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a struct with two identical "
               << "scalar or vector float type members";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (x_type != result_types[0]) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to members of "
               << "Result Type struct";
      }
      break;
    }

    case GLSLstd450Frexp: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or vector float type";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      const uint32_t exp_type = _.GetOperandTypeId(inst, 5);

      if (x_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }

      spv::StorageClass exp_storage_class;
      uint32_t exp_data_type = 0;
      if (!_.GetPointerTypeInfo(exp_type, &exp_data_type, &exp_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Exp to be a pointer";
      }

      if (!_.IsIntScalarOrVectorType(exp_data_type) ||
          (!_.HasExtension(kSPV_AMD_gpu_shader_int16) &&
           _.GetBitWidth(exp_data_type) != 32) ||
          (_.HasExtension(kSPV_AMD_gpu_shader_int16) &&
           _.GetBitWidth(exp_data_type) != 16 &&
           _.GetBitWidth(exp_data_type) != 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Exp data type to be a "
               << (_.HasExtension(kSPV_AMD_gpu_shader_int16)
                       ? "16-bit or 32-bit "
                       : "32-bit ")
               << "int scalar or vector type";
      }

      if (_.GetDimension(result_type) != _.GetDimension(exp_data_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Exp data type to have the same component "
               << "number as Result Type";
      }

      break;
    }

    case GLSLstd450Ldexp: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or vector float type";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      const uint32_t exp_type = _.GetOperandTypeId(inst, 5);

      if (x_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }

      if (!_.IsIntScalarOrVectorType(exp_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Exp to be a 32-bit int scalar "
               << "or vector type";
      }

      if (_.GetDimension(result_type) != _.GetDimension(exp_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Exp to have the same component "
               << "number as Result Type";
      }

      break;
    }

    case GLSLstd450FrexpStruct: {
      std::vector<uint32_t> result_types;
      if (!_.GetStructMemberTypes(result_type, &result_types) ||
          result_types.size() != 2 ||
          !_.IsFloatScalarOrVectorType(result_types[0]) ||
          !_.IsIntScalarOrVectorType(result_types[1]) ||
          (!_.HasExtension(kSPV_AMD_gpu_shader_int16) &&
           _.GetBitWidth(result_types[1]) != 32) ||
          (_.HasExtension(kSPV_AMD_gpu_shader_int16) &&
           _.GetBitWidth(result_types[1]) != 16 &&
           _.GetBitWidth(result_types[1]) != 32) ||
          _.GetDimension(result_types[0]) != _.GetDimension(result_types[1])) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a struct with two members, "
               << "first member a float scalar or vector, second member a "
               << (_.HasExtension(kSPV_AMD_gpu_shader_int16)
                       ? "16-bit or 32-bit "
                       : "32-bit ")
               << "int scalar or vector with the same number of "
               << "components as the first member";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (x_type != result_types[0]) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to the first member "
               << "of Result Type struct";
      }
      break;
    }

    case GLSLstd450PackSnorm4x8:
    case GLSLstd450PackUnorm4x8: {
      if (!_.IsIntScalarType(result_type, 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be 32-bit int scalar type";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatVectorType(v_type) || _.GetDimension(v_type) != 4 ||
          _.GetBitWidth(v_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand V to be a 32-bit float vector of size 4";
      }
      break;
    }

    case GLSLstd450PackSnorm2x16:
    case GLSLstd450PackUnorm2x16:
    case GLSLstd450PackHalf2x16: {
      if (!_.IsIntScalarType(result_type, 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be 32-bit int scalar type";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatVectorType(v_type) || _.GetDimension(v_type) != 2 ||
          _.GetBitWidth(v_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand V to be a 32-bit float vector of size 2";
      }
      break;
    }

    case GLSLstd450PackDouble2x32: {
      if (!_.IsFloatScalarType(result_type, 64)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be 64-bit float scalar type";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsIntVectorType(v_type) || _.GetDimension(v_type) != 2 ||
          _.GetBitWidth(v_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand V to be a 32-bit int vector of size 2";
      }
      break;
    }

    case GLSLstd450UnpackSnorm4x8:
    case GLSLstd450UnpackUnorm4x8: {
      if (!_.IsFloatVectorType(result_type) ||
          _.GetDimension(result_type) != 4 ||
          _.GetBitWidth(result_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit float vector of size "
                  "4";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsIntScalarType(v_type, 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a 32-bit int scalar";
      }
      break;
    }

    case GLSLstd450UnpackSnorm2x16:
    case GLSLstd450UnpackUnorm2x16:
    case GLSLstd450UnpackHalf2x16: {
      if (!_.IsFloatVectorType(result_type) ||
          _.GetDimension(result_type) != 2 ||
          _.GetBitWidth(result_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit float vector of size "
                  "2";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsIntScalarType(v_type, 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a 32-bit int scalar";
      }
      break;
    }

    case GLSLstd450UnpackDouble2x32: {
      if (!_.IsIntVectorType(result_type) || _.GetDimension(result_type) != 2 ||
          _.GetBitWidth(result_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit int vector of size "
                  "2";
      }

      const uint32_t v_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarType(v_type, 64)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand V to be a 64-bit float scalar";
      }
      break;
    }

    case GLSLstd450Length: {
      if (!_.IsFloatScalarType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar type";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarOrVectorType(x_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to be of float scalar or vector type";
      }

      if (result_type != _.GetComponentType(x_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X component type to be equal to Result "
                  "Type";
      }
      break;
    }

    case GLSLstd450Distance: {
      if (!_.IsFloatScalarType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar type";
      }

      const uint32_t p0_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarOrVectorType(p0_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P0 to be of float scalar or vector type";
      }

      if (result_type != _.GetComponentType(p0_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P0 component type to be equal to "
               << "Result Type";
      }

      const uint32_t p1_type = _.GetOperandTypeId(inst, 5);
      if (!_.IsFloatScalarOrVectorType(p1_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P1 to be of float scalar or vector type";
      }

      if (result_type != _.GetComponentType(p1_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P1 component type to be equal to "
               << "Result Type";
      }

      if (_.GetDimension(p0_type) != _.GetDimension(p1_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operands P0 and P1 to have the same number of "
               << "components";
      }
      break;
    }

    case GLSLstd450Cross: {
      if (!_.IsFloatVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float vector type";
      }

      if (_.GetDimension(result_type) != 3) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have 3 components";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      const uint32_t y_type = _.GetOperandTypeId(inst, 5);

      if (x_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }

      if (y_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Y type to be equal to Result Type";
      }
      break;
    }

    case GLSLstd450Refract: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t i_type = _.GetOperandTypeId(inst, 4);
      const uint32_t n_type = _.GetOperandTypeId(inst, 5);
      const uint32_t eta_type = _.GetOperandTypeId(inst, 6);

      if (result_type != i_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand I to be of type equal to Result Type";
      }

      if (result_type != n_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand N to be of type equal to Result Type";
      }

      if (!_.IsFloatScalarType(eta_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Eta to be a float scalar";
      }
      break;
    }

    case GLSLstd450InterpolateAtCentroid:
    case GLSLstd450InterpolateAtSample:
    case GLSLstd450InterpolateAtOffset: {
      if (!_.HasCapability(spv::Capability::InterpolationFunction)) {
        return _.diag(SPV_ERROR_INVALID_CAPABILITY, inst)
               << GetExtInstName(_, inst)
               << " requires capability InterpolationFunction";
      }

      if (!_.IsFloatScalarOrVectorType(result_type) ||
          (_.GetBitWidth(result_type) != 32 &&
           (!_.HasExtension(kSPV_AMD_gpu_shader_half_float) ||
            _.GetBitWidth(result_type) != 16))) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a "
               << (_.HasExtension(kSPV_AMD_gpu_shader_half_float)
                       ? "16-bit or 32-bit "
                       : "32-bit ")
               << "float scalar or vector type";
      }

      // If HLSL legalization and first operand is an OpLoad, use load
      // pointer as the interpolant lvalue. Else use interpolate first
      // operand.
      uint32_t interp_id = inst->GetOperandAs<uint32_t>(4);
      auto* interp_inst = _.FindDef(interp_id);
      uint32_t interpolant_type = (_.options()->before_hlsl_legalization &&
                                   interp_inst->opcode() == spv::Op::OpLoad)
                                      ? _.GetOperandTypeId(interp_inst, 2)
                                      : _.GetOperandTypeId(inst, 4);

      spv::StorageClass interpolant_storage_class;
      uint32_t interpolant_data_type = 0;
      if (!_.GetPointerTypeInfo(interpolant_type, &interpolant_data_type,
                                &interpolant_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Interpolant to be a pointer";
      }

      if (result_type != interpolant_data_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Interpolant data type to be equal to Result Type";
      }

      if (interpolant_storage_class != spv::StorageClass::Input) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Interpolant storage class to be Input";
      }

      if (ext_inst_key == GLSLstd450InterpolateAtSample) {
        const uint32_t sample_type = _.GetOperandTypeId(inst, 5);
        if (!_.IsIntScalarType(sample_type, 32)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Sample to be 32-bit integer";
        }
      }

      if (ext_inst_key == GLSLstd450InterpolateAtOffset) {
        const uint32_t offset_type = _.GetOperandTypeId(inst, 5);
        if (!_.IsFloatVectorType(offset_type) ||
            _.GetDimension(offset_type) != 2 ||
            (_.GetBitWidth(offset_type) != 32 &&
             (!_.HasExtension(kSPV_AMD_gpu_shader_half_float) ||
              _.GetBitWidth(offset_type) != 16))) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Offset to be a vector of 2 "
                 << (_.HasExtension(kSPV_AMD_gpu_shader_half_float)
                         ? "16-bit or 32-bit "
                         : "32-bit ")
                 << "floats";
        }
      }

      _.function(inst->function()->id())
          ->RegisterExecutionModelLimitation(
              spv::ExecutionModel::Fragment,
              GetExtInstName(_, inst) +
                  std::string(" requires Fragment execution model"));
      break;
    }

    case GLSLstd450IMix: {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "Extended instruction GLSLstd450IMix is not supported";
    }

    case GLSLstd450Bad: {
      return _.diag(SPV_ERROR_INVALID_DATA, inst)
             << "Encountered extended instruction GLSLstd450Bad";
    }

    case GLSLstd450Count: {
      assert(0);
      break;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstOpenClStd(ValidationState_t& _,
                                      const Instruction* inst) {
  const uint32_t result_type = inst->type_id();
  const uint32_t num_operands = static_cast<uint32_t>(inst->operands().size());
  const uint32_t ext_inst_index = inst->word(4);
  const OpenCLLIB::Entrypoints ext_inst_key =
      OpenCLLIB::Entrypoints(ext_inst_index);
  switch (ext_inst_key) {
    case OpenCLLIB::Acos:
    case OpenCLLIB::Acosh:
    case OpenCLLIB::Acospi:
    case OpenCLLIB::Asin:
    case OpenCLLIB::Asinh:
    case OpenCLLIB::Asinpi:
    case OpenCLLIB::Atan:
    case OpenCLLIB::Atan2:
    case OpenCLLIB::Atanh:
    case OpenCLLIB::Atanpi:
    case OpenCLLIB::Atan2pi:
    case OpenCLLIB::Cbrt:
    case OpenCLLIB::Ceil:
    case OpenCLLIB::Copysign:
    case OpenCLLIB::Cos:
    case OpenCLLIB::Cosh:
    case OpenCLLIB::Cospi:
    case OpenCLLIB::Erfc:
    case OpenCLLIB::Erf:
    case OpenCLLIB::Exp:
    case OpenCLLIB::Exp2:
    case OpenCLLIB::Exp10:
    case OpenCLLIB::Expm1:
    case OpenCLLIB::Fabs:
    case OpenCLLIB::Fdim:
    case OpenCLLIB::Floor:
    case OpenCLLIB::Fma:
    case OpenCLLIB::Fmax:
    case OpenCLLIB::Fmin:
    case OpenCLLIB::Fmod:
    case OpenCLLIB::Hypot:
    case OpenCLLIB::Lgamma:
    case OpenCLLIB::Log:
    case OpenCLLIB::Log2:
    case OpenCLLIB::Log10:
    case OpenCLLIB::Log1p:
    case OpenCLLIB::Logb:
    case OpenCLLIB::Mad:
    case OpenCLLIB::Maxmag:
    case OpenCLLIB::Minmag:
    case OpenCLLIB::Nextafter:
    case OpenCLLIB::Pow:
    case OpenCLLIB::Powr:
    case OpenCLLIB::Remainder:
    case OpenCLLIB::Rint:
    case OpenCLLIB::Round:
    case OpenCLLIB::Rsqrt:
    case OpenCLLIB::Sin:
    case OpenCLLIB::Sinh:
    case OpenCLLIB::Sinpi:
    case OpenCLLIB::Sqrt:
    case OpenCLLIB::Tan:
    case OpenCLLIB::Tanh:
    case OpenCLLIB::Tanpi:
    case OpenCLLIB::Tgamma:
    case OpenCLLIB::Trunc:
    case OpenCLLIB::Half_cos:
    case OpenCLLIB::Half_divide:
    case OpenCLLIB::Half_exp:
    case OpenCLLIB::Half_exp2:
    case OpenCLLIB::Half_exp10:
    case OpenCLLIB::Half_log:
    case OpenCLLIB::Half_log2:
    case OpenCLLIB::Half_log10:
    case OpenCLLIB::Half_powr:
    case OpenCLLIB::Half_recip:
    case OpenCLLIB::Half_rsqrt:
    case OpenCLLIB::Half_sin:
    case OpenCLLIB::Half_sqrt:
    case OpenCLLIB::Half_tan:
    case OpenCLLIB::Native_cos:
    case OpenCLLIB::Native_divide:
    case OpenCLLIB::Native_exp:
    case OpenCLLIB::Native_exp2:
    case OpenCLLIB::Native_exp10:
    case OpenCLLIB::Native_log:
    case OpenCLLIB::Native_log2:
    case OpenCLLIB::Native_log10:
    case OpenCLLIB::Native_powr:
    case OpenCLLIB::Native_recip:
    case OpenCLLIB::Native_rsqrt:
    case OpenCLLIB::Native_sin:
    case OpenCLLIB::Native_sqrt:
    case OpenCLLIB::Native_tan:
    case OpenCLLIB::FClamp:
    case OpenCLLIB::Degrees:
    case OpenCLLIB::FMax_common:
    case OpenCLLIB::FMin_common:
    case OpenCLLIB::Mix:
    case OpenCLLIB::Radians:
    case OpenCLLIB::Step:
    case OpenCLLIB::Smoothstep:
    case OpenCLLIB::Sign: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case OpenCLLIB::Fract:
    case OpenCLLIB::Modf:
    case OpenCLLIB::Sincos: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (result_type != x_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected type of operand X to be equal to Result Type";
      }

      const uint32_t p_type = _.GetOperandTypeId(inst, 5);
      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected the last operand to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected storage class of the pointer to be Generic, "
                  "CrossWorkgroup, Workgroup or Function";
      }

      if (!_.ContainsUntypedPointer(p_type) && result_type != p_data_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected data type of the pointer to be equal to Result "
                  "Type";
      }
      break;
    }

    case OpenCLLIB::Frexp:
    case OpenCLLIB::Lgamma_r:
    case OpenCLLIB::Remquo: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      uint32_t operand_index = 4;
      const uint32_t x_type = _.GetOperandTypeId(inst, operand_index++);
      if (result_type != x_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected type of operand X to be equal to Result Type";
      }

      if (ext_inst_key == OpenCLLIB::Remquo) {
        const uint32_t y_type = _.GetOperandTypeId(inst, operand_index++);
        if (result_type != y_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected type of operand Y to be equal to Result Type";
        }
      }

      const uint32_t p_type = _.GetOperandTypeId(inst, operand_index++);
      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected the last operand to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected storage class of the pointer to be Generic, "
                  "CrossWorkgroup, Workgroup or Function";
      }

      if ((!_.IsIntScalarOrVectorType(p_data_type) ||
           _.GetBitWidth(p_data_type) != 32) &&
          !_.ContainsUntypedPointer(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected data type of the pointer to be a 32-bit int "
                  "scalar or vector type";
      }

      if (!_.ContainsUntypedPointer(p_type) &&
          _.GetDimension(p_data_type) != num_components) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected data type of the pointer to have the same number "
                  "of components as Result Type";
      }
      break;
    }

    case OpenCLLIB::Ilogb: {
      if (!_.IsIntScalarOrVectorType(result_type) ||
          _.GetBitWidth(result_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit int scalar or vector "
                  "type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarOrVectorType(x_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to be a float scalar or vector";
      }

      if (_.GetDimension(x_type) != num_components) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to have the same number of components "
                  "as Result Type";
      }
      break;
    }

    case OpenCLLIB::Ldexp:
    case OpenCLLIB::Pown:
    case OpenCLLIB::Rootn: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      if (result_type != x_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected type of operand X to be equal to Result Type";
      }

      const uint32_t exp_type = _.GetOperandTypeId(inst, 5);
      if (!_.IsIntScalarOrVectorType(exp_type) ||
          _.GetBitWidth(exp_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected the exponent to be a 32-bit int scalar or vector";
      }

      if (_.GetDimension(exp_type) != num_components) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected the exponent to have the same number of "
                  "components as Result Type";
      }
      break;
    }

    case OpenCLLIB::Nan: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t nancode_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsIntScalarOrVectorType(nancode_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Nancode to be an int scalar or vector type";
      }

      if (_.GetDimension(nancode_type) != num_components) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Nancode to have the same number of components as "
                  "Result Type";
      }

      if (_.GetBitWidth(result_type) != _.GetBitWidth(nancode_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Nancode to have the same bit width as Result "
                  "Type";
      }
      break;
    }

    case OpenCLLIB::SAbs:
    case OpenCLLIB::SAbs_diff:
    case OpenCLLIB::SAdd_sat:
    case OpenCLLIB::UAdd_sat:
    case OpenCLLIB::SHadd:
    case OpenCLLIB::UHadd:
    case OpenCLLIB::SRhadd:
    case OpenCLLIB::URhadd:
    case OpenCLLIB::SClamp:
    case OpenCLLIB::UClamp:
    case OpenCLLIB::Clz:
    case OpenCLLIB::Ctz:
    case OpenCLLIB::SMad_hi:
    case OpenCLLIB::UMad_sat:
    case OpenCLLIB::SMad_sat:
    case OpenCLLIB::SMax:
    case OpenCLLIB::UMax:
    case OpenCLLIB::SMin:
    case OpenCLLIB::UMin:
    case OpenCLLIB::SMul_hi:
    case OpenCLLIB::Rotate:
    case OpenCLLIB::SSub_sat:
    case OpenCLLIB::USub_sat:
    case OpenCLLIB::Popcount:
    case OpenCLLIB::UAbs:
    case OpenCLLIB::UAbs_diff:
    case OpenCLLIB::UMul_hi:
    case OpenCLLIB::UMad_hi: {
      if (!_.IsIntScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case OpenCLLIB::U_Upsample:
    case OpenCLLIB::S_Upsample: {
      if (!_.IsIntScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int scalar or vector "
                  "type";
      }

      const uint32_t result_num_components = _.GetDimension(result_type);
      if (result_num_components > 4 && result_num_components != 8 &&
          result_num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t result_bit_width = _.GetBitWidth(result_type);
      if (result_bit_width != 16 && result_bit_width != 32 &&
          result_bit_width != 64) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected bit width of Result Type components to be 16, 32 "
                  "or 64";
      }

      const uint32_t hi_type = _.GetOperandTypeId(inst, 4);
      const uint32_t lo_type = _.GetOperandTypeId(inst, 5);

      if (hi_type != lo_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Hi and Lo operands to have the same type";
      }

      if (result_num_components != _.GetDimension(hi_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Hi and Lo operands to have the same number of "
                  "components as Result Type";
      }

      if (result_bit_width != 2 * _.GetBitWidth(hi_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected bit width of components of Hi and Lo operands to "
                  "be half of the bit width of components of Result Type";
      }
      break;
    }

    case OpenCLLIB::SMad24:
    case OpenCLLIB::UMad24:
    case OpenCLLIB::SMul24:
    case OpenCLLIB::UMul24: {
      if (!_.IsIntScalarOrVectorType(result_type) ||
          _.GetBitWidth(result_type) != 32) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit int scalar or vector "
                  "type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case OpenCLLIB::Cross: {
      if (!_.IsFloatVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components != 3 && num_components != 4) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have 3 or 4 components";
      }

      const uint32_t x_type = _.GetOperandTypeId(inst, 4);
      const uint32_t y_type = _.GetOperandTypeId(inst, 5);

      if (x_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X type to be equal to Result Type";
      }

      if (y_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Y type to be equal to Result Type";
      }
      break;
    }

    case OpenCLLIB::Distance:
    case OpenCLLIB::Fast_distance: {
      if (!_.IsFloatScalarType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar type";
      }

      const uint32_t p0_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarOrVectorType(p0_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P0 to be of float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(p0_type);
      if (num_components > 4) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P0 to have no more than 4 components";
      }

      if (result_type != _.GetComponentType(p0_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P0 component type to be equal to "
               << "Result Type";
      }

      const uint32_t p1_type = _.GetOperandTypeId(inst, 5);
      if (p0_type != p1_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operands P0 and P1 to be of the same type";
      }
      break;
    }

    case OpenCLLIB::Length:
    case OpenCLLIB::Fast_length: {
      if (!_.IsFloatScalarType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar type";
      }

      const uint32_t p_type = _.GetOperandTypeId(inst, 4);
      if (!_.IsFloatScalarOrVectorType(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a float scalar or vector";
      }

      const uint32_t num_components = _.GetDimension(p_type);
      if (num_components > 4) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to have no more than 4 components";
      }

      if (result_type != _.GetComponentType(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P component type to be equal to Result "
                  "Type";
      }
      break;
    }

    case OpenCLLIB::Normalize:
    case OpenCLLIB::Fast_normalize: {
      if (!_.IsFloatScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar or vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have no more than 4 components";
      }

      const uint32_t p_type = _.GetOperandTypeId(inst, 4);
      if (p_type != result_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P type to be equal to Result Type";
      }
      break;
    }

    case OpenCLLIB::Bitselect: {
      if (!_.IsFloatScalarOrVectorType(result_type) &&
          !_.IsIntScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int or float scalar or "
                  "vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      for (uint32_t operand_index = 4; operand_index < num_operands;
           ++operand_index) {
        const uint32_t operand_type = _.GetOperandTypeId(inst, operand_index);
        if (result_type != operand_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected types of all operands to be equal to Result "
                    "Type";
        }
      }
      break;
    }

    case OpenCLLIB::Select: {
      if (!_.IsFloatScalarOrVectorType(result_type) &&
          !_.IsIntScalarOrVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int or float scalar or "
                  "vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t a_type = _.GetOperandTypeId(inst, 4);
      const uint32_t b_type = _.GetOperandTypeId(inst, 5);
      const uint32_t c_type = _.GetOperandTypeId(inst, 6);

      if (result_type != a_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand A type to be equal to Result Type";
      }

      if (result_type != b_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand B type to be equal to Result Type";
      }

      if (!_.IsIntScalarOrVectorType(c_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand C to be an int scalar or vector";
      }

      if (num_components != _.GetDimension(c_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand C to have the same number of components "
                  "as Result Type";
      }

      if (_.GetBitWidth(result_type) != _.GetBitWidth(c_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand C to have the same bit width as Result "
                  "Type";
      }
      break;
    }

    case OpenCLLIB::Vloadn: {
      if (!_.IsFloatVectorType(result_type) &&
          !_.IsIntVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int or float vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have 2, 3, 4, 8 or 16 components";
      }

      const uint32_t offset_type = _.GetOperandTypeId(inst, 4);
      const uint32_t p_type = _.GetOperandTypeId(inst, 5);

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(offset_type, size_t_bit_width)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Offset to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::UniformConstant &&
          p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P storage class to be UniformConstant, "
                  "Generic, CrossWorkgroup, Workgroup or Function";
      }

      if (_.GetComponentType(result_type) != p_data_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P data type to be equal to component "
                  "type of Result Type";
      }

      const uint32_t n_value = inst->word(7);
      if (num_components != n_value) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected literal N to be equal to the number of "
                  "components of Result Type";
      }
      break;
    }

    case OpenCLLIB::Vstoren: {
      if (_.GetIdOpcode(result_type) != spv::Op::OpTypeVoid) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << ": expected Result Type to be void";
      }

      const uint32_t data_type = _.GetOperandTypeId(inst, 4);
      const uint32_t offset_type = _.GetOperandTypeId(inst, 5);
      const uint32_t p_type = _.GetOperandTypeId(inst, 6);

      if (!_.IsFloatVectorType(data_type) && !_.IsIntVectorType(data_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Data to be an int or float vector";
      }

      const uint32_t num_components = _.GetDimension(data_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Data to have 2, 3, 4, 8 or 16 components";
      }

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(offset_type, size_t_bit_width)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Offset to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P storage class to be Generic, "
                  "CrossWorkgroup, Workgroup or Function";
      }

      if (_.GetComponentType(data_type) != p_data_type) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P data type to be equal to the type of "
                  "operand Data components";
      }
      break;
    }

    case OpenCLLIB::Vload_half: {
      if (!_.IsFloatScalarType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float scalar type";
      }

      const uint32_t offset_type = _.GetOperandTypeId(inst, 4);
      const uint32_t p_type = _.GetOperandTypeId(inst, 5);

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(offset_type, size_t_bit_width)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Offset to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::UniformConstant &&
          p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P storage class to be UniformConstant, "
                  "Generic, CrossWorkgroup, Workgroup or Function";
      }

      if ((!_.IsFloatScalarType(p_data_type, 16)) &&
          !_.ContainsUntypedPointer(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P data type to be 16-bit float scalar";
      }
      break;
    }

    case OpenCLLIB::Vload_halfn:
    case OpenCLLIB::Vloada_halfn: {
      if (!_.IsFloatVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a float vector type";
      }

      const uint32_t num_components = _.GetDimension(result_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have 2, 3, 4, 8 or 16 components";
      }

      const uint32_t offset_type = _.GetOperandTypeId(inst, 4);
      const uint32_t p_type = _.GetOperandTypeId(inst, 5);

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(offset_type, size_t_bit_width)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Offset to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::UniformConstant &&
          p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P storage class to be UniformConstant, "
                  "Generic, CrossWorkgroup, Workgroup or Function";
      }

      if ((!_.IsFloatScalarType(p_data_type, 16)) &&
          !_.ContainsUntypedPointer(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P data type to be 16-bit float scalar";
      }

      const uint32_t n_value = inst->word(7);
      if (num_components != n_value) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected literal N to be equal to the number of "
                  "components of Result Type";
      }
      break;
    }

    case OpenCLLIB::Vstore_half:
    case OpenCLLIB::Vstore_half_r:
    case OpenCLLIB::Vstore_halfn:
    case OpenCLLIB::Vstore_halfn_r:
    case OpenCLLIB::Vstorea_halfn:
    case OpenCLLIB::Vstorea_halfn_r: {
      if (_.GetIdOpcode(result_type) != spv::Op::OpTypeVoid) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << ": expected Result Type to be void";
      }

      const uint32_t data_type = _.GetOperandTypeId(inst, 4);
      const uint32_t offset_type = _.GetOperandTypeId(inst, 5);
      const uint32_t p_type = _.GetOperandTypeId(inst, 6);
      const uint32_t data_type_bit_width = _.GetBitWidth(data_type);

      if (ext_inst_key == OpenCLLIB::Vstore_half ||
          ext_inst_key == OpenCLLIB::Vstore_half_r) {
        if (!_.IsFloatScalarType(data_type) ||
            (data_type_bit_width != 32 && data_type_bit_width != 64)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Data to be a 32 or 64-bit float scalar";
        }
      } else {
        if (!_.IsFloatVectorType(data_type) ||
            (data_type_bit_width != 32 && data_type_bit_width != 64)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Data to be a 32 or 64-bit float vector";
        }

        const uint32_t num_components = _.GetDimension(data_type);
        if (num_components > 4 && num_components != 8 && num_components != 16) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Data to have 2, 3, 4, 8 or 16 components";
        }
      }

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(offset_type, size_t_bit_width)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Offset to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::Generic &&
          p_storage_class != spv::StorageClass::CrossWorkgroup &&
          p_storage_class != spv::StorageClass::Workgroup &&
          p_storage_class != spv::StorageClass::Function) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P storage class to be Generic, "
                  "CrossWorkgroup, Workgroup or Function";
      }

      if ((!_.IsFloatScalarType(p_data_type, 16)) &&
          !_.ContainsUntypedPointer(p_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand P data type to be 16-bit float scalar";
      }

      // Rounding mode enum is checked by assembler.
      break;
    }

    case OpenCLLIB::Shuffle:
    case OpenCLLIB::Shuffle2: {
      if (!_.IsFloatVectorType(result_type) &&
          !_.IsIntVectorType(result_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be an int or float vector type";
      }

      const uint32_t result_num_components = _.GetDimension(result_type);
      if (result_num_components != 2 && result_num_components != 4 &&
          result_num_components != 8 && result_num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to have 2, 4, 8 or 16 components";
      }

      uint32_t operand_index = 4;
      const uint32_t x_type = _.GetOperandTypeId(inst, operand_index++);

      if (ext_inst_key == OpenCLLIB::Shuffle2) {
        const uint32_t y_type = _.GetOperandTypeId(inst, operand_index++);
        if (x_type != y_type) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected operands X and Y to be of the same type";
        }
      }

      const uint32_t shuffle_mask_type =
          _.GetOperandTypeId(inst, operand_index++);

      if (!_.IsFloatVectorType(x_type) && !_.IsIntVectorType(x_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to be an int or float vector";
      }

      const uint32_t x_num_components = _.GetDimension(x_type);
      if (x_num_components != 2 && x_num_components != 4 &&
          x_num_components != 8 && x_num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X to have 2, 4, 8 or 16 components";
      }

      const uint32_t result_component_type = _.GetComponentType(result_type);

      if (result_component_type != _.GetComponentType(x_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand X and Result Type to have equal "
                  "component types";
      }

      if (!_.IsIntVectorType(shuffle_mask_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Shuffle Mask to be an int vector";
      }

      if (result_num_components != _.GetDimension(shuffle_mask_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Shuffle Mask to have the same number of "
                  "components as Result Type";
      }

      if (_.GetBitWidth(result_component_type) !=
          _.GetBitWidth(shuffle_mask_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Shuffle Mask components to have the same "
                  "bit width as Result Type components";
      }
      break;
    }

    case OpenCLLIB::Printf: {
      if (!_.IsIntScalarType(result_type, 32)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a 32-bit int type";
      }

      const uint32_t format_type = _.GetOperandTypeId(inst, 4);
      spv::StorageClass format_storage_class;
      uint32_t format_data_type = 0;
      if (!_.GetPointerTypeInfo(format_type, &format_data_type,
                                &format_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Format to be a pointer";
      }

      if (_.HasExtension(
              Extension::kSPV_EXT_relaxed_printf_string_address_space)) {
        if (format_storage_class != spv::StorageClass::UniformConstant &&
            // Extension SPV_EXT_relaxed_printf_string_address_space allows
            // format strings in Global, Local, Private and Generic address
            // spaces

            // Global
            format_storage_class != spv::StorageClass::CrossWorkgroup &&
            // Local
            format_storage_class != spv::StorageClass::Workgroup &&
            // Private
            format_storage_class != spv::StorageClass::Function &&
            // Generic
            format_storage_class != spv::StorageClass::Generic) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Format storage class to be UniformConstant, "
                    "Crossworkgroup, Workgroup, Function, or Generic";
        }
      } else {
        if (format_storage_class != spv::StorageClass::UniformConstant) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected Format storage class to be UniformConstant";
        }
      }

      // If pointer points to an array, get the type of an element
      if (_.IsIntArrayType(format_data_type))
        format_data_type = _.GetComponentType(format_data_type);

      if (!_.IsIntScalarType(format_data_type, 8) &&
          !_.ContainsUntypedPointer(format_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Format data type to be 8-bit int";
      }
      break;
    }

    case OpenCLLIB::Prefetch: {
      if (_.GetIdOpcode(result_type) != spv::Op::OpTypeVoid) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << ": expected Result Type to be void";
      }

      const uint32_t p_type = _.GetOperandTypeId(inst, 4);
      const uint32_t num_elements_type = _.GetOperandTypeId(inst, 5);

      spv::StorageClass p_storage_class;
      uint32_t p_data_type = 0;
      if (!_.GetPointerTypeInfo(p_type, &p_data_type, &p_storage_class)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Ptr to be a pointer";
      }

      if (p_storage_class != spv::StorageClass::CrossWorkgroup) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Ptr storage class to be CrossWorkgroup";
      }

      if (!_.IsFloatScalarOrVectorType(p_data_type) &&
          !_.IsIntScalarOrVectorType(p_data_type)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Ptr data type to be int or float scalar or "
                  "vector";
      }

      const uint32_t num_components = _.GetDimension(p_data_type);
      if (num_components > 4 && num_components != 8 && num_components != 16) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected Result Type to be a scalar or a vector with 2, "
                  "3, 4, 8 or 16 components";
      }

      const uint32_t size_t_bit_width = GetSizeTBitWidth(_);
      if (!size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst)
               << " can only be used with physical addressing models";
      }

      if (!_.IsIntScalarType(num_elements_type) ||
          _.GetBitWidth(num_elements_type) != size_t_bit_width) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": "
               << "expected operand Num Elements to be of type size_t ("
               << size_t_bit_width
               << "-bit integer for the addressing model used in the module)";
      }
      break;
    }
  }
  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstDebugInfo(ValidationState_t& _,
                                      const Instruction* inst) {
  const uint32_t result_type = inst->type_id();
  const uint32_t ext_inst_index = inst->word(4);
  if (!_.IsVoidType(result_type)) {
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": "
           << "expected result type must be a result id of " << "OpTypeVoid";
  }

  const spv_ext_inst_type_t ext_inst_type =
      spv_ext_inst_type_t(inst->ext_inst_type());
  const bool vulkanDebugInfo =
      ext_inst_type == SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100;

  auto num_words = inst->words().size();

  // Parse the declared NSDI version so optional-operand checks are strict
  // (num_words == n) for version kNSDIKnownVersion and lenient (num_words >= n)
  // for future versions that may add trailing operands.
  static const uint32_t kNSDIKnownVersion = NonSemanticShaderDebugInfoVersion;
  const uint32_t nsdi_version = vulkanDebugInfo ? GetNSDIVersion(_, inst) : 0;
  // True if the optional operand at word |n| is present and should be checked.
  auto has_optional_at = [&](uint32_t n) -> bool {
    return num_words >= n &&
           (nsdi_version > kNSDIKnownVersion || num_words == n);
  };

  // Handle any non-common NonSemanticShaderDebugInfo instructions.
  if (vulkanDebugInfo) {
    const NonSemanticShaderDebugInfoInstructions ext_inst_key =
        NonSemanticShaderDebugInfoInstructions(ext_inst_index);
    switch (ext_inst_key) {
      // The following block of instructions will be handled by the common
      // validation.
      case NonSemanticShaderDebugInfoDebugInfoNone:
      case NonSemanticShaderDebugInfoDebugCompilationUnit:
      case NonSemanticShaderDebugInfoDebugTypePointer:
      case NonSemanticShaderDebugInfoDebugTypeQualifier:
      case NonSemanticShaderDebugInfoDebugTypeArray:
      case NonSemanticShaderDebugInfoDebugTypeVector:
      case NonSemanticShaderDebugInfoDebugTypedef:
      case NonSemanticShaderDebugInfoDebugTypeFunction:
      case NonSemanticShaderDebugInfoDebugTypeEnum:
      case NonSemanticShaderDebugInfoDebugTypeComposite:
      case NonSemanticShaderDebugInfoDebugTypeMember:
      case NonSemanticShaderDebugInfoDebugTypeInheritance:
      case NonSemanticShaderDebugInfoDebugTypePtrToMember:
      case NonSemanticShaderDebugInfoDebugTypeTemplate:
      case NonSemanticShaderDebugInfoDebugTypeTemplateParameter:
      case NonSemanticShaderDebugInfoDebugTypeTemplateTemplateParameter:
      case NonSemanticShaderDebugInfoDebugTypeTemplateParameterPack:
      case NonSemanticShaderDebugInfoDebugGlobalVariable:
      case NonSemanticShaderDebugInfoDebugFunctionDeclaration:
      case NonSemanticShaderDebugInfoDebugFunction:
      case NonSemanticShaderDebugInfoDebugLexicalBlock:
      case NonSemanticShaderDebugInfoDebugLexicalBlockDiscriminator:
      case NonSemanticShaderDebugInfoDebugScope:
      case NonSemanticShaderDebugInfoDebugNoScope:
      case NonSemanticShaderDebugInfoDebugInlinedAt:
      case NonSemanticShaderDebugInfoDebugLocalVariable:
      case NonSemanticShaderDebugInfoDebugInlinedVariable:
      case NonSemanticShaderDebugInfoDebugValue:
      case NonSemanticShaderDebugInfoDebugOperation:
      case NonSemanticShaderDebugInfoDebugExpression:
      case NonSemanticShaderDebugInfoDebugMacroDef:
      case NonSemanticShaderDebugInfoDebugMacroUndef:
      case NonSemanticShaderDebugInfoDebugImportedEntity:
      case NonSemanticShaderDebugInfoDebugSource:
        break;

      // These checks are for operands that are different in
      // NonSemantic.Shader.DebugInfo
      case NonSemanticShaderDebugInfoDebugTypeBasic: {
        CHECK_CONST_UINT_OPERAND("Flags", 8);
        // Optional FPEncoding parameter (5th operand, word index 9)
        if (has_optional_at(10)) {
          CHECK_CONST_UINT_OPERAND("FPEncoding", 9);
        }
        break;
      }
      case NonSemanticShaderDebugInfoDebugDeclare: {
        for (uint32_t word_index = 8; word_index < num_words; ++word_index) {
          auto index_inst = _.FindDef(inst->word(word_index));
          auto type_id = index_inst != nullptr ? index_inst->type_id() : 0;
          if (type_id == 0 || !IsIntScalar(_, type_id, false, false))
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": "
                   << "expected index must be scalar integer";
        }
        break;
      }
      case NonSemanticShaderDebugInfoDebugTypeMatrix: {
        CHECK_DEBUG_OPERAND("Vector Type", CommonDebugInfoDebugTypeVector, 5);

        CHECK_CONST_UINT_OPERAND("Vector Count", 6);

        uint32_t vector_count = inst->word(6);
        uint64_t const_val;
        if (!_.EvalConstantValUint64(vector_count, &const_val)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": Vector Count must be 32-bit integer OpConstant";
        }

        vector_count = const_val & 0xffffffff;
        if (!vector_count || vector_count > 4) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": Vector Count must be positive "
                 << "integer less than or equal to 4";
        }
        break;
      }
      case NonSemanticShaderDebugInfoDebugTypeVectorIdEXT: {
        CHECK_NSDI_MIN_VERSION(NonSemanticShaderDebugInfoVersion);
        CHECK_DEBUG_OPERAND("Component Type", CommonDebugInfoDebugTypeBasic, 5);
        // Component Count may be OpSpecConstant when the cooperative vector
        // type uses a specialization constant for its size.
        CHECK_CONST_OR_SPEC_UINT_OPERAND("Component Count", 6);
        break;
      }
      case NonSemanticShaderDebugInfoDebugTypeCooperativeMatrixKHR: {
        CHECK_NSDI_MIN_VERSION(NonSemanticShaderDebugInfoVersion);
        CHECK_DEBUG_OPERAND("Component Type", CommonDebugInfoDebugTypeBasic, 5);
        // Scope, Rows, Columns, and Use may be OpSpecConstant when the
        // cooperative matrix type uses specialization constants.
        CHECK_CONST_OR_SPEC_UINT_OPERAND("Scope", 6);
        CHECK_CONST_OR_SPEC_UINT_OPERAND("Rows", 7);
        CHECK_CONST_OR_SPEC_UINT_OPERAND("Columns", 8);
        CHECK_CONST_OR_SPEC_UINT_OPERAND("Use", 9);
        break;
      }
      case NonSemanticShaderDebugInfoDebugFunctionDefinition: {
        CHECK_DEBUG_OPERAND("Function", CommonDebugInfoDebugFunction, 5);
        CHECK_OPERAND("Definition", spv::Op::OpFunction, 6);
        const auto* current_function = inst->function();
        if (current_function->first_block()->id() != inst->block()->id()) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": must be in the entry basic block of the function";
        }

        const uint32_t definition_id = inst->word(6);
        if (definition_id != current_function->id()) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": operand Definition must point to the OpFunction it is "
                    "inside";
        }
        break;
      }
      case NonSemanticShaderDebugInfoDebugLine: {
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 5);
        CHECK_CONST_UINT_OPERAND("Line Start", 6);
        CHECK_CONST_UINT_OPERAND("Line End", 7);
        CHECK_CONST_UINT_OPERAND("Column Start", 8);
        CHECK_CONST_UINT_OPERAND("Column End", 9);

        // above already validates if 32-bit and non-spec constant
        // but want to use EvalInt32IfConst to be consistent with other Eval
        // locations
        bool is_int32 = false, is_const_int32 = false;
        uint32_t line_start = 0;
        uint32_t line_end = 0;
        uint32_t column_start = 0;
        uint32_t column_end = 0;
        std::tie(is_int32, is_const_int32, line_start) =
            _.EvalInt32IfConst(inst->word(6));
        std::tie(is_int32, is_const_int32, line_end) =
            _.EvalInt32IfConst(inst->word(7));
        std::tie(is_int32, is_const_int32, column_start) =
            _.EvalInt32IfConst(inst->word(8));
        std::tie(is_int32, is_const_int32, column_end) =
            _.EvalInt32IfConst(inst->word(9));
        if (line_start == 0) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": operand Line Start (0) is not allowed, source lines "
                    "start at Line 1";
        } else if (line_end < line_start) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": operand Line End ("
                 << line_end << ") is less than Line Start (" << line_start
                 << ")";
        } else if (line_start == line_end && column_end < column_start) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": operand Column End ("
                 << column_end << ") is less than Column Start ("
                 << column_start << ") when Line Start equals Line End";
        }
        // Make sure Line is found in the DebugSource
        auto* debug_source_inst = _.FindDef(inst->word(5));
        const std::vector<uint32_t>& line_lengths =
            _.GetDebugSourceLineLength(debug_source_inst->id());
        if (!line_lengths.empty()) {
          if (line_end > line_lengths.size()) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": operand Line End ("
                   << line_end << ") is larger then the " << line_lengths.size()
                   << " lines found in the DebugSource text";
          }
          if (line_start == line_end) {
            const uint32_t line_length = line_lengths[line_end - 1];
            if (column_end > line_length) {
              return _.diag(SPV_ERROR_INVALID_DATA, inst)
                     << GetExtInstName(_, inst) << ": operand Column End ("
                     << column_end << ") is larger then Line " << line_end
                     << " column length of " << line_length
                     << " found in the DebugSource text";
            }
          } else {
            uint32_t line_length = line_lengths[line_start - 1];
            if (column_start > line_length) {
              return _.diag(SPV_ERROR_INVALID_DATA, inst)
                     << GetExtInstName(_, inst) << ": operand Column Start ("
                     << column_start << ") is larger then Line " << line_start
                     << " column length of " << line_length
                     << " found in the DebugSource text";
            }
            line_length = line_lengths[line_end - 1];
            if (column_end > line_length) {
              return _.diag(SPV_ERROR_INVALID_DATA, inst)
                     << GetExtInstName(_, inst) << ": operand Column End ("
                     << column_end << ") is larger then Line " << line_end
                     << " column length of " << line_length
                     << " found in the DebugSource text";
            }
          }
        }

        break;
      }
      case NonSemanticShaderDebugInfoDebugSourceContinued: {
        CHECK_OPERAND("Text", spv::Op::OpString, 5);
        // OpenCL didn't have a Continued version
        BuildDebugSourceLineLength(_, inst, ext_inst_index);
        break;
      }
      case NonSemanticShaderDebugInfoDebugBuildIdentifier: {
        CHECK_OPERAND("Identifier", spv::Op::OpString, 5);
        CHECK_CONST_UINT_OPERAND("Flags", 6);
        break;
      }
      case NonSemanticShaderDebugInfoDebugStoragePath: {
        CHECK_OPERAND("Path", spv::Op::OpString, 5);
        break;
      }
      case NonSemanticShaderDebugInfoDebugEntryPoint: {
        CHECK_DEBUG_OPERAND("Entry Point", CommonDebugInfoDebugFunction, 5);
        CHECK_DEBUG_OPERAND("Compilation Unit",
                            CommonDebugInfoDebugCompilationUnit, 6);
        CHECK_OPERAND("Compiler Signature", spv::Op::OpString, 7);
        CHECK_OPERAND("Command-line Arguments", spv::Op::OpString, 8);
        break;
      }

        // Has no additional checks
      case NonSemanticShaderDebugInfoDebugNoLine:
        break;
      case NonSemanticShaderDebugInfoInstructionsMax:
        assert(0);
        break;
    }
  }

  // Handle any non-common OpenCL insts, then common
  if (ext_inst_type != SPV_EXT_INST_TYPE_OPENCL_DEBUGINFO_100 ||
      OpenCLDebugInfo100Instructions(ext_inst_index) !=
          OpenCLDebugInfo100DebugModuleINTEL) {
    const CommonDebugInfoInstructions ext_inst_key =
        CommonDebugInfoInstructions(ext_inst_index);
    switch (ext_inst_key) {
      case CommonDebugInfoDebugInfoNone:
      case CommonDebugInfoDebugNoScope:
        break;
        // The binary parser validates the opcode for DebugInfoNone,
        // DebugNoScope, DebugOperation. We just check the parameters to
        // DebugOperation are properly constants for vulkan debug info.
      case CommonDebugInfoDebugOperation: {
        CHECK_CONST_UINT_OPERAND("Operation", 5);
        for (uint32_t i = 6; i < num_words; ++i) {
          CHECK_CONST_UINT_OPERAND("Operand", i);
        }
        break;
      }
      case CommonDebugInfoDebugCompilationUnit: {
        CHECK_CONST_UINT_OPERAND("Version", 5);
        CHECK_CONST_UINT_OPERAND("DWARF Version", 6);
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Language", 8);
        break;
      }
      case CommonDebugInfoDebugSource: {
        CHECK_OPERAND("File", spv::Op::OpString, 5);
        if (has_optional_at(7)) CHECK_OPERAND("Text", spv::Op::OpString, 6);
        BuildDebugSourceLineLength(_, inst, ext_inst_index);
        break;
      }
      case CommonDebugInfoDebugTypeBasic: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        CHECK_OPERAND("Size", spv::Op::OpConstant, 6);
        CHECK_CONST_UINT_OPERAND("Encoding", 7);
        break;
      }
      case CommonDebugInfoDebugTypePointer: {
        auto validate_base_type =
            ValidateOperandDebugType(_, "Base Type", inst, 5, false);
        if (validate_base_type != SPV_SUCCESS) return validate_base_type;
        CHECK_CONST_UINT_OPERAND("Storage Class", 6);
        CHECK_CONST_UINT_OPERAND("Flags", 7);
        break;
      }
      case CommonDebugInfoDebugTypeQualifier: {
        auto validate_base_type =
            ValidateOperandDebugType(_, "Base Type", inst, 5, false);
        if (validate_base_type != SPV_SUCCESS) return validate_base_type;
        CHECK_CONST_UINT_OPERAND("Type Qualifier", 6);
        break;
      }
      case CommonDebugInfoDebugTypeVector: {
        auto validate_base_type = ValidateOperandBaseType(_, inst, 5);
        if (validate_base_type != SPV_SUCCESS) return validate_base_type;

        CHECK_CONST_UINT_OPERAND("Component Count", 6);
        uint32_t component_count = inst->word(6);
        if (vulkanDebugInfo) {
          uint64_t const_val;
          if (!_.EvalConstantValUint64(component_count, &const_val)) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst)
                   << ": Component Count must be 32-bit integer OpConstant";
          }
          component_count = const_val & 0xffffffff;
        }

        if (!component_count || component_count > 4) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst)
                 << ": Component Count must be positive "
                 << "integer less than or equal to 4";
        }
        break;
      }
      case CommonDebugInfoDebugTypeArray: {
        auto validate_base_type =
            ValidateOperandDebugType(_, "Base Type", inst, 5, false);
        if (validate_base_type != SPV_SUCCESS) return validate_base_type;
        for (uint32_t i = 6; i < num_words; ++i) {
          bool invalid = false;
          auto* component_count = _.FindDef(inst->word(i));
          if (IsConstIntScalarTypeWith32Or64Bits(_, component_count)) {
            // TODO: We need a spec discussion for the runtime array for
            // OpenCL.
            if (!vulkanDebugInfo && !component_count->word(3)) {
              invalid = true;
            }
          } else if (vulkanDebugInfo && IsSpecConstIntScalarTypeWith32Or64Bits(
                                            _, component_count)) {
            // Spec constants are valid component counts for
            // NonSemantic.Shader.DebugInfo.
          } else if (component_count->words().size() > 6 &&
                     (CommonDebugInfoInstructions(component_count->word(4)) ==
                          CommonDebugInfoDebugLocalVariable ||
                      CommonDebugInfoInstructions(component_count->word(4)) ==
                          CommonDebugInfoDebugGlobalVariable)) {
            auto* component_count_type = _.FindDef(component_count->word(6));
            if (component_count_type->words().size() > 7) {
              uint32_t encoding = component_count_type->word(7);
              if (CommonDebugInfoInstructions(component_count_type->word(4)) !=
                      CommonDebugInfoDebugTypeBasic ||
                  (vulkanDebugInfo && !IsUint32Constant(_, encoding)) ||
                  OpenCLDebugInfo100DebugBaseTypeAttributeEncoding(
                      vulkanDebugInfo
                          ? GetUint32Constant(_, encoding)
                          : encoding) != OpenCLDebugInfo100Unsigned) {
                invalid = true;
              } else {
                // DebugTypeBasic for DebugLocalVariable/DebugGlobalVariable
                // must have Unsigned encoding and 32 or 64 as its size in
                // bits.
                Instruction* size_in_bits =
                    _.FindDef(component_count_type->word(6));
                if (!_.IsIntScalarType(size_in_bits->type_id()) ||
                    (size_in_bits->word(3) != 32 &&
                     size_in_bits->word(3) != 64)) {
                  invalid = true;
                }
              }
            } else {
              invalid = true;
            }
          } else {
            invalid = true;
          }
          if (invalid) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": Component Count must be "
                   << (vulkanDebugInfo ? "a constant instruction"
                                       : "OpConstant")
                   << " with a 32- or 64-bits integer scalar type or "
                   << "DebugGlobalVariable or DebugLocalVariable with a 32- "
                      "or "
                   << "64-bits unsigned integer scalar type";
          }
        }
        break;
      }
      case CommonDebugInfoDebugTypedef: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        auto validate_base_type = ValidateOperandBaseType(_, inst, 6);
        if (validate_base_type != SPV_SUCCESS) return validate_base_type;
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        break;
      }
      case CommonDebugInfoDebugTypeFunction: {
        CHECK_CONST_UINT_OPERAND("Flags", 5);
        auto* return_type = _.FindDef(inst->word(6));
        // TODO: We need a spec discussion that we have to allow return and
        // parameter types of a DebugTypeFunction to have template parameter.
        if (return_type->opcode() != spv::Op::OpTypeVoid) {
          auto validate_return =
              ValidateOperandDebugType(_, "Return Type", inst, 6, true);
          if (validate_return != SPV_SUCCESS) return validate_return;
        }
        for (uint32_t word_index = 7; word_index < num_words; ++word_index) {
          auto validate_param = ValidateOperandDebugType(
              _, "Parameter Types", inst, word_index, true);
          if (validate_param != SPV_SUCCESS) return validate_param;
        }
        break;
      }
      case CommonDebugInfoDebugTypeEnum: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        if (!DoesDebugInfoOperandMatchExpectation(
                _,
                [](CommonDebugInfoInstructions dbg_inst) {
                  return dbg_inst == CommonDebugInfoDebugInfoNone;
                },
                inst, 6)) {
          auto validate_underlying_type =
              ValidateOperandDebugType(_, "Underlying Types", inst, 6, false);
          if (validate_underlying_type != SPV_SUCCESS)
            return validate_underlying_type;
        }
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        CHECK_OPERAND("Size", spv::Op::OpConstant, 11);
        auto* size = _.FindDef(inst->word(11));
        if (!_.IsIntScalarType(size->type_id()) || !size->word(3)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": expected operand Size is a "
                 << "positive integer";
        }
        CHECK_CONST_UINT_OPERAND("Flags", 12);
        for (uint32_t word_index = 13; word_index + 1 < num_words;
             word_index += 2) {
          CHECK_OPERAND("Value", spv::Op::OpConstant, word_index);
          CHECK_OPERAND("Name", spv::Op::OpString, word_index + 1);
        }
        break;
      }
      case CommonDebugInfoDebugTypeComposite: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        CHECK_OPERAND("Linkage Name", spv::Op::OpString, 11);
        if (!DoesDebugInfoOperandMatchExpectation(
                _,
                [](CommonDebugInfoInstructions dbg_inst) {
                  return dbg_inst == CommonDebugInfoDebugInfoNone;
                },
                inst, 12)) {
          CHECK_OPERAND("Size", spv::Op::OpConstant, 12);
        }
        CHECK_CONST_UINT_OPERAND("Flags", 13);
        for (uint32_t word_index = 14; word_index < num_words; ++word_index) {
          if (!DoesDebugInfoOperandMatchExpectation(
                  _,
                  [](CommonDebugInfoInstructions dbg_inst) {
                    return dbg_inst == CommonDebugInfoDebugTypeMember ||
                           dbg_inst == CommonDebugInfoDebugFunction ||
                           dbg_inst == CommonDebugInfoDebugTypeInheritance;
                  },
                  inst, word_index)) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": "
                   << "expected operand Members "
                   << "must be DebugTypeMember, DebugFunction, or "
                      "DebugTypeInheritance";
          }
        }
        break;
      }
      case CommonDebugInfoDebugTypeMember: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        // TODO: We need a spec discussion that we have to allow member types
        // to have template parameter.
        auto validate_type = ValidateOperandDebugType(_, "Type", inst, 6, true);
        if (validate_type != SPV_SUCCESS) return validate_type;
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;
        // NonSemantic.Shader.DebugInfo doesn't have the Parent operand
        if (vulkanDebugInfo) {
          CHECK_OPERAND("Offset", spv::Op::OpConstant, 10);
          CHECK_OPERAND("Size", spv::Op::OpConstant, 11);
          CHECK_CONST_UINT_OPERAND("Flags", 12);
          if (has_optional_at(14))
            CHECK_OPERAND("Value", spv::Op::OpConstant, 13);
        } else {
          CHECK_DEBUG_OPERAND("Parent", CommonDebugInfoDebugTypeComposite, 10);
          CHECK_OPERAND("Offset", spv::Op::OpConstant, 11);
          CHECK_OPERAND("Size", spv::Op::OpConstant, 12);
          CHECK_CONST_UINT_OPERAND("Flags", 13);
          if (has_optional_at(15))
            CHECK_OPERAND("Value", spv::Op::OpConstant, 14);
        }
        break;
      }
      case CommonDebugInfoDebugTypeInheritance: {
        CHECK_DEBUG_OPERAND("Child", CommonDebugInfoDebugTypeComposite, 5);
        auto* debug_inst = _.FindDef(inst->word(5));
        auto composite_type =
            OpenCLDebugInfo100DebugCompositeType(debug_inst->word(6));
        if (composite_type != OpenCLDebugInfo100Class &&
            composite_type != OpenCLDebugInfo100Structure) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected operand Child must be class or struct debug "
                    "type";
        }
        CHECK_DEBUG_OPERAND("Parent", CommonDebugInfoDebugTypeComposite, 6);
        debug_inst = _.FindDef(inst->word(6));
        composite_type =
            OpenCLDebugInfo100DebugCompositeType(debug_inst->word(6));
        if (composite_type != OpenCLDebugInfo100Class &&
            composite_type != OpenCLDebugInfo100Structure) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected operand Parent must be class or struct debug "
                    "type";
        }
        CHECK_OPERAND("Offset", spv::Op::OpConstant, 7);
        CHECK_OPERAND("Size", spv::Op::OpConstant, 8);
        CHECK_CONST_UINT_OPERAND("Flags", 9);
        break;
      }
      case CommonDebugInfoDebugFunction: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        CHECK_DEBUG_OPERAND("Type", CommonDebugInfoDebugTypeFunction, 6);
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        CHECK_OPERAND("Linkage Name", spv::Op::OpString, 11);
        CHECK_CONST_UINT_OPERAND("Flags", 12);
        CHECK_CONST_UINT_OPERAND("Scope Line", 13);
        // NonSemantic.Shader.DebugInfo.100 doesn't include a reference to the
        // OpFunction
        if (vulkanDebugInfo) {
          if (has_optional_at(15)) {
            CHECK_DEBUG_OPERAND("Declaration",
                                CommonDebugInfoDebugFunctionDeclaration, 14);
          }
        } else {
          if (!DoesDebugInfoOperandMatchExpectation(
                  _,
                  [](CommonDebugInfoInstructions dbg_inst) {
                    return dbg_inst == CommonDebugInfoDebugInfoNone;
                  },
                  inst, 14)) {
            CHECK_OPERAND("Function", spv::Op::OpFunction, 14);
          }
          if (has_optional_at(16)) {
            CHECK_DEBUG_OPERAND("Declaration",
                                CommonDebugInfoDebugFunctionDeclaration, 15);
          }
        }
        break;
      }
      case CommonDebugInfoDebugFunctionDeclaration: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        CHECK_DEBUG_OPERAND("Type", CommonDebugInfoDebugTypeFunction, 6);
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        CHECK_OPERAND("Linkage Name", spv::Op::OpString, 11);
        CHECK_CONST_UINT_OPERAND("Flags", 12);
        break;
      }
      case CommonDebugInfoDebugLexicalBlock: {
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 5);
        CHECK_CONST_UINT_OPERAND("Line", 6);
        CHECK_CONST_UINT_OPERAND("Column", 7);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 5, 6, 7, ext_inst_type))
          return error;
        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 8);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        if (has_optional_at(10)) CHECK_OPERAND("Name", spv::Op::OpString, 9);
        break;
      }
      case CommonDebugInfoDebugScope: {
        auto validate_scope = ValidateOperandLexicalScope(_, "Scope", inst, 5);
        if (validate_scope != SPV_SUCCESS) return validate_scope;
        if (has_optional_at(7)) {
          CHECK_DEBUG_OPERAND("Inlined At", CommonDebugInfoDebugInlinedAt, 6);
        }
        break;
      }
      case CommonDebugInfoDebugLocalVariable: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        // TODO: We need a spec discussion that we have to allow local
        // variable types to have template parameter.
        auto validate_type = ValidateOperandDebugType(_, "Type", inst, 6, true);
        if (validate_type != SPV_SUCCESS) return validate_type;
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_parent =
            ValidateOperandLexicalScope(_, "Parent", inst, 10);
        if (validate_parent != SPV_SUCCESS) return validate_parent;
        CHECK_CONST_UINT_OPERAND("Flags", 11);
        if (has_optional_at(13)) {
          CHECK_CONST_UINT_OPERAND("ArgNumber", 12);
        }
        break;
      }
      case CommonDebugInfoDebugDeclare: {
        CHECK_DEBUG_OPERAND("Local Variable", CommonDebugInfoDebugLocalVariable,
                            5);
        auto* operand = _.FindDef(inst->word(6));
        if (operand->opcode() != spv::Op::OpVariable &&
            operand->opcode() != spv::Op::OpFunctionParameter) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected operand Variable must be a result id of "
                    "OpVariable or OpFunctionParameter";
        }

        CHECK_DEBUG_OPERAND("Expression", CommonDebugInfoDebugExpression, 7);
        break;
      }
      case CommonDebugInfoDebugExpression: {
        for (uint32_t word_index = 5; word_index < num_words; ++word_index) {
          CHECK_DEBUG_OPERAND("Operation", CommonDebugInfoDebugOperation,
                              word_index);
        }
        break;
      }
      case CommonDebugInfoDebugTypeTemplate: {
        if (!DoesDebugInfoOperandMatchExpectation(
                _,
                [](CommonDebugInfoInstructions dbg_inst) {
                  return dbg_inst == CommonDebugInfoDebugTypeComposite ||
                         dbg_inst == CommonDebugInfoDebugFunction;
                },
                inst, 5)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": "
                 << "expected operand Target must be DebugTypeComposite "
                 << "or DebugFunction";
        }
        for (uint32_t word_index = 6; word_index < num_words; ++word_index) {
          if (!DoesDebugInfoOperandMatchExpectation(
                  _,
                  [](CommonDebugInfoInstructions dbg_inst) {
                    return dbg_inst ==
                               CommonDebugInfoDebugTypeTemplateParameter ||
                           dbg_inst ==
                               CommonDebugInfoDebugTypeTemplateTemplateParameter;
                  },
                  inst, word_index)) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": "
                   << "expected operand Parameters must be "
                   << "DebugTypeTemplateParameter or "
                   << "DebugTypeTemplateTemplateParameter";
          }
        }
        break;
      }
      case CommonDebugInfoDebugTypeTemplateParameter: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        auto validate_actual_type =
            ValidateOperandDebugType(_, "Actual Type", inst, 6, false);
        if (validate_actual_type != SPV_SUCCESS) return validate_actual_type;
        if (!DoesDebugInfoOperandMatchExpectation(
                _,
                [](CommonDebugInfoInstructions dbg_inst) {
                  return dbg_inst == CommonDebugInfoDebugInfoNone;
                },
                inst, 7)) {
          CHECK_OPERAND("Value", spv::Op::OpConstant, 7);
        }
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 8);
        CHECK_CONST_UINT_OPERAND("Line", 9);
        CHECK_CONST_UINT_OPERAND("Column", 10);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 8, 9, 10, ext_inst_type))
          return error;
        break;
      }
      case CommonDebugInfoDebugGlobalVariable: {
        CHECK_OPERAND("Name", spv::Op::OpString, 5);
        auto validate_type =
            ValidateOperandDebugType(_, "Type", inst, 6, false);
        if (validate_type != SPV_SUCCESS) return validate_type;
        CHECK_DEBUG_OPERAND("Source", CommonDebugInfoDebugSource, 7);
        CHECK_CONST_UINT_OPERAND("Line", 8);
        CHECK_CONST_UINT_OPERAND("Column", 9);
        if (auto error =
                ValidateOperandDebugSource(_, inst, 7, 8, 9, ext_inst_type))
          return error;

        auto validate_scope = ValidateOperandLexicalScope(_, "Scope", inst, 10);
        if (validate_scope != SPV_SUCCESS) return validate_scope;
        CHECK_OPERAND("Linkage Name", spv::Op::OpString, 11);
        if (!DoesDebugInfoOperandMatchExpectation(
                _,
                [](CommonDebugInfoInstructions dbg_inst) {
                  return dbg_inst == CommonDebugInfoDebugInfoNone;
                },
                inst, 12)) {
          auto* operand = _.FindDef(inst->word(12));
          std::initializer_list<spv::Op> allowed_opcodes = {
              spv::Op::OpVariable,
              spv::Op::OpConstantTrue,
              spv::Op::OpConstantFalse,
              spv::Op::OpConstant,
              spv::Op::OpConstantComposite,
              spv::Op::OpConstantSampler,
              spv::Op::OpConstantNull,
              spv::Op::OpSpecConstantTrue,
              spv::Op::OpSpecConstantFalse,
              spv::Op::OpSpecConstant,
              spv::Op::OpSpecConstantComposite,
              spv::Op::OpSpecConstantOp};
          if (std::find(allowed_opcodes.begin(), allowed_opcodes.end(),
                        operand->opcode()) == allowed_opcodes.end()) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst) << ": "
                   << "expected operand Variable must be a result id of "
                      "OpVariable, OpConstant variant, OpSpecConstant variant "
                      "or DebugInfoNone";
          }
        }
        if (has_optional_at(15)) {
          CHECK_DEBUG_OPERAND("Static Member Declaration",
                              CommonDebugInfoDebugTypeMember, 14);
        }
        break;
      }
      case CommonDebugInfoDebugInlinedAt: {
        CHECK_CONST_UINT_OPERAND("Line", 5);
        auto validate_scope = ValidateOperandLexicalScope(_, "Scope", inst, 6);
        if (validate_scope != SPV_SUCCESS) return validate_scope;
        if (has_optional_at(8)) {
          CHECK_DEBUG_OPERAND("Inlined", CommonDebugInfoDebugInlinedAt, 7);
        }
        break;
      }
      case CommonDebugInfoDebugValue: {
        CHECK_DEBUG_OPERAND("Local Variable", CommonDebugInfoDebugLocalVariable,
                            5);
        CHECK_DEBUG_OPERAND("Expression", CommonDebugInfoDebugExpression, 7);

        for (uint32_t word_index = 8; word_index < num_words; ++word_index) {
          // TODO: The following code simply checks if it is a const int
          // scalar or a DebugLocalVariable or DebugGlobalVariable, but we
          // have to check it using the same validation for Indexes of
          // OpAccessChain.
          if (!IsConstWithIntScalarType(_, inst, word_index) &&
              !IsDebugVariableWithIntScalarType(_, inst, word_index)) {
            return _.diag(SPV_ERROR_INVALID_DATA, inst)
                   << GetExtInstName(_, inst)
                   << ": expected operand Indexes is "
                   << "OpConstant, DebugGlobalVariable, or "
                   << "type is OpConstant with an integer scalar type";
          }
        }
        break;
      }

      // TODO: Add validation rules for remaining cases as well.
      case CommonDebugInfoDebugTypePtrToMember:
      case CommonDebugInfoDebugTypeTemplateTemplateParameter:
      case CommonDebugInfoDebugTypeTemplateParameterPack:
      case CommonDebugInfoDebugLexicalBlockDiscriminator:
      case CommonDebugInfoDebugInlinedVariable:
      case CommonDebugInfoDebugMacroDef:
      case CommonDebugInfoDebugMacroUndef:
      case CommonDebugInfoDebugImportedEntity:
        break;
      case CommonDebugInfoInstructionsMax:
        assert(0);
        break;
    }
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstGraphDebugInfo(ValidationState_t& _,
                                           const Instruction* inst) {
  if (!_.IsVoidType(inst->type_id())) {
    return _.diag(SPV_ERROR_INVALID_DATA, inst)
           << GetExtInstName(_, inst) << ": "
           << "expected result type must be a result id of OpTypeVoid";
  }

  const auto ext_inst_key =
      NonSemanticGraphDebugInfoInstructions(inst->word(4));
  switch (ext_inst_key) {
    case NonSemanticGraphDebugInfoDebugGraph: {
      CHECK_OPERAND("Graph", spv::Op::OpGraphARM, 5);
      CHECK_OPERAND("Name", spv::Op::OpString, 6);
      break;
    }

    case NonSemanticGraphDebugInfoDebugOperation: {
      const auto* debug_graph = _.FindDef(inst->word(5));
      if (!debug_graph || !IsGraphDebugInfoDebugGraph(debug_graph)) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": expected operand DebugGraph "
               << "must be a result id of NonSemantic.Graph.DebugInfo "
               << "DebugGraph";
      }
      CHECK_OPERAND("Name", spv::Op::OpString, 6);
      if (inst->words().size() < 8) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": expected operand "
               << "Instructions must contain at least one instruction";
      }

      const uint32_t graph_id = debug_graph->word(5);
      for (uint32_t word_index = 7; word_index < inst->words().size();
           ++word_index) {
        const uint32_t instruction_id = inst->word(word_index);
        if (!IsInstructionInGraph(_, instruction_id, graph_id)) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": expected operand "
                 << "Instructions must be result ids of instructions within "
                 << "the graph described by DebugGraph";
        }
      }
      break;
    }

    case NonSemanticGraphDebugInfoDebugTensor: {
      const auto* tensor = _.FindDef(inst->word(5));
      const uint32_t tensor_type_id = tensor ? tensor->type_id() : 0;
      const auto* tensor_type = _.FindDef(tensor_type_id);
      const bool is_tensor =
          tensor_type && tensor_type->opcode() == spv::Op::OpTypeTensorARM;
      const bool is_composite_tensor =
          IsTopLevelCompositeOfTensors(_, tensor_type_id);
      if (!is_tensor && !is_composite_tensor) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": expected operand Tensor "
               << "must be a value of OpTypeTensorARM or a composite type "
               << "whose top-level constituents are OpTypeTensorARM";
      }
      CHECK_OPERAND("Name", spv::Op::OpString, 6);

      const bool has_index = inst->words().size() > 7;
      if (is_composite_tensor && !has_index) {
        return _.diag(SPV_ERROR_INVALID_DATA, inst)
               << GetExtInstName(_, inst) << ": expected operand Index "
               << "must be present when Tensor has composite type";
      }
      if (has_index) {
        if (!is_composite_tensor) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": expected operand Tensor "
                 << "must have composite type when Index is present";
        }
        if (!IsUint32Constant(_, inst->word(7))) {
          return _.diag(SPV_ERROR_INVALID_DATA, inst)
                 << GetExtInstName(_, inst) << ": expected operand Index "
                 << "must be a result id of 32-bit unsigned OpConstant";
        }
      }
      break;
    }

    default:
      break;
  }

  return SPV_SUCCESS;
}

spv_result_t ValidateExtInstNonsemanticClspvReflection(
    ValidationState_t& _, const Instruction* inst) {
  auto import_inst = _.FindDef(inst->GetOperandAs<uint32_t>(2));
  const std::string name = import_inst->GetOperandAs<std::string>(1);
  const std::string reflection = "NonSemantic.ClspvReflection.";
  char* end_ptr;
  auto version_string = name.substr(reflection.size());
  if (version_string.empty()) {
    return _.diag(SPV_ERROR_INVALID_DATA, import_inst)
           << "Missing NonSemantic.ClspvReflection import version";
  }
  uint32_t version =
      static_cast<uint32_t>(std::strtoul(version_string.c_str(), &end_ptr, 10));
  if (end_ptr && *end_ptr != '\0') {
    return _.diag(SPV_ERROR_INVALID_DATA, import_inst)
           << "NonSemantic.ClspvReflection import does not encode the "
              "version correctly";
  }
  if (version == 0 || version > NonSemanticClspvReflectionRevision) {
    return _.diag(SPV_ERROR_INVALID_DATA, import_inst)
           << "Unknown NonSemantic.ClspvReflection import version";
  }

  return ValidateClspvReflectionInstruction(_, inst, version);
}

spv_result_t ValidateExtInst(ValidationState_t& _, const Instruction* inst) {
  const spv_ext_inst_type_t ext_inst_type =
      spv_ext_inst_type_t(inst->ext_inst_type());

  if (ext_inst_type == SPV_EXT_INST_TYPE_GLSL_STD_450) {
    return ValidateExtInstGlslStd450(_, inst);
  } else if (ext_inst_type == SPV_EXT_INST_TYPE_OPENCL_STD) {
    return ValidateExtInstOpenClStd(_, inst);
  } else if (ext_inst_type == SPV_EXT_INST_TYPE_OPENCL_DEBUGINFO_100 ||
             ext_inst_type ==
                 SPV_EXT_INST_TYPE_NONSEMANTIC_SHADER_DEBUGINFO_100) {
    return ValidateExtInstDebugInfo(_, inst);
  } else if (ext_inst_type == SPV_EXT_INST_TYPE_NONSEMANTIC_CLSPVREFLECTION) {
    return ValidateExtInstNonsemanticClspvReflection(_, inst);
  } else if (ext_inst_type == SPV_EXT_INST_TYPE_NONSEMANTIC_GRAPH_DEBUGINFO) {
    return ValidateExtInstGraphDebugInfo(_, inst);
  }

  return SPV_SUCCESS;
}

spv_result_t ExtensionPass(ValidationState_t& _, const Instruction* inst) {
  const spv::Op opcode = inst->opcode();
  if (opcode == spv::Op::OpExtension) return ValidateExtension(_, inst);
  if (opcode == spv::Op::OpExtInstImport) return ValidateExtInstImport(_, inst);
  if (spvIsExtendedInstruction(opcode)) return ValidateExtInst(_, inst);

  return SPV_SUCCESS;
}

}  // namespace val
}  // namespace spvtools
