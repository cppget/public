# libmetal-cpp - C++ interface for Metal

This is a `build2` package for the [`metal-cpp`](https://github.com/apple/metal-cpp)
C++ library. It provides a C++ interface for Metal.


## Usage

To start using `libmetal-cpp` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libmetal-cpp ^381.0.0
```

Then import the library in your `buildfile`:

```
import libs = libmetal-cpp%lib{metal-cpp}
```


## Importable targets

This package provides the following importable targets:

```
lib{metal-cpp}
```

Compiled by default (`config.libmetal_cpp.implementation=true`). Include
headers as upstream does, for example `#include <Metal/Metal.hpp>` (also
Foundation, QuartzCore, and MetalFX). Do not define
`NS_PRIVATE_IMPLEMENTATION`, `MTL_PRIVATE_IMPLEMENTATION`,
`CA_PRIVATE_IMPLEMENTATION`, or `MTLFX_PRIVATE_IMPLEMENTATION` in that mode.
The library already provides those symbols. Defining them in a consumer
translation unit duplicates symbols at link time.

Set `config.libmetal_cpp.implementation=false` for the upstream header-only
model. Then exactly one consumer translation unit must define those macros
(and `CA_PRIVATE_IMPLEMENTATION` / `MTLFX_PRIVATE_IMPLEMENTATION` when using
QuartzCore / MetalFX). Metadata `libmetal_cpp.implementation` reflects the
configured value.

On Apple targets the library exports Foundation, Metal, QuartzCore, MetalFX,
and `objc`. Requires C++17 and an Apple SDK with Metal.


## Configuration variables

```
[bool] config.libmetal_cpp.implementation ?= true
```

Compile Apple's private implementation into `lib{metal-cpp}` (`true`,
default). Set to `false` for the upstream header-only model, where one
consumer translation unit defines the `*_PRIVATE_IMPLEMENTATION` macros.
