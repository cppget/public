#include <Metal/Metal.hpp>

#undef NDEBUG
#include <cassert>

int main ()
{
  NS::AutoreleasePool* pool = NS::AutoreleasePool::alloc ()->init ();

  MTL::Device* device = MTL::CreateSystemDefaultDevice ();

  if (device != nullptr)
  {
    NS::String* name = device->name ();
    assert (name != nullptr);
    assert (name->length () > 0);
  }
  else
  {
    // No GPU available (headless/virtualized CI runner, for example).
    // Fall back to checks that don't need a device but still exercise the
    // Metal/Foundation Objective-C bridge: array/object marshaling, class
    // allocation, and property access.
    //
    NS::Array* devices = MTL::CopyAllDevices ();
    assert (devices != nullptr);

    MTL::TextureDescriptor* desc = MTL::TextureDescriptor::alloc ()->init ();
    assert (desc != nullptr);
    assert (desc->textureType () == MTL::TextureType2D);
    assert (desc->width () == 1);
    desc->release ();

    devices->release ();
  }

  pool->release ();
  return 0;
}
