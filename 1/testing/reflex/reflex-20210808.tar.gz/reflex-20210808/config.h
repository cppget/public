#define LOCALE 1

#define STDC_HEADERS 1
#define HAVE_MALLOC_H 1
#define HAVE_STRING_H 1
#define HAVE_SYS_TYPES_H 1

#undef HAVE_ALLOCA_H

#define YY_NEVER_INTERACTIVE 1

#ifndef _WIN32
#  define HAVE_UNISTD_H 1
#else
#  define YY_NO_UNISTD_H
#endif
