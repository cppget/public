#include <lua.hpp>
// Just checks that we find, compile and link the lua library.
int main () { }
