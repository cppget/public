#include <libstud/uuid/uuid.hxx>
#include <libstud/uuid/uuid-io.hxx>
