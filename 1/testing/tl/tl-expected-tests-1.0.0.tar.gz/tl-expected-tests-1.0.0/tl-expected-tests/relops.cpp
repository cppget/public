#include <catch2/catch.hpp>
#include <tl/expected.hpp>

TEST_CASE("Relational operators", "[relops]") {
    //TODO
}
