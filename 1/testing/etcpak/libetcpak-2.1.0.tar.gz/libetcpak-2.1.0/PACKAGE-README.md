# libetcpak - ETC and BC texture codec library

This is a `build2` package for the [`etcpak`](https://github.com/wolfpld/etcpak)
C++ library. It provides Ericsson Texture Compression and Block Compression
encode and decode for texture assets.


## Usage

To start using `libetcpak` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libetcpak ^2.1.0
```

Then import the library in your `buildfile`:

```
import libs = libetcpak%lib{etcpak}
```


## Importable targets

This package provides the following importable targets:

```
lib{etcpak}
```

Consumers include `<etcpak/ProcessRGB.hpp>`, `<etcpak/ProcessDxtc.hpp>`,
`<etcpak/Decode.hpp>`, and `<etcpak/TextureHeader.hpp>`.


## Configuration variables

This package has no configuration variables.
