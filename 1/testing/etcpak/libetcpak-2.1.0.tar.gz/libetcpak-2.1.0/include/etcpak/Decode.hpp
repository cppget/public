#ifndef __DECODE_HPP__
#define __DECODE_HPP__

#include <stdint.h>

// Public interface for decoding functions
void DecodeBc1(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeBc3(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeBc4(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeBc5(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeBc7(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeRGB(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeRGBA(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height);
void DecodeR(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height, bool isSigned = false);
void DecodeRG(const uint64_t* src, uint32_t* dst, int32_t width, int32_t height, bool isSigned = false);

#endif
