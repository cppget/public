#include <etcpak/ProcessRGB.hpp>
#include <etcpak/ProcessDxtc.hpp>
#include <etcpak/Decode.hpp>

#include <stdint.h>

#undef NDEBUG
#include <cassert>

int main ()
{
  // One 4x4 RGBA block. Calling non-inline entry points checks the public
  // header install path and that symbols are exported from lib{etcpak}.
  //
  uint32_t src[16];
  for (uint32_t i = 0; i < 16; ++i)
    src[i] = 0xff000000u | (i * 0x10101u);

  uint64_t etc = 0;
  CompressEtc2Rgb (src, &etc, 1, 4, true);
  assert (etc != 0);

  uint64_t bc1 = 0;
  CompressBc1 (src, &bc1, 1, 4);
  assert (bc1 != 0);

  uint32_t out[16];
  DecodeBc1 (&bc1, out, 4, 4);
}
