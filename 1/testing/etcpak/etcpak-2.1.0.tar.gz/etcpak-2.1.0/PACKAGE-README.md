# etcpak - ETC and BC texture compression utility

This is a `build2` package for the [`etcpak`](https://github.com/wolfpld/etcpak)
executable. It is an Ericsson Texture Compression and Block Compression
utility for texture assets.


## Usage

To start using `etcpak` in your project, add the following build-time
`depends` value to your `manifest`, adjusting the version constraint as
appropriate:

```
depends: * etcpak ^2.1.0
```

Then import the executable in your `buildfile`:

```
import etcpak = etcpak%exe{etcpak}
```


## Importable targets

This package provides the following importable targets:

```
exe{etcpak}
```

The command-line tool for encoding and decoding ETC and BC textures from PNG.


## Configuration variables

This package has no configuration variables.
