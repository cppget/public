// This file is provided as forwarding mechanism
// to the actual Catch2 library inclusion.
//
#include <catch2/catch.hpp>
