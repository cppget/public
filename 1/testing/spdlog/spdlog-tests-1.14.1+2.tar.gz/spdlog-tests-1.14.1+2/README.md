# spdlog tests library - Build2 package

See [`spdlog` documentation](https://github.com/gabime/spdlog/wiki) for usage and details.

 - spdlog: https://github.com/gabime/spdlog
 - Build2: https://build2.org

Note: This is the source code for the build2 package of the `spdlog` C++ library,
the actual library sources snapshot can be found in the `./upstream/` submodule.
