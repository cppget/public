
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/values.h>


namespace gl14
{


// import values to namespace


} // namespace gl14