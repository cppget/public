
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl10/types.h>
#include <glbinding/gl10/values.h>
#include <glbinding/gl10/boolean.h>
#include <glbinding/gl10/bitfield.h>
#include <glbinding/gl10/enum.h>
#include <glbinding/gl10/functions.h>

#include <glbinding/gl/extension.h>