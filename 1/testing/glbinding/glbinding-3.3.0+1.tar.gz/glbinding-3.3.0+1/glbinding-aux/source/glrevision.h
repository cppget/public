
#pragma once


namespace glbinding
{


const unsigned int GL_REVISION = 20230211; ///< The revision of the gl.xml at the time of code generation.


} // namespace glbinding