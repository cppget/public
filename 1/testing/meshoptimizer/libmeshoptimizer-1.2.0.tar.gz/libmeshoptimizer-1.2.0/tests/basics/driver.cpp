#include <meshoptimizer.h>

#undef NDEBUG
#include <cassert>

static_assert (MESHOPTIMIZER_VERSION == 1020, "unexpected meshoptimizer version");

int main ()
{
  // A single triangle.
  //
  unsigned int indices[3] = {0, 1, 2};
  unsigned int optimized[3];

  meshopt_optimizeVertexCache (optimized, indices, 3, 3);

  // The vertex cache optimizer only reorders indices; all three original
  // indices must still be present in the result.
  //
  bool has0 = false, has1 = false, has2 = false;
  for (unsigned int i : optimized)
  {
    has0 = has0 || i == 0;
    has1 = has1 || i == 1;
    has2 = has2 || i == 2;
  }
  assert (has0 && has1 && has2);
}
