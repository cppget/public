# libmeshoptimizer - Mesh optimization and simplification C++ library

This is a `build2` package for the
[`meshoptimizer`](https://github.com/zeux/meshoptimizer) C++ library. It
provides algorithms to optimize meshes for GPU rendering pipeline stages, as
well as algorithms to reduce mesh complexity and storage overhead.


## Usage

To start using `libmeshoptimizer` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libmeshoptimizer ^1.2.0
```

Then import the library in your `buildfile`:

```
import libs = libmeshoptimizer%lib{meshoptimizer}
```


## Importable targets

This package provides the following importable targets:

```
lib{meshoptimizer}
```

The C++ library providing meshoptimizer's mesh optimization and
simplification algorithms.


## Configuration variables

This package provides no configuration variables.
