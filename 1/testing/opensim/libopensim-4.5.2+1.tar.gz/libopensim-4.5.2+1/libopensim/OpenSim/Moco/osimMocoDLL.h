#ifndef OPENSIM_OSIMMOCODLL_H
#define OPENSIM_OSIMMOCODLL_H
/* -------------------------------------------------------------------------- *
 * OpenSim: osimMocoDLL.h                                                     *
 * -------------------------------------------------------------------------- *
 * Copyright (c) 2017 Stanford University and the Authors                     *
 *                                                                            *
 * Author(s): Christopher Dembia                                              *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may    *
 * not use this file except in compliance with the License. You may obtain a  *
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0          *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 * -------------------------------------------------------------------------- */

#ifndef _WIN32
    #define OSIMMOCO_API
#else
    #if defined(OPENSIM_MOCO_TYPE_STATIC)
        #define OSIMMOCO_API
    #elif defined(OSIMMOCO_EXPORTS)
        #define OSIMMOCO_API __declspec(dllexport)
    #else
        #define OSIMMOCO_API __declspec(dllimport)
    #endif
#endif

#endif // OPENSIM_OSIMMOCODLL_H
