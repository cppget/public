// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause
#include <QObject>

// dummy
class TestGui: public QObject
{
    Q_OBJECT
public:
    void testGui_data();
};
