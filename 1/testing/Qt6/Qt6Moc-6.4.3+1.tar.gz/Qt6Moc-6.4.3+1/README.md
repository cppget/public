# Qt6Moc

This package contains the Qt6 meta object compiler (`moc`).
