// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

/*!
    \class QMdiArea
    \brief The QMdiArea widget provides an area in which MDI windows are displayed.
    \since 4.3
    \ingroup mainwindow-classes
    \inmodule QtWidgets

    QMdiArea functions, essentially, like a window manager for MDI
    windows. For instance, it draws the windows it manages on itself
    and arranges them in a cascading or tile pattern. QMdiArea is
    commonly used as the center widget in a QMainWindow to create MDI
    applications, but can also be placed in any layout. The following
    code adds an area to a main window:

    \snippet mdiarea/mdiareasnippets.cpp 0

    Unlike the window managers for top-level windows, all window flags
    (Qt::WindowFlags) are supported by QMdiArea as long as the flags
    are supported by the current widget style.

    Subwindows in QMdiArea are instances of QMdiSubWindow. They
    are added to an MDI area with addSubWindow(). It is common to pass
    a QWidget, which is set as the internal widget, to this function,
    but it is also possible to pass a QMdiSubWindow directly. The class
    inherits QWidget, and you can use the same API as with a normal
    top-level window when programming. QMdiSubWindow also has behavior
    that is specific to MDI windows. See the QMdiSubWindow class
    description for more details.

    A subwindow becomes active when it gets the keyboard focus, or
    when setFocus() is called. The user activates a window by moving
    focus in the usual ways. The MDI area emits the
    subWindowActivated() signal when the active window changes, and
    the activeSubWindow() function returns the active subwindow.

    The convenience function subWindowList() returns a list of all
    subwindows. This information could be used in a popup menu
    containing a list of windows, for example.

    The subwindows are sorted by the current
    \l{QMdiArea::}{WindowOrder}. This is used for the subWindowList()
    and for activateNextSubWindow() and activatePreviousSubWindow().
    Also, it is used when cascading or tiling the windows with
    cascadeSubWindows() and tileSubWindows().

    QMdiArea provides two built-in layout strategies for
    subwindows: cascadeSubWindows() and tileSubWindows(). Both are
    slots and are easily connected to menu entries.

    \table
    \row \li \inlineimage mdi-cascade.png
             {MDI windows in cascading order}
         \li \inlineimage mdi-tile.png
             {MDI windows in a tiling pattern}
    \endtable

    \note The default scroll bar property for QMdiArea is Qt::ScrollBarAlwaysOff.

    \sa QMdiSubWindow
*/

/*!
    \fn void QMdiArea::subWindowActivated(QMdiSubWindow *window)

    QMdiArea emits this signal after \a window has been activated. When \a
    window is \nullptr, QMdiArea has just deactivated its last active window,
    and there are no active windows on the workspace.

    \sa QMdiArea::activeSubWindow()
*/

/*!
    \enum QMdiArea::AreaOption

    This enum describes options that customize the behavior of the
    QMdiArea.

    \value DontMaximizeSubWindowOnActivation When the active subwindow
    is maximized, the default behavior is to maximize the next
    subwindow that is activated. Set this option if you do not want
    this behavior.
*/

/*!
    \enum QMdiArea::WindowOrder

    Specifies the criteria to use for ordering the list of child windows
    returned by subWindowList(). The functions cascadeSubWindows() and
    tileSubWindows() follow this order when arranging the windows.

    \value CreationOrder The windows are returned in the order of
    their creation.

    \value StackingOrder The windows are returned in the order in
    which they are stacked, with the top-most window being last in
    the list.

    \value ActivationHistoryOrder The windows are returned in the order in
    which they were activated.

    \sa subWindowList()
*/

/*!
    \enum QMdiArea::ViewMode
    \since 4.4

    This enum describes the view mode of the area; i.e. how sub-windows
    will be displayed.

    \value SubWindowView Display sub-windows with window frames (default).
    \value TabbedView Display sub-windows with tabs in a tab bar.

    \sa setViewMode()
*/

#include "qmdiarea_p.h"

#include <QApplication>
#include <QStyle>
#include <QChildEvent>
#include <QResizeEvent>
#include <QScrollBar>
#include <QtAlgorithms>
#include <QPainter>
#include <QFontMetrics>
#include <QStyleOption>
#include <QDebug>
#include <qmath.h>
#if QT_CONFIG(menu)
#include <qmenu.h>
#endif
#include <private/qlayoutengine_p.h>

#include <algorithm>

QT_BEGIN_NAMESPACE

using namespace Qt::StringLiterals;
using namespace QMdi;

// Asserts in debug mode, gives warning otherwise.
static bool sanityCheck(const QMdiSubWindow * const child, const char *where)
{
    if (Q_UNLIKELY(!child)) {
        const char error[] = "null pointer";
        Q_ASSERT_X(false, where, error);
        qWarning("%s:%s", where, error);
        return false;
    }
    return true;
}

static bool sanityCheck(const QList<QWidget *> &widgets, const int index, const char *where)
{
    if (Q_UNLIKELY(index < 0 || index >= widgets.size())) {
        const char error[] = "index out of range";
        Q_ASSERT_X(false, where, error);
        qWarning("%s:%s", where, error);
        return false;
    }
    if (Q_UNLIKELY(!widgets.at(index))) {
        const char error[] = "null pointer";
        Q_ASSERT_X(false, where, error);
        qWarning("%s:%s", where, error);
        return false;
    }
    return true;
}

static void setIndex(int *index, int candidate, int min, int max, bool isIncreasing)
{
    if (!index)
        return;

    if (isIncreasing) {
        if (candidate > max)
            *index = min;
        else
            *index = qMax(candidate, min);
    } else {
        if (candidate < min)
            *index = max;
        else
            *index = qMin(candidate, max);
    }
    Q_ASSERT(*index >= min && *index <= max);
}

static inline bool useScrollBar(const QRect &childrenRect, const QSize &maxViewportSize,
                                Qt::Orientation orientation)
{
    if (orientation == Qt::Horizontal)
        return  childrenRect.width() > maxViewportSize.width()
                || childrenRect.left() < 0
                || childrenRect.right() >= maxViewportSize.width();
    else
        return childrenRect.height() > maxViewportSize.height()
               || childrenRect.top() < 0
               || childrenRect.bottom() >= maxViewportSize.height();
}

// Returns the closest mdi area containing the widget (if any).
static inline QMdiArea *mdiAreaParent(QWidget *widget)
{
    if (!widget)
        return nullptr;

    QWidget *parent = widget->parentWidget();
    while (parent) {
        if (QMdiArea *area = qobject_cast<QMdiArea *>(parent))
            return area;
        parent = parent->parentWidget();
    }
    return nullptr;
}

#if QT_CONFIG(tabwidget)
QTabBar::Shape _q_tb_tabBarShapeFrom(QTabWidget::TabShape shape, QTabWidget::TabPosition position);
#endif // QT_CONFIG(tabwidget)

static inline QString tabTextFor(QMdiSubWindow *subWindow)
{
    if (!subWindow)
        return QString();

    QString title = subWindow->windowTitle();
    if (subWindow->isWindowModified()) {
        title.replace("[*]"_L1, "*"_L1);
    } else {
        extern QString qt_setWindowTitle_helperHelper(const QString&, const QWidget*);
        title = qt_setWindowTitle_helperHelper(title, subWindow);
    }

    return title.isEmpty() ? QMdiArea::tr("(Untitled)") : title;
}

/*!
    \internal
*/
void RegularTiler::rearrange(QList<QWidget *> &widgets, const QRect &domain) const
{
    if (widgets.isEmpty())
        return;

    const int n = widgets.size();
    const int ncols = qMax(qCeil(qSqrt(qreal(n))), 1);
    const int nrows = qMax((n % ncols) ? (n / ncols + 1) : (n / ncols), 1);
    const int nspecial = (n % ncols) ? (ncols - n % ncols) : 0;
    const int dx = domain.width()  / ncols;
    const int dy = domain.height() / nrows;

    int i = 0;
    for (int row = 0; row < nrows; ++row) {
        const int y1 = int(row * (dy + 1));
        for (int col = 0; col < ncols; ++col) {
            if (row == 1 && col < nspecial)
                continue;
            const int x1 = int(col * (dx + 1));
            int x2 = int(x1 + dx);
            int y2 = int(y1 + dy);
            if (row == 0 && col < nspecial) {
                y2 *= 2;
                if (nrows != 2)
                    y2 += 1;
                else
                    y2 = domain.bottom();
            }
            if (col == ncols - 1 && x2 != domain.right())
                x2 = domain.right();
            if (row == nrows - 1 && y2 != domain.bottom())
                y2 = domain.bottom();
            if (!sanityCheck(widgets, i, "RegularTiler"))
                continue;
            QWidget *widget = widgets.at(i++);
            QRect newGeometry = QRect(QPoint(x1, y1), QPoint(x2, y2));
            widget->setGeometry(QStyle::visualRect(widget->layoutDirection(), domain, newGeometry));
        }
    }
}

/*!
    \internal
*/
void SimpleCascader::rearrange(QList<QWidget *> &widgets, const QRect &domain) const
{
    if (widgets.isEmpty())
        return;

    // Tunables:
    const int topOffset = 0;
    const int bottomOffset = 50;
    const int leftOffset = 0;
    const int rightOffset = 100;
    const int dx = 10;

    QStyleOptionTitleBar options;
    options.initFrom(widgets.at(0));
    int titleBarHeight = widgets.at(0)->style()->pixelMetric(QStyle::PM_TitleBarHeight, &options, widgets.at(0));
    const QFontMetrics fontMetrics = QFontMetrics(QApplication::font("QMdiSubWindowTitleBar"));
    const int dy = qMax(titleBarHeight - (titleBarHeight - fontMetrics.height()) / 2, 1)
        + widgets.at(0)->style()->pixelMetric(QStyle::PM_FocusFrameVMargin, nullptr, widgets.at(0));

    const int n = widgets.size();
    const int nrows = qMax((domain.height() - (topOffset + bottomOffset)) / dy, 1);
    const int ncols = qMax(n / nrows + ((n % nrows) ? 1 : 0), 1);
    const int dcol = (domain.width() - (leftOffset + rightOffset)) / ncols;

    int i = 0;
    for (int row = 0; row < nrows; ++row) {
        for (int col = 0; col < ncols; ++col) {
            const int x = leftOffset + row * dx + col * dcol;
            const int y = topOffset + row * dy;
            if (!sanityCheck(widgets, i, "SimpleCascader"))
                continue;
            QWidget *widget = widgets.at(i++);
            QRect newGeometry = QRect(QPoint(x, y), widget->sizeHint());
            widget->setGeometry(QStyle::visualRect(widget->layoutDirection(), domain, newGeometry));
            if (i == n)
                return;
        }
    }
}

/*!
    \internal
*/
void IconTiler::rearrange(QList<QWidget *> &widgets, const QRect &domain) const
{
    if (widgets.isEmpty() || !sanityCheck(widgets, 0, "IconTiler"))
        return;

    const int n = widgets.size();
    const int width = qMax(widgets.at(0)->width(), 1);
    const int height = widgets.at(0)->height();
    const int ncols = qMax(domain.width() / width, 1);
    const int nrows = n / ncols + ((n % ncols) ? 1 : 0);

    int i = 0;
    for (int row = 0; row < nrows; ++row) {
        for (int col = 0; col < ncols; ++col) {
            const int x = col * width;
            const int y = domain.height() - height - row * height;
            if (!sanityCheck(widgets, i, "IconTiler"))
                continue;
            QWidget *widget = widgets.at(i++);
            QPoint newPos(x, y);
            QRect newGeometry = QRect(newPos.x(), newPos.y(), widget->width(), widget->height());
            widget->setGeometry(QStyle::visualRect(widget->layoutDirection(), domain, newGeometry));
            if (i == n)
                return;
        }
    }
}

/*!
    \internal
    Calculates the accumulated overlap (intersection area) between 'source' and 'rects'.
*/
int MinOverlapPlacer::accumulatedOverlap(const QRect &source, const QList<QRect> &rects)
{
    int accOverlap = 0;
    for (const QRect &rect : rects) {
        QRect intersection = source.intersected(rect);
        accOverlap += intersection.width() * intersection.height();
    }
    return accOverlap;
}


/*!
    \internal
    Finds among 'source' the rectangle with the minimum accumulated overlap with the
    rectangles in 'rects'.
*/
QRect MinOverlapPlacer::findMinOverlapRect(const QList<QRect> &source, const QList<QRect> &rects)
{
    int minAccOverlap = -1;
    QRect minAccOverlapRect;
    for (const QRect &srcRect : source) {
        const int accOverlap = accumulatedOverlap(srcRect, rects);
        if (accOverlap < minAccOverlap || minAccOverlap == -1) {
            minAccOverlap = accOverlap;
            minAccOverlapRect = srcRect;
        }
    }
    return minAccOverlapRect;
}

/*!
    \internal
    Gets candidates for the final placement.
*/
QList<QRect> MinOverlapPlacer::getCandidatePlacements(const QSize &size, const QList<QRect> &rects,
                                                      const QRect &domain)
{
    QList<QRect> result;

    QList<int> xlist;
    xlist.reserve(2 + rects.size());
    xlist << domain.left() << domain.right() - size.width() + 1;

    QList<int> ylist;
    ylist.reserve(2 + rects.size());
    ylist << domain.top();
    if (domain.bottom() - size.height() + 1 >= 0)
        ylist << domain.bottom() - size.height() + 1;

    for (const QRect &rect : rects) {
        xlist << rect.right() + 1;
        ylist << rect.bottom() + 1;
    }

    std::sort(xlist.begin(), xlist.end());
    xlist.erase(std::unique(xlist.begin(), xlist.end()), xlist.end());

    std::sort(ylist.begin(), ylist.end());
    ylist.erase(std::unique(ylist.begin(), ylist.end()), ylist.end());

    result.reserve(ylist.size() * xlist.size());
    for (int y : std::as_const(ylist))
        for (int x : std::as_const(xlist))
            result << QRect(QPoint(x, y), size);
    return result;
}

/*!
    \internal
    Finds all rectangles in 'source' not completely inside 'domain'. The result is stored
    in 'result' and also removed from 'source'.
*/
QList<QRect> MinOverlapPlacer::findNonInsiders(const QRect &domain, QList<QRect> &source)
{
    const auto containedInDomain =
            [domain](const QRect &srcRect) { return domain.contains(srcRect); };

    const auto firstOut = std::stable_partition(source.begin(), source.end(), containedInDomain);

    QList<QRect> result;
    result.reserve(source.end() - firstOut);
    std::copy(firstOut, source.end(), std::back_inserter(result));

    source.erase(firstOut, source.end());

    return result;
}

/*!
   \internal
    Finds all rectangles in 'source' that overlaps 'domain' by the maximum overlap area
    between 'domain' and any rectangle in 'source'. The result is stored in 'result'.
*/
QList<QRect> MinOverlapPlacer::findMaxOverlappers(const QRect &domain, const QList<QRect> &source)
{
    QList<QRect> result;
    result.reserve(source.size());

    int maxOverlap = -1;
    for (const QRect &srcRect : source) {
        QRect intersection = domain.intersected(srcRect);
        const int overlap = intersection.width() * intersection.height();
        if (overlap >= maxOverlap || maxOverlap == -1) {
            if (overlap > maxOverlap) {
                maxOverlap = overlap;
                result.clear();
            }
            result << srcRect;
        }
    }

    return result;
}

/*!
   \internal
    Finds among the rectangles in 'source' the best placement. Here, 'best' means the
    placement that overlaps the rectangles in 'rects' as little as possible while at the
    same time being as much as possible inside 'domain'.
*/
QPoint MinOverlapPlacer::findBestPlacement(const QRect &domain, const QList<QRect> &rects,
                                           QList<QRect> &source)
{
    const QList<QRect> nonInsiders = findNonInsiders(domain, source);

    if (!source.empty())
        return findMinOverlapRect(source, rects).topLeft();

    QList<QRect> maxOverlappers = findMaxOverlappers(domain, nonInsiders);
    return findMinOverlapRect(maxOverlappers, rects).topLeft();
}


/*!
    \internal
    Places the rectangle defined by 'size' relative to 'rects' and 'domain' so that it
    overlaps 'rects' as little as possible and 'domain' as much as possible.
    Returns the position of the resulting rectangle.
*/
QPoint MinOverlapPlacer::place(const QSize &size, const QList<QRect> &rects,
                               const QRect &domain) const
{
    if (size.isEmpty() || !domain.isValid())
        return QPoint();
    for (const QRect &rect : rects) {
        if (!rect.isValid())
            return QPoint();
    }

    QList<QRect> candidates = getCandidatePlacements(size, rects, domain);
    return findBestPlacement(domain, rects, candidates);
}

#if QT_CONFIG(tabbar)
class QMdiAreaTabBar : public QTabBar
{
public:
    QMdiAreaTabBar(QWidget *parent) : QTabBar(parent) {}

protected:
    void mousePressEvent(QMouseEvent *event) override;
#ifndef QT_NO_CONTEXTMENU
    void contextMenuEvent(QContextMenuEvent *event) override;
#endif

private:
    QMdiSubWindow *subWindowFromIndex(int index) const;
};

/*!
    \internal
*/
void QMdiAreaTabBar::mousePressEvent(QMouseEvent *event)
{
    if (event->button() != Qt::MiddleButton) {
        QTabBar::mousePressEvent(event);
        return;
    }

    QMdiSubWindow *subWindow = subWindowFromIndex(tabAt(event->position().toPoint()));
    if (!subWindow) {
        event->ignore();
        return;
    }

    subWindow->close();
}

#ifndef QT_NO_CONTEXTMENU
/*!
    \internal
*/
void QMdiAreaTabBar::contextMenuEvent(QContextMenuEvent *event)
{
    QPointer<QMdiSubWindow> subWindow = subWindowFromIndex(tabAt(event->pos()));
    if (!subWindow || subWindow->isHidden()) {
        event->ignore();
        return;
    }

#if QT_CONFIG(menu)
    QMdiSubWindowPrivate *subWindowPrivate = subWindow->d_func();
    if (!subWindowPrivate->systemMenu) {
        event->ignore();
        return;
    }

    QMdiSubWindow *currentSubWindow = subWindowFromIndex(currentIndex());
    Q_ASSERT(currentSubWindow);

    // We don't want these actions to show up in the system menu when the
    // current sub-window is maximized, i.e. covers the entire viewport.
    if (currentSubWindow->isMaximized()) {
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::MoveAction, false);
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::ResizeAction, false);
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::MinimizeAction, false);
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::MaximizeAction, false);
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::RestoreAction, false);
        subWindowPrivate->setVisible(QMdiSubWindowPrivate::StayOnTopAction, false);
    }

    // Show system menu.
    subWindowPrivate->systemMenu->exec(event->globalPos());
    if (!subWindow)
        return;

    // Restore action visibility.
    subWindowPrivate->updateActions();
#endif // QT_CONFIG(menu)
}
#endif // QT_NO_CONTEXTMENU

/*!
    \internal
*/
QMdiSubWindow *QMdiAreaTabBar::subWindowFromIndex(int index) const
{
    if (index < 0 || index >= count())
        return nullptr;

    QMdiArea *mdiArea = qobject_cast<QMdiArea *>(parentWidget());
    Q_ASSERT(mdiArea);

    const QList<QMdiSubWindow *> subWindows = mdiArea->subWindowList();
    Q_ASSERT(index < subWindows.size());

    QMdiSubWindow *subWindow = mdiArea->subWindowList().at(index);
    Q_ASSERT(subWindow);

    return subWindow;
}
#endif // QT_CONFIG(tabbar)

/*!
    \internal
*/
QMdiAreaPrivate::QMdiAreaPrivate()
    : cascader(nullptr),
      regularTiler(nullptr),
      iconTiler(nullptr),
      placer(nullptr),
#if QT_CONFIG(rubberband)
      rubberBand(nullptr),
#endif
#if QT_CONFIG(tabbar)
      tabBar(nullptr),
#endif
      activationOrder(QMdiArea::CreationOrder),
      viewMode(QMdiArea::SubWindowView),
#if QT_CONFIG(tabbar)
      documentMode(false),
      tabsClosable(false),
      tabsMovable(false),
#endif
#if QT_CONFIG(tabwidget)
      tabShape(QTabWidget::Rounded),
      tabPosition(QTabWidget::North),
#endif
      ignoreGeometryChange(false),
      ignoreWindowStateChange(false),
      isActivated(false),
      isSubWindowsTiled(false),
      showActiveWindowMaximized(false),
      tileCalledFromResizeEvent(false),
      updatesDisabledByUs(false),
      inViewModeChange(false),
      indexToNextWindow(-1),
      indexToPreviousWindow(-1),
      indexToHighlighted(-1),
      indexToLastActiveTab(-1)
{
}

/*!
    \internal
*/
void QMdiAreaPrivate::_q_deactivateAllWindows(QMdiSubWindow *aboutToActivate)
{
    if (ignoreWindowStateChange)
        return;

    Q_Q(QMdiArea);
    if (!aboutToActivate)
        aboutToBecomeActive = qobject_cast<QMdiSubWindow *>(q->sender());
    else
        aboutToBecomeActive = aboutToActivate;
    Q_ASSERT(aboutToBecomeActive);

    // Take a copy because child->showNormal() could indirectly call
    // QCoreApplication::sendEvent(), which could call unknown code that e.g.
    // recurses into the class modifying childWindows.
    const auto subWindows = childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::deactivateAllWindows") || aboutToBecomeActive == child)
            continue;
        // We don't want to handle signals caused by child->showNormal().
        ignoreWindowStateChange = true;
        if (!(options & QMdiArea::DontMaximizeSubWindowOnActivation) && !showActiveWindowMaximized)
            showActiveWindowMaximized = child->isMaximized() && child->isVisible();
        if (showActiveWindowMaximized && child->isMaximized()) {
            if (q->updatesEnabled()) {
                updatesDisabledByUs = true;
                q->setUpdatesEnabled(false);
            }
            child->showNormal();
        }
        if (child->isMinimized() && !child->isShaded() && !windowStaysOnTop(child))
            child->lower();
        ignoreWindowStateChange = false;
        child->d_func()->setActive(false);
    }
}

/*!
    \internal
*/
void QMdiAreaPrivate::_q_processWindowStateChanged(Qt::WindowStates oldState,
                                                   Qt::WindowStates newState)
{
    if (ignoreWindowStateChange)
        return;

    Q_Q(QMdiArea);
    QMdiSubWindow *child = qobject_cast<QMdiSubWindow *>(q->sender());
    if (!child)
        return;

    // windowActivated
    if (!(oldState & Qt::WindowActive) && (newState & Qt::WindowActive))
        emitWindowActivated(child);
    // windowDeactivated
    else if ((oldState & Qt::WindowActive) && !(newState & Qt::WindowActive))
        resetActiveWindow(child);

    // windowMinimized
    if (!(oldState & Qt::WindowMinimized) && (newState & Qt::WindowMinimized)) {
        isSubWindowsTiled = false;
        arrangeMinimizedSubWindows();
    // windowMaximized
    } else if (!(oldState & Qt::WindowMaximized) && (newState & Qt::WindowMaximized)) {
        internalRaise(child);
    // windowRestored
    } else if (!(newState & (Qt::WindowMaximized | Qt::WindowMinimized))) {
        internalRaise(child);
        if (oldState & Qt::WindowMinimized)
            arrangeMinimizedSubWindows();
    }
}

void QMdiAreaPrivate::_q_currentTabChanged(int index)
{
#if !QT_CONFIG(tabbar)
    Q_UNUSED(index);
#else
    if (!tabBar || index < 0)
        return;

    // If the previous active sub-window was hidden, disable the tab.
    if (indexToLastActiveTab >= 0 && indexToLastActiveTab < tabBar->count()
        && indexToLastActiveTab < childWindows.size()) {
        QMdiSubWindow *lastActive = childWindows.at(indexToLastActiveTab);
        if (lastActive && lastActive->isHidden())
            tabBar->setTabEnabled(indexToLastActiveTab, false);
    }

    indexToLastActiveTab = index;
    Q_ASSERT(childWindows.size() > index);
    QMdiSubWindow *subWindow = childWindows.at(index);
    Q_ASSERT(subWindow);
    activateWindow(subWindow);
#endif // QT_CONFIG(tabbar)
}

void QMdiAreaPrivate::_q_closeTab(int index)
{
#if !QT_CONFIG(tabbar)
    Q_UNUSED(index);
#else
    QMdiSubWindow *subWindow = childWindows.at(index);
    Q_ASSERT(subWindow);
    subWindow->close();
#endif // QT_CONFIG(tabbar)
}

void QMdiAreaPrivate::_q_moveTab(int from, int to)
{
#if !QT_CONFIG(tabbar)
    Q_UNUSED(from);
    Q_UNUSED(to);
#else
    childWindows.move(from, to);

    // Put the active window in front to update activation order.
    const int indexToActiveWindow = childWindows.indexOf(active);
    if (indexToActiveWindow != -1) {
        const int index = indicesToActivatedChildren.indexOf(indexToActiveWindow);
        Q_ASSERT(index != -1);
        if (index != 0) { // if it's not in front
            indicesToActivatedChildren.move(index, 0);
            internalRaise(active);
        }
    }
#endif // QT_CONFIG(tabbar)
}

/*!
    \internal
*/
void QMdiAreaPrivate::appendChild(QMdiSubWindow *child)
{
    Q_Q(QMdiArea);
    Q_ASSERT(child && childWindows.indexOf(child) == -1);

    if (child->parent() != viewport)
        child->setParent(viewport, child->windowFlags());
    childWindows.append(QPointer<QMdiSubWindow>(child));

    if (!child->testAttribute(Qt::WA_Resized) && q->isVisible()) {
        QSize newSize(child->sizeHint().boundedTo(viewport->size()));
        child->resize(newSize.expandedTo(qSmartMinSize(child)));
    }

    if (!placer)
        placer = new MinOverlapPlacer;
    place(placer, child);

    if (hbarpolicy != Qt::ScrollBarAlwaysOff)
        child->setOption(QMdiSubWindow::AllowOutsideAreaHorizontally, true);
    else
        child->setOption(QMdiSubWindow::AllowOutsideAreaHorizontally, false);

    if (vbarpolicy != Qt::ScrollBarAlwaysOff)
        child->setOption(QMdiSubWindow::AllowOutsideAreaVertically, true);
    else
        child->setOption(QMdiSubWindow::AllowOutsideAreaVertically, false);

    internalRaise(child);
    indicesToActivatedChildren.prepend(childWindows.size() - 1);
    Q_ASSERT(indicesToActivatedChildren.size() == childWindows.size());

#if QT_CONFIG(tabbar)
    if (tabBar) {
        tabBar->addTab(child->windowIcon(), tabTextFor(child));
        updateTabBarGeometry();
        if (childWindows.size() == 1 && !(options & QMdiArea::DontMaximizeSubWindowOnActivation))
            showActiveWindowMaximized = true;
    }
#endif

    if (!(child->windowFlags() & Qt::SubWindow))
        child->setWindowFlags(Qt::SubWindow);
    child->installEventFilter(q);

    QObject::connect(child, SIGNAL(aboutToActivate()), q, SLOT(_q_deactivateAllWindows()));
    QObject::connect(child, SIGNAL(windowStateChanged(Qt::WindowStates,Qt::WindowStates)),
                     q, SLOT(_q_processWindowStateChanged(Qt::WindowStates,Qt::WindowStates)));
}

/*!
    \internal
*/
void QMdiAreaPrivate::place(Placer *placer, QMdiSubWindow *child)
{
    if (!placer || !child)
        return;

    Q_Q(QMdiArea);
    if (!q->isVisible()) {
        // The window is only laid out when it's added to QMdiArea,
        // so there's no need to check that we don't have it in the
        // list already. appendChild() ensures that.
        pendingPlacements.append(child);
        return;
    }

    QList<QRect> rects;
    rects.reserve(childWindows.size());
    QRect parentRect = q->rect();
    for (QMdiSubWindow *window : std::as_const(childWindows)) {
        if (!sanityCheck(window, "QMdiArea::place") || window == child || !window->isVisibleTo(q)
                || !window->testAttribute(Qt::WA_Moved)) {
            continue;
        }
        QRect occupiedGeometry;
        if (window->isMaximized()) {
            occupiedGeometry = QRect(window->d_func()->oldGeometry.topLeft(),
                                     window->d_func()->restoreSize);
        } else {
            occupiedGeometry = window->geometry();
        }
        rects.append(QStyle::visualRect(child->layoutDirection(), parentRect, occupiedGeometry));
    }
    QPoint newPos = placer->place(child->size(), rects, parentRect);
    QRect newGeometry = QRect(newPos.x(), newPos.y(), child->width(), child->height());
    child->setGeometry(QStyle::visualRect(child->layoutDirection(), parentRect, newGeometry));
}

/*!
    \internal
*/
void QMdiAreaPrivate::rearrange(Rearranger *rearranger)
{
    if (!rearranger)
        return;

    Q_Q(QMdiArea);
    if (!q->isVisible()) {
        // Compress if we already have the rearranger in the list.
        int index = pendingRearrangements.indexOf(rearranger);
        if (index != -1)
            pendingRearrangements.move(index, pendingRearrangements.size() - 1);
        else
            pendingRearrangements.append(rearranger);
        return;
    }

    QList<QWidget *> widgets;
    const bool reverseList = rearranger->type() == Rearranger::RegularTiler;
    const QList<QMdiSubWindow *> subWindows = subWindowList(activationOrder, reverseList);
    QSize minSubWindowSize;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::rearrange") || !child->isVisible())
            continue;
        if (rearranger->type() == Rearranger::IconTiler) {
            if (child->isMinimized() && !child->isShaded())
                widgets.append(child);
        } else {
            if (child->isMinimized() && !child->isShaded())
                continue;
            if (child->isMaximized() || child->isShaded())
                child->showNormal();
            minSubWindowSize = minSubWindowSize.expandedTo(child->minimumSize())
                               .expandedTo(child->d_func()->internalMinimumSize);
            widgets.append(child);
        }
    }

    QRect domain = viewport->rect();
    if (rearranger->type() == Rearranger::RegularTiler && !widgets.isEmpty())
        domain = resizeToMinimumTileSize(minSubWindowSize, widgets.size());

    rearranger->rearrange(widgets, domain);

    if (rearranger->type() == Rearranger::RegularTiler && !widgets.isEmpty()) {
        isSubWindowsTiled = true;
        updateScrollBars();
    } else if (rearranger->type() == Rearranger::SimpleCascader) {
        isSubWindowsTiled = false;
    }
}

/*!
    \internal

    Arranges all minimized windows at the bottom of the workspace.
*/
void QMdiAreaPrivate::arrangeMinimizedSubWindows()
{
    if (!iconTiler)
        iconTiler = new IconTiler;
    rearrange(iconTiler);
}

/*!
    \internal
*/
void QMdiAreaPrivate::activateWindow(QMdiSubWindow *child)
{
    if (childWindows.isEmpty()) {
        Q_ASSERT(!child);
        Q_ASSERT(!active);
        return;
    }

    if (!child) {
        if (active) {
            Q_ASSERT(active->d_func()->isActive);
            active->d_func()->setActive(false);
            resetActiveWindow();
        }
        return;
    }

    if (child->isHidden() || child == active)
        return;

    if (child->d_func()->isActive && active == nullptr)
        child->d_func()->isActive = false;

    child->d_func()->setActive(true);
}

/*!
    \internal
*/
void QMdiAreaPrivate::activateCurrentWindow()
{
    QMdiSubWindow *current = q_func()->currentSubWindow();
    if (current && !isExplicitlyDeactivated(current)) {
        current->d_func()->activationEnabled = true;
        current->d_func()->setActive(true, /*changeFocus=*/false);
    }
}

void QMdiAreaPrivate::activateHighlightedWindow()
{
    if (indexToHighlighted < 0)
        return;

    Q_ASSERT(indexToHighlighted < childWindows.size());
    if (tabToPreviousTimer.isActive())
        activateWindow(nextVisibleSubWindow(-1, QMdiArea::ActivationHistoryOrder));
    else
        activateWindow(childWindows.at(indexToHighlighted));
#if QT_CONFIG(rubberband)
    hideRubberBand();
#endif
}

/*!
    \internal
*/
void QMdiAreaPrivate::emitWindowActivated(QMdiSubWindow *activeWindow)
{
    Q_Q(QMdiArea);
    Q_ASSERT(activeWindow);
    if (activeWindow == active)
        return;
    Q_ASSERT(activeWindow->d_func()->isActive);

    if (!aboutToBecomeActive)
        _q_deactivateAllWindows(activeWindow);
    Q_ASSERT(aboutToBecomeActive);

    // This is true only if 'DontMaximizeSubWindowOnActivation' is disabled
    // and the previous active window was maximized.
    if (showActiveWindowMaximized) {
        if (!activeWindow->isMaximized())
            activeWindow->showMaximized();
        showActiveWindowMaximized = false;
    }

    // Put in front to update activation order.
    const int indexToActiveWindow = childWindows.indexOf(activeWindow);
    Q_ASSERT(indexToActiveWindow != -1);
    const int index = indicesToActivatedChildren.indexOf(indexToActiveWindow);
    Q_ASSERT(index != -1);
    indicesToActivatedChildren.move(index, 0);
    internalRaise(activeWindow);

    if (updatesDisabledByUs) {
        q->setUpdatesEnabled(true);
        updatesDisabledByUs = false;
    }

    Q_ASSERT(aboutToBecomeActive == activeWindow);
    active = activeWindow;
    aboutToBecomeActive = nullptr;
    Q_ASSERT(active->d_func()->isActive);

#if QT_CONFIG(tabbar)
    if (tabBar && tabBar->currentIndex() != indexToActiveWindow)
        tabBar->setCurrentIndex(indexToActiveWindow);
#endif

    if (active->isMaximized() && scrollBarsEnabled())
        updateScrollBars();

    emit q->subWindowActivated(active);
}

/*!
    \internal
*/
void QMdiAreaPrivate::resetActiveWindow(QMdiSubWindow *deactivatedWindow)
{
    Q_Q(QMdiArea);
    if (deactivatedWindow) {
        if (deactivatedWindow != active)
            return;
        active = nullptr;
        if ((aboutToBecomeActive || isActivated || lastWindowAboutToBeDestroyed())
            && !isExplicitlyDeactivated(deactivatedWindow) && !q->window()->isMinimized()) {
            return;
        }
        emit q->subWindowActivated(nullptr);
        return;
    }

    if (aboutToBecomeActive)
        return;

    active = nullptr;
    emit q->subWindowActivated(nullptr);
}

/*!
    \internal
*/
void QMdiAreaPrivate::updateActiveWindow(int removedIndex, bool activeRemoved)
{
    Q_ASSERT(indicesToActivatedChildren.size() == childWindows.size());

    // Update indices list first so that we don't rely
    for (int i = 0; i < indicesToActivatedChildren.size(); ++i) {
        int &index = indicesToActivatedChildren[i];
        if (index > removedIndex)
            --index;
    }

#if QT_CONFIG(tabbar)
    if (tabBar && removedIndex >= 0) {
        const QSignalBlocker blocker(tabBar);
        tabBar->removeTab(removedIndex);
        updateTabBarGeometry();
    }
#endif

    if (childWindows.isEmpty()) {
        showActiveWindowMaximized = false;
        resetActiveWindow();
        return;
    }

    if (indexToHighlighted >= 0) {
#if QT_CONFIG(rubberband)
        // Hide rubber band if highlighted window is removed.
        if (indexToHighlighted == removedIndex)
            hideRubberBand();
        else
#endif
        // or update index if necessary.
        if (indexToHighlighted > removedIndex)
            --indexToHighlighted;
    }

    if (!activeRemoved)
        return;

    // Activate next window.
    QMdiSubWindow *next = nextVisibleSubWindow(0, activationOrder, removedIndex);
    if (next)
        activateWindow(next);
}

/*!
    \internal
*/
void QMdiAreaPrivate::updateScrollBars()
{
    if (ignoreGeometryChange || !scrollBarsEnabled())
        return;

    Q_Q(QMdiArea);
    QSize maxSize = q->maximumViewportSize();
    QSize hbarExtent = hbar->sizeHint();
    QSize vbarExtent = vbar->sizeHint();

    if (q->style()->styleHint(QStyle::SH_ScrollView_FrameOnlyAroundContents, nullptr, q)) {
        const int doubleFrameWidth = frameWidth * 2;
        if (hbarpolicy == Qt::ScrollBarAlwaysOn)
            maxSize.rheight() -= doubleFrameWidth;
        if (vbarpolicy == Qt::ScrollBarAlwaysOn)
            maxSize.rwidth() -= doubleFrameWidth;
        hbarExtent.rheight() += doubleFrameWidth;
        vbarExtent.rwidth() += doubleFrameWidth;
    }

    const QRect childrenRect = active && active->isMaximized()
                               ? active->geometry() : viewport->childrenRect();
    bool useHorizontalScrollBar = useScrollBar(childrenRect, maxSize, Qt::Horizontal);
    bool useVerticalScrollBar = useScrollBar(childrenRect, maxSize, Qt::Vertical);

    if (useHorizontalScrollBar && !useVerticalScrollBar) {
        const QSize max = maxSize - QSize(0, hbarExtent.height());
        useVerticalScrollBar = useScrollBar(childrenRect, max, Qt::Vertical);
    }

    if (useVerticalScrollBar && !useHorizontalScrollBar) {
        const QSize max = maxSize - QSize(vbarExtent.width(), 0);
        useHorizontalScrollBar = useScrollBar(childrenRect, max, Qt::Horizontal);
    }

    if (useHorizontalScrollBar && hbarpolicy != Qt::ScrollBarAlwaysOn)
        maxSize.rheight() -= hbarExtent.height();
    if (useVerticalScrollBar && vbarpolicy != Qt::ScrollBarAlwaysOn)
        maxSize.rwidth() -= vbarExtent.width();

    QRect viewportRect(QPoint(0, 0), maxSize);
    const int startX = q->isLeftToRight() ? childrenRect.left() : viewportRect.right()
                                                                  - childrenRect.right();

    const auto singleStep = defaultSingleStep();

    // Horizontal scroll bar.
    if (isSubWindowsTiled && hbar->value() != 0)
        hbar->setValue(0);
    const int xOffset = startX + hbar->value();
    hbar->setRange(qMin(0, xOffset),
                   qMax(0, xOffset + childrenRect.width() - viewportRect.width()));
    hbar->setPageStep(childrenRect.width());
    hbar->setSingleStep(childrenRect.width() / singleStep);

    // Vertical scroll bar.
    if (isSubWindowsTiled && vbar->value() != 0)
        vbar->setValue(0);
    const int yOffset = childrenRect.top() + vbar->value();
    vbar->setRange(qMin(0, yOffset),
                   qMax(0, yOffset + childrenRect.height() - viewportRect.height()));
    vbar->setPageStep(childrenRect.height());
    vbar->setSingleStep(childrenRect.height() / singleStep);
}

/*!
    \internal
*/
void QMdiAreaPrivate::internalRaise(QMdiSubWindow *mdiChild) const
{
    if (!sanityCheck(mdiChild, "QMdiArea::internalRaise") || childWindows.size() < 2)
        return;

    QMdiSubWindow *stackUnderChild = nullptr;
    if (!windowStaysOnTop(mdiChild)) {
        const auto children = viewport->children(); // take a copy, as raising/stacking under changes the order
        for (QObject *object : children) {
            QMdiSubWindow *child = qobject_cast<QMdiSubWindow *>(object);
            if (!child || !childWindows.contains(child))
                continue;
            if (!child->isHidden() && windowStaysOnTop(child)) {
                if (stackUnderChild)
                    child->stackUnder(stackUnderChild);
                else
                    child->raise();
                stackUnderChild = child;
            }
        }
    }

    if (stackUnderChild)
        mdiChild->stackUnder(stackUnderChild);
    else
        mdiChild->raise();
}

QRect QMdiAreaPrivate::resizeToMinimumTileSize(const QSize &minSubWindowSize, int subWindowCount)
{
    Q_Q(QMdiArea);
    if (!minSubWindowSize.isValid() || subWindowCount <= 0)
        return viewport->rect();

    // Calculate minimum size.
    const int columns = qMax(qCeil(qSqrt(qreal(subWindowCount))), 1);
    const int rows = qMax((subWindowCount % columns) ? (subWindowCount / columns + 1)
                                                     : (subWindowCount / columns), 1);
    const int minWidth = minSubWindowSize.width() * columns;
    const int minHeight = minSubWindowSize.height() * rows;

    // Increase area size if necessary. Scroll bars are provided if we're not able
    // to resize to the minimum size.
    if (!tileCalledFromResizeEvent) {
        QWidget *topLevel = q;
        // Find the topLevel for this area, either a real top-level or a sub-window.
        while (topLevel && !topLevel->isWindow() && topLevel->windowType() != Qt::SubWindow)
            topLevel = topLevel->parentWidget();
        // We don't want sub-subwindows to be placed at the edge, thus add 2 pixels.
        int minAreaWidth = minWidth + left + right + 2;
        int minAreaHeight = minHeight + top + bottom + 2;
        if (hbar->isVisible())
            minAreaHeight += hbar->height();
        if (vbar->isVisible())
            minAreaWidth += vbar->width();
        if (q->style()->styleHint(QStyle::SH_ScrollView_FrameOnlyAroundContents, nullptr, q)) {
            const int frame = q->style()->pixelMetric(QStyle::PM_DefaultFrameWidth, nullptr, q);
            minAreaWidth += 2 * frame;
            minAreaHeight += 2 * frame;
        }
        const QSize diff = QSize(minAreaWidth, minAreaHeight).expandedTo(q->size()) - q->size();
        // Only resize topLevel widget if scroll bars are disabled.
        if (hbarpolicy == Qt::ScrollBarAlwaysOff)
            topLevel->resize(topLevel->size().width() + diff.width(), topLevel->size().height());
        if (vbarpolicy == Qt::ScrollBarAlwaysOff)
            topLevel->resize(topLevel->size().width(), topLevel->size().height() + diff.height());
    }

    QRect domain = viewport->rect();

    // Adjust domain width and provide horizontal scroll bar.
    if (domain.width() < minWidth) {
        domain.setWidth(minWidth);
        if (hbarpolicy == Qt::ScrollBarAlwaysOff)
            q->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        else
            hbar->setValue(0);
    }
    // Adjust domain height and provide vertical scroll bar.
    if (domain.height() < minHeight) {
        domain.setHeight(minHeight);
        if (vbarpolicy  == Qt::ScrollBarAlwaysOff)
            q->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        else
            vbar->setValue(0);
    }
    return domain;
}

/*!
    \internal
*/
bool QMdiAreaPrivate::scrollBarsEnabled() const
{
    return hbarpolicy != Qt::ScrollBarAlwaysOff || vbarpolicy != Qt::ScrollBarAlwaysOff;
}

/*!
    \internal
*/
bool QMdiAreaPrivate::lastWindowAboutToBeDestroyed() const
{
    if (childWindows.size() != 1)
        return false;

    QMdiSubWindow *last = childWindows.at(0);
    if (!last)
        return true;

    if (!last->testAttribute(Qt::WA_DeleteOnClose))
        return false;

    return last->d_func()->data.is_closing;
}

/*!
    \internal
*/
void QMdiAreaPrivate::setChildActivationEnabled(bool enable, bool onlyNextActivationEvent) const
{
    for (QMdiSubWindow *subWindow : childWindows) {
        if (!subWindow || !subWindow->isVisible())
            continue;
        if (onlyNextActivationEvent)
            subWindow->d_func()->ignoreNextActivationEvent = !enable;
        else
            subWindow->d_func()->activationEnabled = enable;
    }
}

/*!
    \internal
    \reimp
*/
void QMdiAreaPrivate::scrollBarPolicyChanged(Qt::Orientation orientation, Qt::ScrollBarPolicy policy)
{
    if (childWindows.isEmpty())
        return;

    const QMdiSubWindow::SubWindowOption option = orientation == Qt::Horizontal ?
        QMdiSubWindow::AllowOutsideAreaHorizontally : QMdiSubWindow::AllowOutsideAreaVertically;
    const bool enable = policy != Qt::ScrollBarAlwaysOff;
    // Take a copy because child->setOption() may indirectly call QCoreApplication::sendEvent(),
    // the latter could call unknown code that could e.g. recurse into the class
    // modifying childWindows.
    const auto subWindows = childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::scrollBarPolicyChanged"))
            continue;
        child->setOption(option, enable);
    }
    updateScrollBars();
}

QList<QMdiSubWindow*>
QMdiAreaPrivate::subWindowList(QMdiArea::WindowOrder order, bool reversed) const
{
    QList<QMdiSubWindow *> list;
    if (childWindows.isEmpty())
        return list;

    if (order == QMdiArea::CreationOrder) {
        for (QMdiSubWindow *child : childWindows) {
            if (!child)
                continue;
            if (!reversed)
                list.append(child);
            else
                list.prepend(child);
        }
    } else if (order == QMdiArea::StackingOrder) {
        for (QObject *object : viewport->children()) {
            QMdiSubWindow *child = qobject_cast<QMdiSubWindow *>(object);
            if (!child || !childWindows.contains(child))
                continue;
            if (!reversed)
                list.append(child);
            else
                list.prepend(child);
        }
    } else { // ActivationHistoryOrder
        Q_ASSERT(indicesToActivatedChildren.size() == childWindows.size());
        for (int i = indicesToActivatedChildren.size() - 1; i >= 0; --i) {
            QMdiSubWindow *child = childWindows.at(indicesToActivatedChildren.at(i));
            if (!child)
                continue;
            if (!reversed)
                list.append(child);
            else
                list.prepend(child);
        }
    }
    return list;
}

/*!
    \internal
*/
void QMdiAreaPrivate::disconnectSubWindow(QObject *subWindow)
{
    if (!subWindow)
        return;

    Q_Q(QMdiArea);
    QObject::disconnect(subWindow, nullptr, q, nullptr);
    subWindow->removeEventFilter(q);
}

/*!
    \internal
*/
QMdiSubWindow *QMdiAreaPrivate::nextVisibleSubWindow(int increaseFactor, QMdiArea::WindowOrder order,
                                                     int removedIndex, int fromIndex) const
{
    if (childWindows.isEmpty())
        return nullptr;

    Q_Q(const QMdiArea);
    const QList<QMdiSubWindow *> subWindows = q->subWindowList(order);
    QMdiSubWindow *current = nullptr;

    if (removedIndex < 0) {
        if (fromIndex >= 0 && fromIndex < subWindows.size())
            current = childWindows.at(fromIndex);
        else
            current = q->currentSubWindow();
    }

    // There's no current sub-window (removed or deactivated),
    // so we have to pick the last active or the next in creation order.
    if (!current) {
        if (removedIndex >= 0 && order == QMdiArea::CreationOrder) {
            int candidateIndex = -1;
            setIndex(&candidateIndex, removedIndex, 0, subWindows.size() - 1, true);
            current = childWindows.at(candidateIndex);
        } else {
            current = subWindows.back();
        }
    }
    Q_ASSERT(current);

    // Find the index for the current sub-window in the given activation order
    const int indexToCurrent = subWindows.indexOf(current);
    const bool increasing = increaseFactor > 0;

    // and use that index + increseFactor as a candidate.
    int index = -1;
    setIndex(&index, indexToCurrent + increaseFactor, 0, subWindows.size() - 1, increasing);
    Q_ASSERT(index != -1);

    // Try to find another window if the candidate is hidden.
    while (subWindows.at(index)->isHidden()) {
        setIndex(&index, index + increaseFactor, 0, subWindows.size() - 1, increasing);
        if (index == indexToCurrent)
            break;
    }

    if (!subWindows.at(index)->isHidden())
        return subWindows.at(index);
    return nullptr;
}

/*!
    \internal
*/
void QMdiAreaPrivate::highlightNextSubWindow(int increaseFactor)
{
    if (childWindows.size() == 1)
        return;

    Q_Q(QMdiArea);
    // There's no highlighted sub-window atm, use current.
    if (indexToHighlighted < 0) {
        QMdiSubWindow *current = q->currentSubWindow();
        if (!current)
            return;
        indexToHighlighted = childWindows.indexOf(current);
    }

    Q_ASSERT(indexToHighlighted >= 0);
    Q_ASSERT(indexToHighlighted < childWindows.size());

    QMdiSubWindow *highlight = nextVisibleSubWindow(increaseFactor, activationOrder, -1, indexToHighlighted);
    if (!highlight)
        return;

#if QT_CONFIG(rubberband)
    if (!rubberBand) {
        rubberBand = new QRubberBand(QRubberBand::Rectangle, q);
        // For accessibility to identify this special widget.
        rubberBand->setObjectName("qt_rubberband"_L1);
        rubberBand->setWindowFlags(rubberBand->windowFlags() | Qt::WindowStaysOnTopHint);
    }
#endif

    // Only highlight if we're not switching back to the previously active window (Ctrl-Tab once).
#if QT_CONFIG(rubberband)
    if (!tabToPreviousTimer.isActive())
        showRubberBandFor(highlight);
#endif

    indexToHighlighted = childWindows.indexOf(highlight);
    Q_ASSERT(indexToHighlighted >= 0);
}

#if QT_CONFIG(rubberband)
void QMdiAreaPrivate::showRubberBandFor(QMdiSubWindow *subWindow)
{
    if (!subWindow || !rubberBand)
        return;

#if QT_CONFIG(tabbar)
    if (viewMode == QMdiArea::TabbedView)
        rubberBand->setGeometry(tabBar->tabRect(childWindows.indexOf(subWindow)));
    else
#endif
        rubberBand->setGeometry(subWindow->geometry());

    rubberBand->raise();
    rubberBand->show();
}
#endif // QT_CONFIG(rubberBand)
/*!
    \internal
    \since 4.4
*/
void QMdiAreaPrivate::setViewMode(QMdiArea::ViewMode mode)
{
    Q_Q(QMdiArea);
    if (viewMode == mode || inViewModeChange)
        return;

    // Just a guard since we cannot set viewMode = mode here.
    inViewModeChange = true;

#if QT_CONFIG(tabbar)
    if (mode == QMdiArea::TabbedView) {
        Q_ASSERT(!tabBar);
        tabBar = new QMdiAreaTabBar(q);
        tabBar->setDocumentMode(documentMode);
        tabBar->setTabsClosable(tabsClosable);
        tabBar->setMovable(tabsMovable);
#if QT_CONFIG(tabwidget)
        tabBar->setShape(_q_tb_tabBarShapeFrom(tabShape, tabPosition));
#endif

        isSubWindowsTiled = false;

        // Take a copy as tabBar->addTab() will (indirectly) create a connection between
        // the tab close button clicked() signal and the _q_closeTab() slot, which may
        // indirectly call QCoreApplication::sendEvent(), the latter could result in
        // invoking unknown code that could e.g. recurse into the class modifying childWindows.
        const auto subWindows = childWindows;
        for (QMdiSubWindow *subWindow : subWindows)
            tabBar->addTab(subWindow->windowIcon(), tabTextFor(subWindow));

        QMdiSubWindow *current = q->currentSubWindow();
        if (current) {
            tabBar->setCurrentIndex(childWindows.indexOf(current));
            // Restore sub-window (i.e. cleanup buttons in menu bar and window title).
            if (current->isMaximized())
                current->showNormal();

            viewMode = mode;

            // Now, maximize it.
            if (!q->testOption(QMdiArea::DontMaximizeSubWindowOnActivation)) {
                current->showMaximized();
            }
        } else {
            viewMode = mode;
        }

        if (q->isVisible())
            tabBar->show();
        updateTabBarGeometry();

        QObject::connect(tabBar, SIGNAL(currentChanged(int)), q, SLOT(_q_currentTabChanged(int)));
        QObject::connect(tabBar, SIGNAL(tabCloseRequested(int)), q, SLOT(_q_closeTab(int)));
        QObject::connect(tabBar, SIGNAL(tabMoved(int,int)), q, SLOT(_q_moveTab(int,int)));
    } else
#endif // QT_CONFIG(tabbar)
    { // SubWindowView
#if QT_CONFIG(tabbar)
        delete tabBar;
        tabBar = nullptr;
#endif // QT_CONFIG(tabbar)

        viewMode = mode;
        q->setViewportMargins(0, 0, 0, 0);
        indexToLastActiveTab = -1;

        QMdiSubWindow *current = q->currentSubWindow();
        if (current && current->isMaximized())
            current->showNormal();
    }

    Q_ASSERT(viewMode == mode);
    inViewModeChange = false;
}

#if QT_CONFIG(tabbar)
/*!
    \internal
*/
void QMdiAreaPrivate::updateTabBarGeometry()
{
    if (!tabBar)
        return;

    Q_Q(QMdiArea);
#if QT_CONFIG(tabwidget)
    Q_ASSERT(_q_tb_tabBarShapeFrom(tabShape, tabPosition) == tabBar->shape());
#endif
    const QSize tabBarSizeHint = tabBar->sizeHint();

    int areaHeight = q->height();
    if (hbar && hbar->isVisible())
        areaHeight -= hbar->height();

    int areaWidth = q->width();
    if (vbar && vbar->isVisible())
        areaWidth -= vbar->width();

    QRect tabBarRect;
#if QT_CONFIG(tabwidget)
    switch (tabPosition) {
    case QTabWidget::North:
        q->setViewportMargins(0, tabBarSizeHint.height(), 0, 0);
        tabBarRect = QRect(0, 0, areaWidth, tabBarSizeHint.height());
        break;
    case QTabWidget::South:
        q->setViewportMargins(0, 0, 0, tabBarSizeHint.height());
        tabBarRect = QRect(0, areaHeight - tabBarSizeHint.height(), areaWidth, tabBarSizeHint.height());
        break;
    case QTabWidget::East:
        if (q->layoutDirection() == Qt::LeftToRight)
            q->setViewportMargins(0, 0, tabBarSizeHint.width(), 0);
        else
            q->setViewportMargins(tabBarSizeHint.width(), 0, 0, 0);
        tabBarRect = QRect(areaWidth - tabBarSizeHint.width(), 0, tabBarSizeHint.width(), areaHeight);
        break;
    case QTabWidget::West:
        if (q->layoutDirection() == Qt::LeftToRight)
            q->setViewportMargins(tabBarSizeHint.width(), 0, 0, 0);
        else
            q->setViewportMargins(0, 0, tabBarSizeHint.width(), 0);
        tabBarRect = QRect(0, 0, tabBarSizeHint.width(), areaHeight);
        break;
    default:
        break;
    }
#endif // QT_CONFIG(tabwidget)

    tabBar->setGeometry(QStyle::visualRect(q->layoutDirection(), q->contentsRect(), tabBarRect));
}

/*!
    \internal
*/
void QMdiAreaPrivate::refreshTabBar()
{
    if (!tabBar)
        return;

    tabBar->setDocumentMode(documentMode);
    tabBar->setTabsClosable(tabsClosable);
    tabBar->setMovable(tabsMovable);
#if QT_CONFIG(tabwidget)
    tabBar->setShape(_q_tb_tabBarShapeFrom(tabShape, tabPosition));
#endif
    updateTabBarGeometry();
}
#endif // QT_CONFIG(tabbar)

/*!
    Constructs an empty mdi area. \a parent is passed to QWidget's
    constructor.
*/
QMdiArea::QMdiArea(QWidget *parent)
    : QAbstractScrollArea(*new QMdiAreaPrivate, parent)
{
    setBackground(palette().brush(QPalette::Dark));
    setFrameStyle(QFrame::NoFrame);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setViewport(nullptr);
    setFocusPolicy(Qt::NoFocus);
    QApplication::instance()->installEventFilter(this);
}

/*!
    Destroys the MDI area.
*/
QMdiArea::~QMdiArea()
{
    Q_D(QMdiArea);
    delete d->cascader;
    d->cascader = nullptr;

    delete d->regularTiler;
    d->regularTiler = nullptr;

    delete d->iconTiler;
    d->iconTiler = nullptr;

    delete d->placer;
    d->placer = nullptr;
}

/*!
    \reimp
*/
QSize QMdiArea::sizeHint() const
{
    // Calculate a proper scale factor for the desktop's size.
    // This also takes into account that we can have nested workspaces.
    int nestedCount = 0;
    QWidget *widget = this->parentWidget();
    while (widget) {
        if (qobject_cast<QMdiArea *>(widget))
            ++nestedCount;
        widget = widget->parentWidget();
    }
    const int scaleFactor = 3 * (nestedCount + 1);

    QSize desktopSize = QGuiApplication::primaryScreen()->virtualSize();
    QSize size(desktopSize.width() * 2 / scaleFactor, desktopSize.height() * 2 / scaleFactor);
    for (QMdiSubWindow *child : d_func()->childWindows) {
        if (!sanityCheck(child, "QMdiArea::sizeHint"))
            continue;
        size = size.expandedTo(child->sizeHint());
    }
    return size;
}

/*!
    \reimp
*/
QSize QMdiArea::minimumSizeHint() const
{
    Q_D(const QMdiArea);
    QSize size(style()->pixelMetric(QStyle::PM_MdiSubWindowMinimizedWidth, nullptr, this),
               style()->pixelMetric(QStyle::PM_TitleBarHeight, nullptr, this));
    size = size.expandedTo(QAbstractScrollArea::minimumSizeHint());
    if (!d->scrollBarsEnabled()) {
        for (QMdiSubWindow *child : d->childWindows) {
            if (!sanityCheck(child, "QMdiArea::sizeHint"))
                continue;
            size = size.expandedTo(child->minimumSizeHint());
        }
    }
    return size;
}

/*!
    Returns a pointer to the current subwindow, or \nullptr if there is
    no current subwindow.

    This function will return the same as activeSubWindow() if
    the QApplication containing QMdiArea is active.

    \sa activeSubWindow(), QApplication::activeWindow()
*/
QMdiSubWindow *QMdiArea::currentSubWindow() const
{
    Q_D(const QMdiArea);
    if (d->childWindows.isEmpty())
        return nullptr;

    if (d->active)
        return d->active;

    if (d->isActivated && !window()->isMinimized())
        return nullptr;

    Q_ASSERT(d->indicesToActivatedChildren.size() > 0);
    int index = d->indicesToActivatedChildren.at(0);
    Q_ASSERT(index >= 0 && index < d->childWindows.size());
    QMdiSubWindow *current = d->childWindows.at(index);
    Q_ASSERT(current);
    return current;
}

/*!
    Returns a pointer to the current active subwindow. If no
    window is currently active, \nullptr is returned.

    Subwindows are treated as top-level windows with respect to
    window state, i.e., if a widget outside the MDI area is the active
    window, no subwindow will be active. Note that if a widget in the
    window in which the MDI area lives gains focus, the window will be
    activated.

    \sa setActiveSubWindow(), Qt::WindowState
*/
QMdiSubWindow *QMdiArea::activeSubWindow() const
{
    Q_D(const QMdiArea);
    return d->active;
}

/*!
    Activates the subwindow \a window. If \a window is \nullptr, any
    current active window is deactivated.

    \sa activeSubWindow()
*/
void QMdiArea::setActiveSubWindow(QMdiSubWindow *window)
{
    Q_D(QMdiArea);
    if (!window) {
        d->activateWindow(nullptr);
        return;
    }

    if (Q_UNLIKELY(d->childWindows.isEmpty())) {
        qWarning("QMdiArea::setActiveSubWindow: workspace is empty");
        return;
    }

    if (Q_UNLIKELY(d->childWindows.indexOf(window) == -1)) {
        qWarning("QMdiArea::setActiveSubWindow: window is not inside workspace");
        return;
    }

    d->activateWindow(window);
}

/*!
    Closes the active subwindow.

    \sa closeAllSubWindows()
*/
void QMdiArea::closeActiveSubWindow()
{
    Q_D(QMdiArea);
    if (d->active)
        d->active->close();
}

/*!
    Returns a list of all subwindows in the MDI area. If \a order is
    CreationOrder (the default), the windows are sorted in the order
    in which they were inserted into the workspace. If \a order is
    StackingOrder, the windows are listed in their stacking order,
    with the topmost window as the last item in the list. If \a order
    is ActivationHistoryOrder, the windows are listed according to
    their recent activation history.

    \sa WindowOrder
*/
QList<QMdiSubWindow *> QMdiArea::subWindowList(WindowOrder order) const
{
    Q_D(const QMdiArea);
    return d->subWindowList(order, false);
}

/*!
    Closes all subwindows by sending a QCloseEvent to each window.
    You may receive subWindowActivated() signals from subwindows
    before they are closed (if the MDI area activates the subwindow
    when another is closing).

    Subwindows that ignore the close event will remain open.

    \sa closeActiveSubWindow()
*/
void QMdiArea::closeAllSubWindows()
{
    Q_D(QMdiArea);
    if (d->childWindows.isEmpty())
        return;

    d->isSubWindowsTiled = false;
    // Take a copy because the child->close() call below may end up indirectly calling
    // QCoreApplication::send{Spontaneous}Event(), which may call unknown code that
    // could e.g. recurse into the class modifying d->childWindows.
    const auto subWindows = d->childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::closeAllSubWindows"))
            continue;
        child->close();
    }

    d->updateScrollBars();
}

/*!
    Gives the keyboard focus to another window in the list of child
    windows.  The window activated will be the next one determined
    by the current \l{QMdiArea::WindowOrder} {activation order}.

    \sa activatePreviousSubWindow(), QMdiArea::WindowOrder
*/
void QMdiArea::activateNextSubWindow()
{
    Q_D(QMdiArea);
    if (d->childWindows.isEmpty())
        return;

    QMdiSubWindow *next = d->nextVisibleSubWindow(1, d->activationOrder);
    if (next)
        d->activateWindow(next);
}

/*!
    Gives the keyboard focus to another window in the list of child
    windows.  The window activated will be the previous one determined
    by the current \l{QMdiArea::WindowOrder} {activation order}.

    \sa activateNextSubWindow(), QMdiArea::WindowOrder
*/
void QMdiArea::activatePreviousSubWindow()
{
    Q_D(QMdiArea);
    if (d->childWindows.isEmpty())
        return;

    QMdiSubWindow *previous = d->nextVisibleSubWindow(-1, d->activationOrder);
    if (previous)
        d->activateWindow(previous);
}

/*!
    Adds \a widget as a new subwindow to the MDI area.  If \a
    windowFlags are non-zero, they will override the flags set on the
    widget.

    The \a widget can be either a QMdiSubWindow or another QWidget
    (in which case the MDI area will create a subwindow and set the \a
    widget as the internal widget).

    \note Once the subwindow has been added, its parent will be the
    \e{viewport widget} of the QMdiArea.

    \snippet mdiarea/mdiareasnippets.cpp 1

    When you create your own subwindow, you must set the
    Qt::WA_DeleteOnClose widget attribute if you want the window to be
    deleted when closed in the MDI area. If not, the window will be
    hidden and the MDI area will not activate the next subwindow.

    Returns the QMdiSubWindow that is added to the MDI area.

    \sa removeSubWindow()
*/
QMdiSubWindow *QMdiArea::addSubWindow(QWidget *widget, Qt::WindowFlags windowFlags)
{
    if (Q_UNLIKELY(!widget)) {
        qWarning("QMdiArea::addSubWindow: null pointer to widget");
        return nullptr;
    }

    Q_D(QMdiArea);
    // QWidget::setParent clears focusWidget so store it
    QWidget *childFocus = widget->focusWidget();
    QMdiSubWindow *child = qobject_cast<QMdiSubWindow *>(widget);

    // Widget is already a QMdiSubWindow
    if (child) {
        if (Q_UNLIKELY(d->childWindows.indexOf(child) != -1)) {
            qWarning("QMdiArea::addSubWindow: window is already added");
            return child;
        }
        child->setParent(viewport(), windowFlags ? windowFlags : child->windowFlags());
    // Create a QMdiSubWindow
    } else {
        child = new QMdiSubWindow(viewport(), windowFlags);
        child->setAttribute(Qt::WA_DeleteOnClose);
        child->setWidget(widget);
        Q_ASSERT(child->testAttribute(Qt::WA_DeleteOnClose));
    }

    d->appendChild(child);

    if (childFocus)
        childFocus->setFocus();

    return child;
}

/*!
    Removes \a widget from the MDI area. The \a widget must be
    either a QMdiSubWindow or a widget that is the internal widget of
    a subwindow. Note \a widget is never actually deleted by QMdiArea.
    If a QMdiSubWindow is passed in, its parent is set to \nullptr and it is
    removed; but if an internal widget is passed in, the child widget
    is set to \nullptr and the QMdiSubWindow is \e not removed.

    \sa addSubWindow()
*/
void QMdiArea::removeSubWindow(QWidget *widget)
{
    if (Q_UNLIKELY(!widget)) {
        qWarning("QMdiArea::removeSubWindow: null pointer to widget");
        return;
    }

    Q_D(QMdiArea);
    if (d->childWindows.isEmpty())
        return;

    if (QMdiSubWindow *child = qobject_cast<QMdiSubWindow *>(widget)) {
        int index = d->childWindows.indexOf(child);
        if (Q_UNLIKELY(index == -1)) {
            qWarning("QMdiArea::removeSubWindow: window is not inside workspace");
            return;
        }
        d->disconnectSubWindow(child);
        d->childWindows.removeAll(child);
        d->indicesToActivatedChildren.removeAll(index);
        d->updateActiveWindow(index, d->active == child);
        child->setParent(nullptr);
        return;
    }

    bool found = false;
    // Take a copy because child->setWidget(nullptr) will indirectly
    // QCoreApplication::sendEvent(); the latter could call unknown code that could
    // e.g. recurse into the class modifying d->childWindows.
    const auto subWindows = d->childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::removeSubWindow"))
            continue;
        if (child->widget() == widget) {
            child->setWidget(nullptr);
            Q_ASSERT(!child->widget());
            found = true;
            break;
        }
    }

    if (Q_UNLIKELY(!found))
        qWarning("QMdiArea::removeSubWindow: widget is not child of any window inside QMdiArea");
}

/*!
    \property QMdiArea::background
    \brief the background brush for the workspace

    This property sets the background brush for the workspace area
    itself. By default, it is a gray color, but can be any brush
    (e.g., colors, gradients or pixmaps).
*/
QBrush QMdiArea::background() const
{
    return d_func()->background;
}

void QMdiArea::setBackground(const QBrush &brush)
{
    Q_D(QMdiArea);
    if (d->background != brush) {
        d->background = brush;
        d->viewport->setAttribute(Qt::WA_OpaquePaintEvent, brush.isOpaque());
        d->viewport->update();
    }
}


/*!
    \property QMdiArea::activationOrder
    \brief the ordering criteria for subwindow lists
    \since 4.4

    This property specifies the ordering criteria for the list of
    subwindows returned by subWindowList(). By default, it is the window
    creation order.

    \sa subWindowList()
*/
QMdiArea::WindowOrder QMdiArea::activationOrder() const
{
    Q_D(const QMdiArea);
    return d->activationOrder;
}

void QMdiArea::setActivationOrder(WindowOrder order)
{
    Q_D(QMdiArea);
    if (order != d->activationOrder)
        d->activationOrder = order;
}

/*!
    If \a on is true, \a option is enabled on the MDI area; otherwise
    it is disabled. See AreaOption for the effect of each option.

    \sa AreaOption, testOption()
*/
void QMdiArea::setOption(AreaOption option, bool on)
{
    Q_D(QMdiArea);
    d->options.setFlag(option, on);
}

/*!
    Returns \c true if \a option is enabled; otherwise returns \c false.

    \sa AreaOption, setOption()
*/
bool QMdiArea::testOption(AreaOption option) const
{
    return d_func()->options & option;
}

/*!
    \property QMdiArea::viewMode
    \brief the way sub-windows are displayed in the QMdiArea.
    \since 4.4

    By default, the SubWindowView is used to display sub-windows.

    \sa ViewMode, setTabShape(), setTabPosition()
*/
QMdiArea::ViewMode QMdiArea::viewMode() const
{
    Q_D(const QMdiArea);
    return d->viewMode;
}

void QMdiArea::setViewMode(ViewMode mode)
{
    Q_D(QMdiArea);
    d->setViewMode(mode);
}

#if QT_CONFIG(tabbar)
/*!
    \property QMdiArea::documentMode
    \brief whether the tab bar is set to document mode in tabbed view mode.
    \since 4.5

    Document mode is disabled by default.

    \sa QTabBar::documentMode, setViewMode()
*/
bool QMdiArea::documentMode() const
{
    Q_D(const QMdiArea);
    return d->documentMode;
}

void QMdiArea::setDocumentMode(bool enabled)
{
    Q_D(QMdiArea);
    if (d->documentMode == enabled)
        return;

    d->documentMode = enabled;
    d->refreshTabBar();
}

/*!
    \property QMdiArea::tabsClosable
    \brief whether the tab bar should place close buttons on each tab in tabbed view mode.
    \since 4.8

    Tabs are not closable by default.

    \sa QTabBar::tabsClosable, setViewMode()
*/
bool QMdiArea::tabsClosable() const
{
    Q_D(const QMdiArea);
    return d->tabsClosable;
}

void QMdiArea::setTabsClosable(bool closable)
{
    Q_D(QMdiArea);
    if (d->tabsClosable == closable)
        return;

    d->tabsClosable = closable;
    d->refreshTabBar();
}

/*!
    \property QMdiArea::tabsMovable
    \brief whether the user can move the tabs within the tabbar area in tabbed view mode.
    \since 4.8

    Tabs are not movable by default.

    \sa QTabBar::movable, setViewMode()
*/
bool QMdiArea::tabsMovable() const
{
    Q_D(const QMdiArea);
    return d->tabsMovable;
}

void QMdiArea::setTabsMovable(bool movable)
{
    Q_D(QMdiArea);
    if (d->tabsMovable == movable)
        return;

    d->tabsMovable = movable;
    d->refreshTabBar();
}
#endif // QT_CONFIG(tabbar)

#if QT_CONFIG(tabwidget)
/*!
    \property QMdiArea::tabShape
    \brief the shape of the tabs in tabbed view mode.
    \since 4.4

    Possible values for this property are QTabWidget::Rounded
    (default) or QTabWidget::Triangular.

    \sa QTabWidget::TabShape, setViewMode()
*/
QTabWidget::TabShape QMdiArea::tabShape() const
{
    Q_D(const QMdiArea);
    return d->tabShape;
}

void QMdiArea::setTabShape(QTabWidget::TabShape shape)
{
    Q_D(QMdiArea);
    if (d->tabShape == shape)
        return;

    d->tabShape = shape;
    d->refreshTabBar();
}

/*!
    \property QMdiArea::tabPosition
    \brief the position of the tabs in tabbed view mode.
    \since 4.4

    Possible values for this property are described by the
    QTabWidget::TabPosition enum.

    \sa QTabWidget::TabPosition, setViewMode()
*/
QTabWidget::TabPosition QMdiArea::tabPosition() const
{
    Q_D(const QMdiArea);
    return d->tabPosition;
}

void QMdiArea::setTabPosition(QTabWidget::TabPosition position)
{
    Q_D(QMdiArea);
    if (d->tabPosition == position)
        return;

    d->tabPosition = position;
    d->refreshTabBar();
}
#endif // QT_CONFIG(tabwidget)

/*!
    \reimp
*/
void QMdiArea::childEvent(QChildEvent *childEvent)
{
    Q_D(QMdiArea);
    if (childEvent->type() == QEvent::ChildPolished) {
        if (QMdiSubWindow *mdiChild = qobject_cast<QMdiSubWindow *>(childEvent->child())) {
            if (d->childWindows.indexOf(mdiChild) == -1)
                d->appendChild(mdiChild);
        }
    }
}

/*!
    \reimp
*/
void QMdiArea::resizeEvent(QResizeEvent *resizeEvent)
{
    Q_D(QMdiArea);
    if (d->childWindows.isEmpty()) {
        resizeEvent->ignore();
        return;
    }

#if QT_CONFIG(tabbar)
    d->updateTabBarGeometry();
#endif

    // Re-tile the views if we're in tiled mode. Re-tile means we will change
    // the geometry of the children, which in turn means 'isSubWindowsTiled'
    // is set to false, so we have to update the state at the end.
    if (d->isSubWindowsTiled) {
        d->tileCalledFromResizeEvent = true;
        tileSubWindows();
        d->tileCalledFromResizeEvent = false;
        d->isSubWindowsTiled = true;
        d->startResizeTimer();
        // We don't have scroll bars or any maximized views.
        return;
    }

    // Resize maximized views.
    bool hasMaximizedSubWindow = false;
    // Take a copy because child->resize() may call QCoreApplication::sendEvent()
    // which may invoke unknown code, that could e.g. recurse into the class
    // modifying d->childWindows.
    const auto subWindows = d->childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (sanityCheck(child, "QMdiArea::resizeEvent") && child->isMaximized()
                && child->size() != resizeEvent->size()) {
            auto realSize = resizeEvent->size();
            const auto minSizeHint = child->minimumSizeHint();
            // QMdiSubWindow is no tlw so minimumSize() is not set by the layout manager
            // and therefore we have to take care by ourself that we're not getting smaller
            // than allowed
            if (minSizeHint.isValid())
                realSize = realSize.expandedTo(minSizeHint);
            child->resize(realSize);
            if (!hasMaximizedSubWindow)
                hasMaximizedSubWindow = true;
        }
    }

    d->updateScrollBars();

    // Minimized views are stacked under maximized views so there's
    // no need to re-arrange minimized views on-demand. Start a timer
    // just to make things faster with subsequent resize events.
    if (hasMaximizedSubWindow)
        d->startResizeTimer();
    else
        d->arrangeMinimizedSubWindows();
}

/*!
    \reimp
*/
void QMdiArea::timerEvent(QTimerEvent *timerEvent)
{
    Q_D(QMdiArea);
    if (timerEvent->id() == d->resizeTimer.id()) {
        d->resizeTimer.stop();
        d->arrangeMinimizedSubWindows();
    } else if (timerEvent->id() == d->tabToPreviousTimer.id()) {
        d->tabToPreviousTimer.stop();
        if (d->indexToHighlighted < 0)
            return;
#if QT_CONFIG(rubberband)
        // We're not doing a "quick switch" ... show rubber band.
        Q_ASSERT(d->indexToHighlighted < d->childWindows.size());
        Q_ASSERT(d->rubberBand);
        d->showRubberBandFor(d->childWindows.at(d->indexToHighlighted));
#endif
    }
}

/*!
    \reimp
*/
void QMdiArea::showEvent(QShowEvent *showEvent)
{
    Q_D(QMdiArea);
    if (!d->pendingRearrangements.isEmpty()) {
        bool skipPlacement = false;
        // Take a copy because d->rearrange() may modify d->pendingRearrangements
        const auto pendingRearrange = d->pendingRearrangements;
        for (Rearranger *rearranger : pendingRearrange) {
            // If this is the case, we don't have to lay out pending child windows
            // since the rearranger will find a placement for them.
            if (rearranger->type() != Rearranger::IconTiler && !skipPlacement)
                skipPlacement = true;
            d->rearrange(rearranger);
        }
        d->pendingRearrangements.clear();

        if (skipPlacement && !d->pendingPlacements.isEmpty())
            d->pendingPlacements.clear();
    }

    if (!d->pendingPlacements.isEmpty()) {
        // Nothing obvious in the loop body changes the container (in this code path)
        // during iteration, this is calling into a non-const method that does change
        // the container when called from other places. So take a copy anyway for good
        // measure.
        const auto copy = d->pendingPlacements;
        for (QMdiSubWindow *window : copy) {
            if (!window)
                continue;
            if (d->viewMode == TabbedView && window->d_func()->isActive && !d->active) {
                d->showActiveWindowMaximized = true;
                d->emitWindowActivated(window); // Also maximizes the window
                continue;
            }
            if (!window->testAttribute(Qt::WA_Resized)) {
                QSize newSize(window->sizeHint().boundedTo(viewport()->size()));
                window->resize(newSize.expandedTo(qSmartMinSize(window)));
            }
            if (!window->testAttribute(Qt::WA_Moved) && !window->isMinimized()
                    && !window->isMaximized()) {
                d->place(d->placer, window);
            }
        }
        d->pendingPlacements.clear();
    }

    d->setChildActivationEnabled(true);
    d->activateCurrentWindow();

    QAbstractScrollArea::showEvent(showEvent);
}

/*!
    \reimp
*/
bool QMdiArea::viewportEvent(QEvent *event)
{
    Q_D(QMdiArea);
    switch (event->type()) {
    case QEvent::ChildRemoved: {
        d->isSubWindowsTiled = false;
        QObject *removedChild = static_cast<QChildEvent *>(event)->child();
        for (int i = 0; i < d->childWindows.size(); ++i) {
            QObject *child = d->childWindows.at(i);
            if (!child || child == removedChild || !child->parent()
                    || child->parent() != viewport()) {
                if (!testOption(DontMaximizeSubWindowOnActivation)) {
                    // In this case we can only rely on the child being a QObject
                    // (or 0), but let's try and see if we can get more information.
                    QWidget *mdiChild = qobject_cast<QWidget *>(removedChild);
                    if (mdiChild && mdiChild->isMaximized())
                        d->showActiveWindowMaximized = true;
                }
                d->disconnectSubWindow(child);
                const bool activeRemoved = i == d->indicesToActivatedChildren.at(0);
                d->childWindows.removeAt(i);
                d->indicesToActivatedChildren.removeAll(i);
                d->updateActiveWindow(i, activeRemoved);
                d->arrangeMinimizedSubWindows();
                break;
            }
        }
        d->updateScrollBars();
        break;
    }
    case QEvent::Destroy:
        d->isSubWindowsTiled = false;
        d->resetActiveWindow();
        d->childWindows.clear();
        qWarning("QMdiArea: Deleting the view port is undefined, use setViewport instead.");
        break;
    default:
        break;
    }
    return QAbstractScrollArea::viewportEvent(event);
}

/*!
    \reimp
*/
void QMdiArea::scrollContentsBy(int dx, int dy)
{
    Q_D(QMdiArea);
    const bool wasSubWindowsTiled = d->isSubWindowsTiled;
    d->ignoreGeometryChange = true;
    viewport()->scroll(isLeftToRight() ? dx : -dx, dy);
    d->arrangeMinimizedSubWindows();
    d->ignoreGeometryChange = false;
    if (wasSubWindowsTiled)
        d->isSubWindowsTiled = true;
}

/*!
    Arranges all child windows in a tile pattern.

    \sa cascadeSubWindows()
*/
void QMdiArea::tileSubWindows()
{
    Q_D(QMdiArea);
    if (!d->regularTiler)
        d->regularTiler = new RegularTiler;
    d->rearrange(d->regularTiler);
}

/*!
    Arranges all the child windows in a cascade pattern.

    \sa tileSubWindows()
*/
void QMdiArea::cascadeSubWindows()
{
    Q_D(QMdiArea);
    if (!d->cascader)
        d->cascader = new SimpleCascader;
    d->rearrange(d->cascader);
}

/*!
    \reimp
*/
bool QMdiArea::event(QEvent *event)
{
    Q_D(QMdiArea);
    switch (event->type()) {
    case QEvent::WindowActivate: {
        d->isActivated = true;
        if (d->childWindows.isEmpty())
            break;
        if (!d->active)
            d->activateCurrentWindow();
        d->setChildActivationEnabled(false, true);
        break;
    }
    case QEvent::WindowDeactivate:
        d->isActivated = false;
        d->setChildActivationEnabled(false, true);
        break;
    case QEvent::StyleChange:
        // Re-tile the views if we're in tiled mode. Re-tile means we will change
        // the geometry of the children, which in turn means 'isSubWindowsTiled'
        // is set to false, so we have to update the state at the end.
        if (d->isSubWindowsTiled) {
            tileSubWindows();
            d->isSubWindowsTiled = true;
        }
        break;
    case QEvent::WindowIconChange: {
        // Take a copy because QCoreApplication::sendEvent() may call unknown code,
        // that may cause recursing into the class
        const auto subWindows = d->childWindows;
        for (QMdiSubWindow *window : subWindows) {
            if (sanityCheck(window, "QMdiArea::WindowIconChange"))
                QCoreApplication::sendEvent(window, event);
        }
        break;
    }
    case QEvent::Hide:
        d->setActive(d->active, false, false);
        d->setChildActivationEnabled(false);
        break;
#if QT_CONFIG(tabbar)
    case QEvent::LayoutDirectionChange:
        d->updateTabBarGeometry();
        break;
#endif
    default:
        break;
    }
    return QAbstractScrollArea::event(event);
}

/*!
    \reimp
*/
bool QMdiArea::eventFilter(QObject *object, QEvent *event)
{
    if (!object)
        return QAbstractScrollArea::eventFilter(object, event);

    Q_D(QMdiArea);
    // Global key events with Ctrl modifier.
    if (event->type() == QEvent::KeyPress || event->type() == QEvent::KeyRelease) {

        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        // Ignore key events without a Ctrl modifier (except for press/release on the modifier itself).
        if (!(keyEvent->modifiers() & Qt::ControlModifier) && keyEvent->key() != Qt::Key_Control)
            return QAbstractScrollArea::eventFilter(object, event);

        // Find closest mdi area (in case we have a nested workspace).
        QMdiArea *area = mdiAreaParent(static_cast<QWidget *>(object));
        if (!area)
            return QAbstractScrollArea::eventFilter(object, event);

        const bool keyPress = (event->type() == QEvent::KeyPress);

        // 1) Ctrl-Tab once -> activate the previously active window.
        // 2) Ctrl-Tab (Tab, Tab, ...) -> iterate through all windows (activateNextSubWindow()).
        // 3) Ctrl-Shift-Tab (Tab, Tab, ...) -> iterate through all windows in the opposite
        //    direction (activatePreviousSubWindow())
        switch (keyEvent->key()) {
        case Qt::Key_Control:
            if (keyPress)
                area->d_func()->startTabToPreviousTimer();
            else
                area->d_func()->activateHighlightedWindow();
            break;
        case Qt::Key_Tab:
        case Qt::Key_Backtab:
            if (keyPress)
                area->d_func()->highlightNextSubWindow(keyEvent->key() == Qt::Key_Tab ? 1 : -1);
            return true;
#if QT_CONFIG(rubberband)
        case Qt::Key_Escape:
            area->d_func()->hideRubberBand();
            break;
#endif
        default:
            break;
        }
        return QAbstractScrollArea::eventFilter(object, event);
    }

    QMdiSubWindow *subWindow = qobject_cast<QMdiSubWindow *>(object);

    if (!subWindow) {
        // QApplication events:
        if (event->type() == QEvent::ApplicationActivate && !d->active
            && isVisible() && !window()->isMinimized()) {
            d->activateCurrentWindow();
        } else if (event->type() == QEvent::ApplicationDeactivate && d->active) {
            d->setActive(d->active, false, false);
        }
        return QAbstractScrollArea::eventFilter(object, event);
    }

    if (subWindow->mdiArea() != this)
        return QAbstractScrollArea::eventFilter(object, event);

    // QMdiSubWindow events:
    switch (event->type()) {
    case QEvent::Move:
    case QEvent::Resize:
        if (d->tileCalledFromResizeEvent)
            break;
        d->updateScrollBars();
        if (!subWindow->isMinimized())
            d->isSubWindowsTiled = false;
        break;
    case QEvent::Show:
#if QT_CONFIG(tabbar)
        if (d->tabBar) {
            const int tabIndex = d->childWindows.indexOf(subWindow);
            if (!d->tabBar->isTabEnabled(tabIndex))
                d->tabBar->setTabEnabled(tabIndex, true);
        }
#endif // QT_CONFIG(tabbar)
        Q_FALLTHROUGH();
    case QEvent::Hide:
        // Do not reset the isSubWindowsTiled flag if the event is a spontaneous system window event.
        // This ensures that tiling will be performed during the resizeEvent after an application
        // window minimize (hide) and then restore (show).
        if (!event->spontaneous())
            d->isSubWindowsTiled = false;
        break;
#if QT_CONFIG(rubberband)
    case QEvent::Close:
        if (d->childWindows.indexOf(subWindow) == d->indexToHighlighted)
            d->hideRubberBand();
        break;
#endif
#if QT_CONFIG(tabbar)
    case QEvent::WindowTitleChange:
    case QEvent::ModifiedChange:
        if (d->tabBar)
            d->tabBar->setTabText(d->childWindows.indexOf(subWindow), tabTextFor(subWindow));
        break;
    case QEvent::WindowIconChange:
        if (d->tabBar)
            d->tabBar->setTabIcon(d->childWindows.indexOf(subWindow), subWindow->windowIcon());
        break;
#endif // QT_CONFIG(tabbar)
    default:
        break;
    }
    return QAbstractScrollArea::eventFilter(object, event);
}

/*!
    \reimp
*/
void QMdiArea::paintEvent(QPaintEvent *paintEvent)
{
    Q_D(QMdiArea);
    QPainter painter(d->viewport);
    for (const QRect &exposedRect : paintEvent->region())
        painter.fillRect(exposedRect, d->background);
}

/*!
    This slot is called by QAbstractScrollArea after setViewport() has been
    called. Reimplement this function in a subclass of QMdiArea to
    initialize the new \a viewport before it is used.

    \sa setViewport()
*/
void QMdiArea::setupViewport(QWidget *viewport)
{
    Q_D(QMdiArea);
    if (viewport)
        viewport->setAttribute(Qt::WA_OpaquePaintEvent, d->background.isOpaque());
    // Take a copy because the child->setParent() call below may call QCoreApplication::sendEvent()
    // which may call unknown code that could e.g. recurse into the class modifying d->childWindows.
    const auto subWindows = d->childWindows;
    for (QMdiSubWindow *child : subWindows) {
        if (!sanityCheck(child, "QMdiArea::setupViewport"))
            continue;
        child->setParent(viewport, child->windowFlags());
    }
}

QT_END_NAMESPACE

#include "moc_qmdiarea.cpp"
