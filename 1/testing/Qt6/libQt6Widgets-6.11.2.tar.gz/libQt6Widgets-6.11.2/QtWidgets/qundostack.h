// Copyright (C) 2020 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#if 0
// syncqt: header is already part of QtGui/QtGui
#pragma qt_no_master_include
#endif

#include <QtGui/QUndoStack>

QT_BEGIN_NAMESPACE
QT_END_NAMESPACE
