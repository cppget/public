#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <assert.h>

#include <vulkan/vulkan.h>

int main()
{
   return 0;
}
