#include <boost/rational.hpp>

int
main ()
{
  return 0;
}
