#include <boost/pfr.hpp>

int
main ()
{
  return 0;
}
