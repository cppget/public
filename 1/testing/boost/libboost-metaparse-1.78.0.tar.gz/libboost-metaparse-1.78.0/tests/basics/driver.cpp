#include <boost/metaparse.hpp>

int
main ()
{
  return 0;
}
