#include <boost/variant2/variant.hpp>

int
main ()
{
  return 0;
}
