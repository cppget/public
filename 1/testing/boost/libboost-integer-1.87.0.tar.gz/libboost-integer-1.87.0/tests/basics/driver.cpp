#include <boost/integer.hpp>

int
main ()
{
  return 0;
}
