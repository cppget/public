#include <boost/assign.hpp>

int
main ()
{
  return 0;
}
