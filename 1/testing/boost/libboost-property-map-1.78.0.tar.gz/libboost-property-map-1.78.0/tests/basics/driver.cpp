#include <boost/property_map/property_map.hpp>

int
main ()
{
  return 0;
}
