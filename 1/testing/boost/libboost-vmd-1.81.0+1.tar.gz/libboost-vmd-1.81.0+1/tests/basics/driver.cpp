#include <boost/vmd/vmd.hpp>

int
main ()
{
  return 0;
}
