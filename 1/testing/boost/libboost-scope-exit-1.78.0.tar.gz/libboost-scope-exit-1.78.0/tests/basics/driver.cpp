#include <boost/scope_exit.hpp>

int
main ()
{
  return 0;
}
