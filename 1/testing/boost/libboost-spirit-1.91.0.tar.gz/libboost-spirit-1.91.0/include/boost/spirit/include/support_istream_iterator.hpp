/*=============================================================================
    Copyright (c) 2001-2011 Joel de Guzman
    Copyright (c) 2001-2011 Hartmut Kaiser
    http://spirit.sourceforge.net/

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
#ifndef BOOST_SPIRIT_INCLUDE_SUPPORT_ISTREAM_ITERATOR
#define BOOST_SPIRIT_INCLUDE_SUPPORT_ISTREAM_ITERATOR

#if defined(_MSC_VER)
#pragma once
#endif

#include <boost/spirit/home/support/iterators/istream_iterator.hpp>

#endif
