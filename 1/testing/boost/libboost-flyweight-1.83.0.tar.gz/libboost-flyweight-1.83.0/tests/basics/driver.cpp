#include <boost/flyweight.hpp>

int
main ()
{
  return 0;
}
