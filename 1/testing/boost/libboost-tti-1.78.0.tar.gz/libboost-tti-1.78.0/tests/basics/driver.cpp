#include <boost/tti/tti.hpp>

int
main ()
{
  return 0;
}
