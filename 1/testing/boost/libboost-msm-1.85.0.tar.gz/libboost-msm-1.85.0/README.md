# msm
Boost.org msm module
[Please look at the generated documentation](http://htmlpreview.github.com/?https://github.com/boostorg/msm/blob/master/doc/HTML/index.html)
You might need to force browser reloading (F5)
