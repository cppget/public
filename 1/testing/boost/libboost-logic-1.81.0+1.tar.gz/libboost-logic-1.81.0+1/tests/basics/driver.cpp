#include <boost/logic/tribool_fwd.hpp>
#include <boost/logic/tribool.hpp>
#include <boost/logic/tribool_io.hpp>

int
main ()
{
  return 0;
}
