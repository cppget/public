#include <boost/move/move.hpp>

int
main ()
{
  return 0;
}
