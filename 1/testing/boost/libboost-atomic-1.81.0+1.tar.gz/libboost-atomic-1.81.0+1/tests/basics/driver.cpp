#include <boost/atomic.hpp>

int
main ()
{
  return 0;
}
