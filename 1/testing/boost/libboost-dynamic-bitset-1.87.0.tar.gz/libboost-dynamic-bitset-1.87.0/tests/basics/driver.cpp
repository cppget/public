#include <boost/dynamic_bitset/dynamic_bitset.hpp>

int
main ()
{
  return 0;
}
