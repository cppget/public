#include <boost/yap/yap.hpp>

int
main ()
{
  return 0;
}
