#include <boost/uuid/uuid.hpp>

int
main ()
{
  return 0;
}
