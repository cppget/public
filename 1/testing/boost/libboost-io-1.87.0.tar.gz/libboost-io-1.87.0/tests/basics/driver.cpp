#include <boost/io_fwd.hpp>
#include <boost/io/ios_state.hpp>
#include <boost/io/nullstream.hpp>
#include <boost/io/ostream_joiner.hpp>
#include <boost/io/ostream_put.hpp>
#include <boost/io/quoted.hpp>

int
main ()
{
  return 0;
}
