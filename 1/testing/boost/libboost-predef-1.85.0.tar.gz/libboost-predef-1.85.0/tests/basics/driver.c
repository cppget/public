#include <boost/predef.h>

int
main ()
{
  return 0;
}
