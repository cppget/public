# Boost.Metaparse

[![Build Status](https://secure.travis-ci.org/boostorg/metaparse.svg?branch=master "Build Status")](http://travis-ci.org/boostorg/metaparse)
[![Windows build status](https://ci.appveyor.com/api/projects/status/u7ysxkssmrgr7vau/branch/master?svg=true)](https://ci.appveyor.com/project/sabel83/metaparse-04v04/branch/master)

Metaparse is parser generator library for template metaprograms. The purpose of
this library is to support the creation of parsers that parse at compile time.

