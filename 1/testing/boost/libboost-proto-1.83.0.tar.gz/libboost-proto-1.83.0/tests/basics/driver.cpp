#include <boost/proto/proto.hpp>

int
main ()
{
  return 0;
}
