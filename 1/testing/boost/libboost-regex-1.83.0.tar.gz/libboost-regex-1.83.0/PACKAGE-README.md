# libboost-regex

The `build2` package of `libboost-regex` supports the following configuration
variables:


### `config.libboost_regex.icu`

Enable ICU support. Default is `false`. Note that enabling this support will
cause the package to depend on `libicuuc` and `libicui18n`.
