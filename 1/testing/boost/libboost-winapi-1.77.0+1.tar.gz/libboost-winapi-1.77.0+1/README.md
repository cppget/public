WinAPI
======

Windows API declarations without &lt;windows.h&gt;, for internal Boost use.

### Build Status

Master: [![AppVeyor](https://ci.appveyor.com/api/projects/status/dkb233de24u30x9a/branch/master?svg=true)](https://ci.appveyor.com/project/Lastique/winapi/branch/master) [![Travis CI](https://travis-ci.org/boostorg/winapi.svg?branch=master)](https://travis-ci.org/boostorg/winapi)
Develop: [![AppVeyor](https://ci.appveyor.com/api/projects/status/dkb233de24u30x9a/branch/develop?svg=true)](https://ci.appveyor.com/project/Lastique/winapi/branch/develop) [![Travis CI](https://travis-ci.org/boostorg/winapi.svg?branch=develop)](https://travis-ci.org/boostorg/winapi)

### License

Distributed under the [Boost Software License, Version 1.0](https://boost.org/LICENSE_1_0.txt).
