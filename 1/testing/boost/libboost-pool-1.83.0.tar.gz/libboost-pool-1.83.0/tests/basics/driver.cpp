#include <boost/pool/pool.hpp>

int
main ()
{
  return 0;
}
