#include <boost/compat/bind_back.hpp>
#include <boost/compat/bind_front.hpp>
#include <boost/compat/function_ref.hpp>
#include <boost/compat/integer_sequence.hpp>
#include <boost/compat/invoke.hpp>
#include <boost/compat/latch.hpp>
#include <boost/compat/mem_fn.hpp>
#include <boost/compat/shared_lock.hpp>
#include <boost/compat/to_array.hpp>
#include <boost/compat/type_traits.hpp>

int
main ()
{
  return 0;
}
