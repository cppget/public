#include <boost/type_traits.hpp>

int
main ()
{
  return 0;
}
