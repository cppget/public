#include <boost/multi_array.hpp>

int
main ()
{
  return 0;
}
