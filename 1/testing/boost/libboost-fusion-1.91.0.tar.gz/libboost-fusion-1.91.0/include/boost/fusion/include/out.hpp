/*=============================================================================
    Copyright (c) 2001-2007 Hartmut Kaiser

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef FUSION_INCLUDE_OUT
#define FUSION_INCLUDE_OUT

#include <boost/fusion/support/config.hpp>
#include <boost/fusion/sequence/io/out.hpp>

#endif
