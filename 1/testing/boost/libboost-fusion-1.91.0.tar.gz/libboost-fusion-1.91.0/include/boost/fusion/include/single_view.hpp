/*=============================================================================
    Copyright (c) 2001-2007 Joel de Guzman

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef FUSION_INCLUDE_SINGLE_VIEW
#define FUSION_INCLUDE_SINGLE_VIEW

#include <boost/fusion/support/config.hpp>
#include <boost/fusion/view/single_view.hpp>

#endif
