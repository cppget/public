#include <boost/compat/latch.hpp>
#include <boost/compat/shared_lock.hpp>

int
main ()
{
  return 0;
}
