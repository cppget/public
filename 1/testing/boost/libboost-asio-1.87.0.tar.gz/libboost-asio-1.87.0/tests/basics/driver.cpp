#include <boost/asio.hpp>

int
main ()
{
  return 0;
}
