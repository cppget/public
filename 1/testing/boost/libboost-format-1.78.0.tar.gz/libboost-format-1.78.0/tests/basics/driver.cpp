#include <boost/format.hpp>

int
main ()
{
  return 0;
}
