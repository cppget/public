#include <boost/throw_exception.hpp>

int
main ()
{
  return 0;
}
