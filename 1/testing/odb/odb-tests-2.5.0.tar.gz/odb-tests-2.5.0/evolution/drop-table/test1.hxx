// file      : evolution/drop-table/test1.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef TEST1_HXX
#define TEST1_HXX

#pragma db model version(1, 1)

#endif // TEST1_HXX
