// file      : common/include/objs3.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef OBJS3_HXX
#define OBJS3_HXX

#include "../include/obj1.hxx"
#include "../include/obj2.hxx"
#include "../include/obj3.hxx"

#endif // OBJS3_HXX
