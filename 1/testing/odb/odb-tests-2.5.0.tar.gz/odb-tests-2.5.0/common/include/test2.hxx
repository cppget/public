// file      : common/include/test2.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef TEST2_HXX
#define TEST2_HXX

// Test preference of includes from the main file.
//
#include "objs1.hxx"

#include "obj1.hxx"
#include "obj2.hxx"
#include "obj3.hxx"

#endif // TEST2_HXX
