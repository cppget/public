// file      : common/include/objs2.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef OBJS2_HXX
#define OBJS2_HXX

#ifdef ODB_COMPILER
#  include "include/obj1.hxx"
#  include "include/obj2.hxx"
#  include "include/obj3.hxx"
#endif

#endif // OBJS2_HXX
