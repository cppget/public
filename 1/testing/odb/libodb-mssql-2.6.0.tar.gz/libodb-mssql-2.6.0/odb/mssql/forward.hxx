// file      : odb/mssql/forward.hxx
// license   : ODB NCUEL; see accompanying LICENSE file

#ifndef ODB_MSSQL_FORWARD_HXX
#define ODB_MSSQL_FORWARD_HXX

#include <odb/pre.hxx>

#include <memory> // std::shared_ptr

#include <odb/forward.hxx>

namespace odb
{
  namespace mssql
  {
    namespace core
    {
      using namespace odb::common;
    }

    //
    //
    class database;
    class connection;
    typedef std::shared_ptr<connection> connection_ptr;
    class connection_factory;
    class statement;
    class transaction;
    class tracer;

    namespace core
    {
      using mssql::database;
      using mssql::connection;
      using mssql::connection_ptr;
      using mssql::transaction;
      using mssql::statement;
    }

    // Implementation details.
    //
    enum statement_kind
    {
      statement_select,
      statement_insert,
      statement_update,
      statement_delete
    };

    class binding;
    class select_statement;

    template <typename T>
    class object_statements;

    template <typename T>
    class polymorphic_root_object_statements;

    template <typename T>
    class polymorphic_derived_object_statements;

    template <typename T>
    class no_id_object_statements;

    template <typename T>
    class view_statements;

    template <typename T>
    class container_statements;

    template <typename T>
    class direct_container_statements;

    template <typename T, template <typename> class B>
    class smart_container_statements;

    template <typename T, typename ST>
    class section_statements;

    class query_base;
  }
}

#include <odb/post.hxx>

#endif // ODB_MSSQL_FORWARD_HXX
