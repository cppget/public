// file      : odb/details/condition.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef ODB_DETAILS_CONDITION_HXX
#define ODB_DETAILS_CONDITION_HXX

#include <odb/pre.hxx>

#include <odb/details/config.hxx>

#ifdef ODB_THREADS_NONE

namespace odb
{
  namespace details
  {
    class mutex;
    class unique_lock;

    using lock = unique_lock;

    class condition
    {
    public:
      condition (mutex&) {}

      void
      signal () {}

      void
      wait (lock&) {}

      condition (condition&&) = delete;
      condition (const condition&) = delete;
      condition& operator= (condition&&) = delete;
      condition& operator= (const condition&)  = delete;
    };
  }
}

#elif defined(ODB_THREADS_CXX11)
#  include <condition_variable>
#  include <odb/details/mutex.hxx>
#  include <odb/details/lock.hxx>

namespace odb
{
  namespace details
  {
    class condition: public std::condition_variable
    {
    public:
      condition (mutex&) {}

      void
      signal () {notify_one ();}
    };
  }
}

#else
# error unknown threading model
#endif

#include <odb/post.hxx>

#endif // ODB_DETAILS_CONDITION_HXX
