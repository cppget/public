/* Public C++ API smoke test for libenkits. */

// Both inclusion styles must resolve (dual -I: include/ and include/enkiTS/).
//
#include <enkiTS/TaskScheduler.h>
#include <TaskScheduler.h>

#include <atomic>
#include <cstdint>

#undef NDEBUG
#include <cassert>

using namespace enki;

struct IncrementTask: ITaskSet
{
  std::atomic<uint32_t>* counter;

  IncrementTask (std::atomic<uint32_t>* c, uint32_t set_size)
      : ITaskSet (set_size), counter (c)
  {
  }

  void
  ExecuteRange (TaskSetPartition range, uint32_t /*threadnum*/) override
  {
    for (uint32_t i = range.start; i < range.end; ++i)
      counter->fetch_add (1, std::memory_order_relaxed);
  }
};

int
main ()
{
  // Non-inline symbol from the shared/static library.
  //
  uint32_t hw = GetNumHardwareThreads ();
  assert (hw >= 1);

  TaskScheduler ts;
  ts.Initialize ();

  std::atomic<uint32_t> counter {0};
  const uint32_t set_size = 1000;
  IncrementTask task (&counter, set_size);
  ts.AddTaskSetToPipe (&task);
  ts.WaitforTask (&task);

  assert (task.GetIsComplete ());
  assert (counter.load () == set_size);

  ts.WaitforAllAndShutdown ();
  return 0;
}
