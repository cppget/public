/* Public C API smoke test for libenkits. */

// Both inclusion styles must resolve (dual -I: include/ and include/enkiTS/).
//
#include <enkiTS/TaskScheduler_c.h>
#include <TaskScheduler_c.h>

#include <stdint.h>

#undef NDEBUG
#include <assert.h>

static void
noop_task (uint32_t start, uint32_t end, uint32_t threadnum, void* args)
{
  (void)start;
  (void)end;
  (void)threadnum;
  (void)args;
}

int
main (void)
{
  enkiTaskScheduler* ts = enkiNewTaskScheduler ();
  assert (ts != NULL);

  enkiInitTaskScheduler (ts);

  enkiTaskSet* task = enkiCreateTaskSet (ts, noop_task);
  assert (task != NULL);

  struct enkiParamsTaskSet params = enkiGetParamsTaskSet (task);
  params.setSize = 1;
  enkiSetParamsTaskSet (task, params);

  enkiAddTaskSet (ts, task);
  enkiWaitForTaskSet (ts, task);

  enkiDeleteTaskSet (ts, task);
  enkiDeleteTaskScheduler (ts);
  return 0;
}
