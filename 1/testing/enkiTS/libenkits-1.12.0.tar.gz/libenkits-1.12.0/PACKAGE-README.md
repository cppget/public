# libenkits - C and C++ task scheduler for parallel programs

This is a `build2` package for the [enkiTS](https://github.com/dougbinks/enkiTS)
C and C++ library. It provides a lightweight task scheduler for data- and
task-level parallelism on multicore CPUs (C++11, optional C API).


## Usage

To start using `libenkits` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libenkits ^1.12.0
```

Then import the library in your `buildfile`:

```
import libs = libenkits%lib{enkits}
```

This is a C++ library, so a C executable that links it must be linked with the
C++ compiler driver (otherwise a static link fails with undefined references to
the C++ runtime). Request the C++ link rule with a rule hint:

```
[rule_hint=cxx] exe{app}: c{app} $libs
```

This affects only linking. Your C sources are still compiled as C.

Public headers are installed under `include/enkiTS/` (so they co-exist with
other packages). Both inclusion styles are supported:

```cpp
#include <enkiTS/TaskScheduler.h>    // preferred (qualified)
#include <enkiTS/TaskScheduler_c.h>

#include <TaskScheduler.h>           // upstream / unqualified
#include <TaskScheduler_c.h>
```


## Importable targets

This package provides the following importable targets:

```
lib{enkits}
```

This is the enkiTS task scheduler library (C++ implementation plus C API).


## Configuration variables

This package provides the following configuration variables:

```
[uint64] config.libenkits.task_priorities_num ?= 3
```

`config.libenkits.task_priorities_num` sets `ENKITS_TASK_PRIORITIES_NUM` (1-5).
This value is part of the public interface (priority enum layout in
`TaskScheduler.h`) and is re-exported to consumers. Use `0` to leave the
define unset and rely on the upstream header default. The package default of
`3` matches upstream CMake.
