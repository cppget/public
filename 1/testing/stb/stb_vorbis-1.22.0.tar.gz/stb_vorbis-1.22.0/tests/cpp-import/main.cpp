#include <stb_vorbis.c>

int main() {}
