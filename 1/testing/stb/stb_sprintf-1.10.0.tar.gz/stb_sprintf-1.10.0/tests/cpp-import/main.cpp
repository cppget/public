#define STB_SPRINTF_IMPLEMENTATION
#include <stb_sprintf.h>

int main() {}
