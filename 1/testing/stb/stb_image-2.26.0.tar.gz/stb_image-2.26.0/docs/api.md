# stb_image.h API Documentation

## Limitations
- no 12-bit-per-channel JPEG
- no JPEGs with arithmetic coding
- GIF always returns *comp=4

## Basic usage (see HDR discussion below for HDR usage):
```c
int x,y,n;
unsigned char *data = stbi_load(filename, &x, &y, &n, 0);
// ... process data if not NULL ...
// ... x = width, y = height, n = # 8-bit components per pixel ...
// ... replace '0' with '1'..'4' to force that many components per pixel
// ... but 'n' will always be the number that it would have been if you said 0
stbi_image_free(data)
```

## Standard Parameters
```c
   int *x                 // outputs image width in pixels
   int *y                 // outputs image height in pixels
   int *channels_in_file  // outputs # of image components in image file
   int desired_channels   // if non-zero, # of image components requested in result
```
The return value from an image loader is an 'unsigned char *' which points
to the pixel data, or NULL on an allocation failure or if the image is
corrupt or invalid. The pixel data consists of *y scanlines of *x pixels,
with each pixel consisting of N interleaved 8-bit components; the first
pixel pointed to is top-left-most in the image. There is no padding between
image scanlines or between pixels, regardless of format. The number of
components N is 'desired_channels' if desired_channels is non-zero, or
*channels_in_file otherwise. If desired_channels is non-zero,
*channels_in_file has the number of components that _would_ have been
output otherwise. E.g. if you set desired_channels to 4, you will always
get RGBA output, but you can check *channels_in_file to see if it's trivially
opaque because e.g. there were only 3 channels in the source image.

An output image with N components has the following components interleaved
in this order in each pixel:

|N=#comp|components|
|---|---|
|1|grey|
|2|grey, alpha|
|3|red, green, blue|
|4|red, green, blue, alpha|

If image loading fails for any reason, the return value will be NULL,
and *x, *y, *channels_in_file will be unchanged. The function
stbi_failure_reason() can be queried for an extremely brief, end-user
unfriendly explanation of why the load failed. Define STBI_NO_FAILURE_STRINGS
to avoid compiling these strings at all, and STBI_FAILURE_USERMSG to get slightly
more user-friendly ones.

Paletted PNG, BMP, GIF, and PIC images are automatically depalettized.


## UNICODE

  If compiling for Windows and you wish to use Unicode filenames, compile
  with
      #define STBI_WINDOWS_UTF8
  and pass utf8-encoded filenames. Call stbi_convert_wchar_to_utf8 to convert
  Windows wchar_t filenames to utf8.

## Philosophy

stb libraries are designed with the following priorities:

   1. easy to use
   2. easy to maintain
   3. good performance

Sometimes I let "good performance" creep up in priority over "easy to maintain",
and for best performance I may provide less-easy-to-use APIs that give higher
performance, in addition to the easy-to-use ones. Nevertheless, it's important
to keep in mind that from the standpoint of you, a client of this library,
all you care about is #1 and #3, and stb libraries DO NOT emphasize #3 above all.

Some secondary priorities arise directly from the first two, some of which
provide more explicit reasons why performance can't be emphasized.

   - Portable ("ease of use")
   - Small source code footprint ("easy to maintain")
   - No dependencies ("ease of use")


## I/O callbacks

I/O callbacks allow you to read from arbitrary sources, like packaged
files or some other source. Data read from callbacks are processed
through a small internal buffer (currently 128 bytes) to try to reduce
overhead.

The three functions you must define are "read" (reads some bytes of data),
"skip" (skips some bytes of data), "eof" (reports if the stream is at the end).

## SIMD support

The JPEG decoder will try to automatically use SIMD kernels on x86 when
supported by the compiler. For ARM Neon support, you must explicitly
request it.

(The old do-it-yourself SIMD API is no longer supported in the current
code.)

On x86, SSE2 will automatically be used when available based on a run-time
test; if not, the generic C versions are used as a fall-back. On ARM targets,
the typical path is to have separate builds for NEON and non-NEON devices
(at least this is true for iOS and Android). Therefore, the NEON support is
toggled by a build flag: define STBI_NEON to get NEON loops.

If for some reason you do not want to use any of SIMD code, or if
you have issues compiling it, you can disable it entirely by
defining STBI_NO_SIMD.

## HDR image support   (disable by defining `STBI_NO_HDR`)

stb_image supports loading HDR images in general, and currently the Radiance
.HDR file format specifically. You can still load any file through the existing
interface; if you attempt to load an HDR file, it will be automatically remapped
to LDR, assuming gamma 2.2 and an arbitrary scale factor defaulting to 1;
both of these constants can be reconfigured through this interface:

    stbi_hdr_to_ldr_gamma(2.2f);
    stbi_hdr_to_ldr_scale(1.0f);

(note, do not use _inverse_ constants; stbi_image will invert them
appropriately).

Additionally, there is a new, parallel interface for loading files as
(linear) floats to preserve the full dynamic range:

    float *data = stbi_loadf(filename, &x, &y, &n, 0);

If you load LDR images through this interface, those images will
be promoted to floating point values, run through the inverse of
constants corresponding to the above:

    stbi_ldr_to_hdr_scale(1.0f);
    stbi_ldr_to_hdr_gamma(2.2f);

Finally, given a filename (or an open file or memory block--see header
file for details) containing image data, you can query for the "most
appropriate" interface to use (that is, whether the image is HDR or
not), using:

    stbi_is_hdr(char *filename);

## iPhone PNG support:

By default we convert iphone-formatted PNGs back to RGB, even though
they are internally encoded differently. You can disable this conversion
by calling stbi_convert_iphone_png_to_rgb(0), in which case
you will always just get the native iphone "format" through (which
is BGR stored in RGB).

Call stbi_set_unpremultiply_on_load(1) as well to force a divide per
pixel to remove any premultiplied alpha *only* if the image file explicitly
says there's premultiplied data (currently only happens in iPhone images,
and only if iPhone convert-to-rgb processing is on).

## Additional Configuration

You can suppress implementation of any of the decoders to reduce your code footprint by #defining one or more of the following symbols before creating the implementation.

    STBI_NO_JPEG
    STBI_NO_PNG
    STBI_NO_BMP
    STBI_NO_PSD
    STBI_NO_TGA
    STBI_NO_GIF
    STBI_NO_HDR
    STBI_NO_PIC
    STBI_NO_PNM   (.ppm and .pgm)

You can request *only* certain decoders and suppress all other ones
(this will be more forward-compatible, as addition of new decoders
doesn't require you to disable them explicitly):

       STBI_ONLY_JPEG
       STBI_ONLY_PNG
       STBI_ONLY_BMP
       STBI_ONLY_PSD
       STBI_ONLY_TGA
       STBI_ONLY_GIF
       STBI_ONLY_HDR
       STBI_ONLY_PIC
       STBI_ONLY_PNM   (.ppm and .pgm)

If you use STBI_NO_PNG (or _ONLY_ without PNG), and you still
want the zlib decoder to be available, 

    #define STBI_SUPPORT_ZLIB

If you define STBI_MAX_DIMENSIONS, stb_image will reject images greater
than that size (in either width or height) without further processing.
This is to let programs in the wild set an upper bound to prevent
denial-of-service attacks on untrusted data, as one could generate a
valid image of gigantic dimensions and force stb_image to allocate a
huge block of memory and spend disproportionate time decoding it. By
default this is set to (1 << 24), which is 16777216, but that's still
very big.