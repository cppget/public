#define STB_EASY_FONT_IMPLEMENTATION
#include <stb_easy_font.h>

int main() {}
