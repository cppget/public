#include <cassert>
#include <chrono>
#include <vector>

#include <fmt/version.h>
#include <fmt/printf.h>
#include <fmt/core.h>
#include <fmt/format.h>
#include <fmt/color.h>
#include <fmt/chrono.h>
#include <fmt/ranges.h>

#include "tests.inl"

