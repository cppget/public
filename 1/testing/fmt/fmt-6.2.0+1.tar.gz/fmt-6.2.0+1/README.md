`{fmt}` library - Build2 package
================================

This is the source code for the build2 package of the `{fmt}` C++ library.

 - Build2 : https://build2.org
 - `{fmt}` : https://github.com/fmtlib/fmt/

See ./upstream/Readme.rst for the library's details.
