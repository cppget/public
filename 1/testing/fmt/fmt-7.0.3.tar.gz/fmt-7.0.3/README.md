`{fmt}` library - Build2 package
================================

See [`{fmt}` documentation](https://fmt.dev/) for usage and details.

 - `{fmt}` : https://github.com/fmtlib/fmt/
 - Build2 : https://build2.org

Note: This is the source code for the build2 package of the `{fmt}` C++ library,
the actual library sources snapshot can be found in the `./upstream/` submodule.

