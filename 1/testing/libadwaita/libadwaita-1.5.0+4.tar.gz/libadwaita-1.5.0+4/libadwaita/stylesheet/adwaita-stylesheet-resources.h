#ifndef __RESOURCE_adw_stylesheet_H__
#define __RESOURCE_adw_stylesheet_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *adw_stylesheet_get_resource (void);
#endif
