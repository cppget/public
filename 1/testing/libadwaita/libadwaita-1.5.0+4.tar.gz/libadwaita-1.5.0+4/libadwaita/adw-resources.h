#ifndef __RESOURCE_adw_H__
#define __RESOURCE_adw_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *adw_get_resource (void);
#endif
