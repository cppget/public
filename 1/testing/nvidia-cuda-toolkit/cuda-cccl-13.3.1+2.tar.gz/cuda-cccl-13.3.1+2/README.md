# cuda-cccl - A C++ library

> **NOTE:**  
> This package is not open source and does not contain any source code. Instead,
> in order to "build" the exported target(s) it downloads (potentially large)
> pre-built binaries provided by Intel for the target platform.
>
> CI for this package is disabled due to the above.
> Supported platforms/compilers are Windows/MSVC and Linux.

The goal of CCCL is to provide CUDA C++ developers with building blocks
that make it easier to write safe and efficient code. Bringing these
libraries together streamlines your development process and broadens
your ability to leverage the power of CUDA C++.


## Usage

To start using `cuda-cccl` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: cuda-cccl ^13.0.1
```

Then import the library in your `buildfile`:

```
import libs = cuda-cccl%lib{cccl}
```


## Importable targets

This package provides the following importable targets:

```
lib{cccl}
```


## Configuration variables

This package provides the following configuration variables:

```
[dir_path] config.cuda_cccl.cache ?= $out_root
```

The directory used to cache downloaded binary archives between builds. If
`config.cuda.cache` is set (a shared project-wide cache directory), it
takes precedence over the per-package default of `$out_root`.
