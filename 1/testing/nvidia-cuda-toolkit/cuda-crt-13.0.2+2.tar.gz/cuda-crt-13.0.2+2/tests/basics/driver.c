#define __CUDA_INCLUDE_COMPILER_INTERNAL_HEADERS__
#include <crt/host_config.h>

#ifndef __HOST_CONFIG_H__
  #error __HOST_CONFIG_H__ not defined
#endif

int main() {
  return 0;
}
