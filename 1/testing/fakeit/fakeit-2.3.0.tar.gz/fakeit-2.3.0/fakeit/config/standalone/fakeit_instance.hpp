#pragma once

#include "StandaloneFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::StandaloneFakeit::getInstance();
