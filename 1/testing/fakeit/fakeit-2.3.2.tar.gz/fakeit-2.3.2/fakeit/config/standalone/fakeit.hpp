#pragma once

#include "fakeit_instance.hpp"
#include "fakeit/fakeit_root.hpp"
