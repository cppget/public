#include <stdio.h>

#include <MinHook.h>

/* Smoke test: exercise the MinHook lifecycle and a couple of exported
 * functions without installing an actual hook (so it runs anywhere, including
 * under Wine). This validates that <MinHook.h> is usable and that the library's
 * exports link and run.
 */
int main (void)
{
  MH_STATUS s;

  if ((s = MH_Initialize ()) != MH_OK)
  {
    fprintf (stderr, "MH_Initialize: %s\n", MH_StatusToString (s));
    return 1;
  }

  /* A second Initialize must report that it is already initialized. */
  if (MH_Initialize () != MH_ERROR_ALREADY_INITIALIZED)
  {
    fprintf (stderr, "MH_Initialize did not report already-initialized\n");
    return 1;
  }

  /* Status strings are always available. */
  printf ("MinHook ready: %s\n", MH_StatusToString (MH_OK));

  if ((s = MH_Uninitialize ()) != MH_OK)
  {
    fprintf (stderr, "MH_Uninitialize: %s\n", MH_StatusToString (s));
    return 1;
  }

  /* A second Uninitialize must report that it is not initialized. */
  if (MH_Uninitialize () != MH_ERROR_NOT_INITIALIZED)
  {
    fprintf (stderr, "MH_Uninitialize did not report not-initialized\n");
    return 1;
  }

  return 0;
}
