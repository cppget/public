/* file      : libpq/strlcpy.c -*- C -*-
 * license   : PostgreSQL License; see accompanying COPYRIGHT file
 */
#if !HAVE_DECL_STRLCPY
# include <port/strlcpy.c>
#endif
