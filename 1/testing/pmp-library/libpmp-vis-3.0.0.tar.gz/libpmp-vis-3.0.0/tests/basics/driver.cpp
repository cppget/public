#include <pmp/visualization/mesh_viewer.h>

#undef NDEBUG
#include <cassert>

int main() {}
