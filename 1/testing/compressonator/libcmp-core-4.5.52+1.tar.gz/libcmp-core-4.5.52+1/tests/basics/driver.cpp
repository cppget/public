#include <cmp_core/cmp_core.h>

#include <stdint.h>
#include <string.h>

#undef NDEBUG
#include <cassert>

int
main ()
{
  // One 4x4 RGBA8888 block. Calling non-inline CompressBlock/DecompressBlock
  // entry points checks the public header install path and that symbols are
  // exported from lib{CMP_Core}.
  //
  unsigned char src[64];
  for (unsigned i = 0; i < 16; ++i)
  {
    src[i * 4 + 0] = (unsigned char) (i * 16);
    src[i * 4 + 1] = 255;
    src[i * 4 + 2] = 0;
    src[i * 4 + 3] = 255;
  }

  unsigned char bc1[8];
  memset (bc1, 0, sizeof (bc1));
  assert (CompressBlockBC1 (src, 16, bc1, NULL) == 0);

  unsigned char out[64];
  memset (out, 0, sizeof (out));
  assert (DecompressBlockBC1 (bc1, out, NULL) == 0);

  unsigned char bc3[16];
  memset (bc3, 0, sizeof (bc3));
  assert (CompressBlockBC3 (src, 16, bc3, NULL) == 0);
  assert (DecompressBlockBC3 (bc3, out, NULL) == 0);

  // Portable CPU path: SIMD detection is a no-op outside Windows, so this
  // should report none (0) on macOS arm64.
  //
  assert (GetEnabledSIMDExtension () >= 0);
  assert (DisableSIMD () == 0);
}
