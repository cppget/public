# libcmp-core - BCn block compression library

This is a `build2` package for the [`Compressonator`](https://github.com/GPUOpen-Tools/compressonator)
C++ library. Compressonator Core (`CMP_Core`) provides block-level encode
and decode of the BCn texture codecs (BC1 through BC7, also known as ATI1N,
ATI2N, and DXTC).


## Usage

To start using `libcmp-core` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libcmp-core ^4.5.52
```

Then import the library in your `buildfile`:

```
import libs = libcmp-core%lib{CMP_Core}
```


## Importable targets

This package provides the following importable targets:

```
lib{CMP_Core}
```

The target name matches upstream's CMake `CMP_Core` library. Include the
public header as `<cmp_core/cmp_core.h>` (the documented `CMP_Core.h`
spelling works on case-insensitive filesystems).

```
#include <cmp_core/cmp_core.h>
```

Consumers using the generated `pkg-config` file directly (rather than
build2) can also write `#include <cmp_core.h>` unqualified, matching
upstream's own CMake public include path.


## Configuration variables

This package provides the following configuration variables:

```
config [bool] config.libcmp_core.sse    ?= <x86>
config [bool] config.libcmp_core.avx    ?= <x86>
config [bool] config.libcmp_core.avx512 ?= <x86>
```

Each switch compiles the corresponding upstream SIMD translation unit
(`core_simd_sse.cpp`, `core_simd_avx.cpp`, `core_simd_avx512.cpp`) with
the architecture flags from `cmp_core/CMakeLists.txt`, except that the
AVX512 unit uses `-mavx512f` in place of upstream's `-march=knl`, which
GCC 15 and 16 no longer accept. They default to true on x86 and x86_64,
and false elsewhere, so the portable CPU path is what builds on macOS
arm64. Upstream references those SIMD symbols as function pointers from
`bc1_cmp.h` even when they are never called, so a stub is compiled for
each disabled unit.
