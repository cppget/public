#ifndef ENTT_STL_TYPE_TRAITS_HPP
#define ENTT_STL_TYPE_TRAITS_HPP

/*! @cond ENTT_INTERNAL */
#if __has_include(<entt/ext/stl/type_traits.hpp>)
#    include <entt/ext/stl/type_traits.hpp>
#else
#    include <type_traits>

namespace entt::stl {

using std::bool_constant;
using std::common_type_t;
using std::conditional_t;
using std::decay_t;
using std::extent_v;
using std::false_type;
using std::integral_constant;
using std::invoke_result_t;
using std::is_aggregate_v;
using std::is_arithmetic_v;
using std::is_array_v;
using std::is_base_of_v;
using std::is_class_v;
using std::is_const_v;
using std::is_constructible_v;
using std::is_convertible_v;
using std::is_copy_assignable_v;
using std::is_copy_constructible_v;
using std::is_default_constructible_v;
using std::is_empty_v;
using std::is_enum_v;
using std::is_final_v;
using std::is_function_v;
using std::is_integral_v;
using std::is_invocable;
using std::is_invocable_r;
using std::is_invocable_r_v;
using std::is_invocable_v;
using std::is_lvalue_reference_v;
using std::is_member_function_pointer_v;
using std::is_member_object_pointer_v;
using std::is_member_pointer_v;
using std::is_move_assignable_v;
using std::is_move_constructible_v;
using std::is_nothrow_constructible_v;
using std::is_nothrow_copy_constructible_v;
using std::is_nothrow_default_constructible_v;
using std::is_nothrow_destructible_v;
using std::is_nothrow_invocable_v;
using std::is_nothrow_move_constructible_v;
using std::is_pointer_v;
using std::is_reference_v;
using std::is_same_v;
using std::is_signed_v;
using std::is_trivially_destructible_v;
using std::is_void_v;
using std::remove_const_t;
using std::remove_cvref_t;
using std::remove_pointer_t;
using std::remove_reference_t;
using std::true_type;
using std::type_identity;
using std::underlying_type_t;

} // namespace entt::stl
#endif
/*! @endcond */

#endif
