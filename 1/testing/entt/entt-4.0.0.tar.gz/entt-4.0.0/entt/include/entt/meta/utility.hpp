#ifndef ENTT_META_UTILITY_HPP
#define ENTT_META_UTILITY_HPP

#include "../core/type_traits.hpp"
#include "../locator/locator.hpp"
#include "../stl/cstddef.hpp"
#include "../stl/functional.hpp"
#include "../stl/type_traits.hpp"
#include "../stl/utility.hpp"
#include "meta.hpp"
#include "node.hpp"
#include "policy.hpp"

namespace entt {

/**
 * @brief Meta function descriptor traits.
 * @tparam Ret Function return type.
 * @tparam Args Function arguments.
 * @tparam Static Function staticness.
 * @tparam Const Function constness.
 */
template<typename Ret, typename Args, bool Static, bool Const>
struct meta_function_descriptor_traits {
    /*! @brief Meta function return type. */
    using return_type = Ret;
    /*! @brief Meta function arguments. */
    using args_type = Args;

    /*! @brief True if the meta function is static, false otherwise. */
    static constexpr bool is_static = Static;
    /*! @brief True if the meta function is const, false otherwise. */
    static constexpr bool is_const = Const;
};

/*! @brief Primary template isn't defined on purpose. */
template<typename, typename>
struct meta_function_descriptor;

/**
 * @brief Meta function descriptor.
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Ret Function return type.
 * @tparam Class Actual owner of the member function.
 * @tparam Args Function arguments.
 */
template<typename Type, typename Ret, typename Class, typename... Args>
struct meta_function_descriptor<Type, Ret (Class::*)(Args...) const>
    : meta_function_descriptor_traits<
          Ret,
          stl::conditional_t<stl::is_base_of_v<Class, Type>, type_list<Args...>, type_list<const Class &, Args...>>,
          !stl::is_base_of_v<Class, Type>,
          true> {};

/**
 * @brief Meta function descriptor.
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Ret Function return type.
 * @tparam Class Actual owner of the member function.
 * @tparam Args Function arguments.
 */
template<typename Type, typename Ret, typename Class, typename... Args>
struct meta_function_descriptor<Type, Ret (Class::*)(Args...)>
    : meta_function_descriptor_traits<
          Ret,
          stl::conditional_t<stl::is_base_of_v<Class, Type>, type_list<Args...>, type_list<Class &, Args...>>,
          !stl::is_base_of_v<Class, Type>,
          false> {};

/**
 * @brief Meta function descriptor.
 * @tparam Type Reflected type to which the meta data is associated.
 * @tparam Class Actual owner of the data member.
 * @tparam Ret Data member type.
 */
template<typename Type, typename Ret, typename Class>
struct meta_function_descriptor<Type, Ret Class::*>
    : meta_function_descriptor_traits<
          Ret &,
          stl::conditional_t<stl::is_base_of_v<Class, Type>, type_list<>, type_list<Class &>>,
          !stl::is_base_of_v<Class, Type>,
          false> {};

/**
 * @brief Meta function descriptor.
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Ret Function return type.
 * @tparam MaybeType First function argument.
 * @tparam Args Other function arguments.
 */
template<typename Type, typename Ret, typename MaybeType, typename... Args>
struct meta_function_descriptor<Type, Ret (*)(MaybeType, Args...)>
    : meta_function_descriptor_traits<
          Ret,
          stl::conditional_t<
              stl::is_same_v<stl::remove_cvref_t<MaybeType>, Type> || stl::is_base_of_v<stl::remove_cvref_t<MaybeType>, Type>,
              type_list<Args...>,
              type_list<MaybeType, Args...>>,
          !(stl::is_same_v<stl::remove_cvref_t<MaybeType>, Type> || stl::is_base_of_v<stl::remove_cvref_t<MaybeType>, Type>),
          stl::is_const_v<stl::remove_reference_t<MaybeType>> && (stl::is_same_v<stl::remove_cvref_t<MaybeType>, Type> || stl::is_base_of_v<stl::remove_cvref_t<MaybeType>, Type>)> {};

/**
 * @brief Meta function descriptor.
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Ret Function return type.
 */
template<typename Type, typename Ret>
struct meta_function_descriptor<Type, Ret (*)()>
    : meta_function_descriptor_traits<
          Ret,
          type_list<>,
          true,
          false> {};

/**
 * @brief Meta function helper.
 *
 * Converts a function type to be associated with a reflected type into its meta
 * function descriptor.
 *
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Candidate The actual function to associate with the reflected type.
 */
template<typename Type, typename Candidate>
class meta_function_helper {
    template<typename Ret, typename... Args, typename Class>
    static meta_function_descriptor<Type, Ret (Class::*)(Args...) const> get_rid_of_noexcept(Ret (Class::*)(Args...) const);

    template<typename Ret, typename... Args, typename Class>
    static meta_function_descriptor<Type, Ret (Class::*)(Args...)> get_rid_of_noexcept(Ret (Class::*)(Args...));

    template<typename Ret, typename Class>
    requires stl::is_member_object_pointer_v<Ret Class::*>
    static meta_function_descriptor<Type, Ret Class::*> get_rid_of_noexcept(Ret Class::*);

    template<typename Ret, typename... Args>
    static meta_function_descriptor<Type, Ret (*)(Args...)> get_rid_of_noexcept(Ret (*)(Args...));

    template<typename Class>
    static meta_function_descriptor<Class, decltype(&Class::operator())> get_rid_of_noexcept(Class);

public:
    /*! @brief The meta function descriptor of the given function. */
    using type = decltype(get_rid_of_noexcept(stl::declval<Candidate>()));
};

/**
 * @brief Helper type.
 * @tparam Type Reflected type to which the meta function is associated.
 * @tparam Candidate The actual function to associate with the reflected type.
 */
template<typename Type, typename Candidate>
using meta_function_helper_t = meta_function_helper<Type, Candidate>::type;

/**
 * @brief Wraps a value depending on the given policy.
 *
 * This function always returns a wrapped value in the requested context.<br/>
 * Therefore, if the passed value is itself a wrapped object with a different
 * context, it undergoes a rebinding to the requested context.
 *
 * @tparam Policy Optional policy (no policy set by default).
 * @tparam Type Type of value to wrap.
 * @param ctx The context from which to search for meta types.
 * @param value Value to wrap.
 * @return A meta any containing the returned value, if any.
 */
template<meta_policy Policy = as_value_t, typename Type>
[[nodiscard]] meta_any meta_dispatch(const meta_ctx &ctx, [[maybe_unused]] Type &&value) {
    if constexpr(stl::is_same_v<Policy, as_cref_t>) {
        static_assert(stl::is_lvalue_reference_v<Type>, "Invalid type");
        return meta_any{ctx, stl::in_place_type<const stl::remove_reference_t<Type> &>, stl::as_const(value)};
    } else if constexpr(stl::is_same_v<Policy, as_ref_t> || (stl::is_same_v<Policy, as_is_t> && stl::is_lvalue_reference_v<Type>)) {
        return meta_any{ctx, stl::in_place_type<Type>, value};
    } else if constexpr(stl::is_same_v<Policy, as_void_t>) {
        return meta_any{ctx, stl::in_place_type<void>};
    } else {
        return meta_any{ctx, stl::forward<Type>(value)};
    }
}

/**
 * @brief Wraps a value depending on the given policy.
 * @tparam Policy Optional policy (no policy set by default).
 * @tparam Type Type of value to wrap.
 * @param value Value to wrap.
 * @return A meta any containing the returned value, if any.
 */
template<meta_policy Policy = as_value_t, typename Type>
[[nodiscard]] meta_any meta_dispatch(Type &&value) {
    return meta_dispatch<Policy, Type>(locator<meta_ctx>::value_or(), stl::forward<Type>(value));
}

/*! @cond ENTT_INTERNAL */
namespace internal {

template<typename Policy, typename Candidate, typename... Args>
[[nodiscard]] meta_any meta_invoke_with_args(const meta_ctx &ctx, Candidate &&candidate, Args &&...args) {
    if constexpr(stl::is_void_v<decltype(stl::invoke(stl::forward<Candidate>(candidate), args...))>) {
        stl::invoke(stl::forward<Candidate>(candidate), args...);
        return meta_any{ctx, stl::in_place_type<void>};
    } else {
        return meta_dispatch<Policy>(ctx, stl::invoke(stl::forward<Candidate>(candidate), args...));
    }
}

template<typename Type, typename Policy, typename Candidate, stl::size_t... Index>
[[nodiscard]] meta_any meta_invoke(meta_any &instance, Candidate &&candidate, [[maybe_unused]] meta_any *const args, stl::index_sequence<Index...>) {
    using descriptor = meta_function_helper_t<Type, stl::remove_reference_t<Candidate>>;

    // NOLINTBEGIN(cppcoreguidelines-pro-bounds-pointer-arithmetic) - waiting for C++20 (and stl::span)
    if constexpr(stl::is_invocable_v<stl::remove_reference_t<Candidate>, const Type &, type_list_element_t<Index, typename descriptor::args_type>...>) {
        if(const auto *const clazz = instance.try_cast<const Type>(); clazz && ((args + Index)->allow_cast<type_list_element_t<Index, typename descriptor::args_type>>() && ...)) {
            return meta_invoke_with_args<Policy>(instance.context(), stl::forward<Candidate>(candidate), *clazz, (args + Index)->cast<type_list_element_t<Index, typename descriptor::args_type>>()...);
        }
    } else if constexpr(stl::is_invocable_v<stl::remove_reference_t<Candidate>, Type &, type_list_element_t<Index, typename descriptor::args_type>...>) {
        if(auto *const clazz = instance.try_cast<Type>(); clazz && ((args + Index)->allow_cast<type_list_element_t<Index, typename descriptor::args_type>>() && ...)) {
            return meta_invoke_with_args<Policy>(instance.context(), stl::forward<Candidate>(candidate), *clazz, (args + Index)->cast<type_list_element_t<Index, typename descriptor::args_type>>()...);
        }
    } else {
        if(((args + Index)->allow_cast<type_list_element_t<Index, typename descriptor::args_type>>() && ...)) {
            return meta_invoke_with_args<Policy>(instance.context(), stl::forward<Candidate>(candidate), (args + Index)->cast<type_list_element_t<Index, typename descriptor::args_type>>()...);
        }
    }
    // NOLINTEND(cppcoreguidelines-pro-bounds-pointer-arithmetic)

    return meta_any{meta_ctx_arg, instance.context()};
}

template<typename Type, typename... Args, stl::size_t... Index>
[[nodiscard]] meta_any meta_construct(const meta_ctx &ctx, meta_any *const args, stl::index_sequence<Index...>) {
    // NOLINTBEGIN(cppcoreguidelines-pro-bounds-pointer-arithmetic) - waiting for C++20 (and stl::span)
    if(((args + Index)->allow_cast<Args>() && ...)) {
        return meta_any{ctx, stl::in_place_type<Type>, (args + Index)->cast<Args>()...};
    }
    // NOLINTEND(cppcoreguidelines-pro-bounds-pointer-arithmetic)

    return meta_any{meta_ctx_arg, ctx};
}

} // namespace internal
/*! @endcond */

/**
 * @brief Returns the meta type of the i-th element of a list of arguments.
 * @tparam Type Type list of the actual types of arguments.
 * @param ctx The context from which to search for meta types.
 * @param index The index of the element for which to return the meta type.
 * @return The meta type of the i-th element of the list of arguments.
 */
template<typename Type>
[[nodiscard]] meta_type meta_arg(const meta_ctx &ctx, const stl::size_t index) noexcept {
    const auto &context = internal::meta_context::from(ctx);
    return {ctx, internal::meta_arg_node(context, Type{}, index)};
}

/**
 * @brief Returns the meta type of the i-th element of a list of arguments.
 * @tparam Type Type list of the actual types of arguments.
 * @param index The index of the element for which to return the meta type.
 * @return The meta type of the i-th element of the list of arguments.
 */
template<typename Type>
[[nodiscard]] meta_type meta_arg(const stl::size_t index) noexcept {
    return meta_arg<Type>(locator<meta_ctx>::value_or(), index);
}

/**
 * @brief Sets the value of a given variable.
 * @tparam Type Reflected type to which the variable is associated.
 * @tparam Data The actual variable to set.
 * @param instance An opaque instance of the underlying type, if required.
 * @param args Parameters to use to set the variable.
 * @return True in case of success, false otherwise.
 */
template<typename Type, auto Data>
[[nodiscard]] bool meta_setter([[maybe_unused]] meta_handle instance, [[maybe_unused]] meta_any *const args) {
    if constexpr(stl::is_member_function_pointer_v<decltype(Data)> || stl::is_function_v<stl::remove_reference_t<stl::remove_pointer_t<decltype(Data)>>>) {
        return static_cast<bool>(internal::meta_invoke<Type, as_void_t>(*instance.operator->(), Data, args, stl::make_index_sequence<meta_function_helper_t<Type, decltype(Data)>::args_type::size>{}));
    } else if constexpr(stl::is_member_object_pointer_v<decltype(Data)>) {
        using data_type = stl::remove_reference_t<typename meta_function_helper_t<Type, decltype(Data)>::return_type>;

        if constexpr(!stl::is_array_v<data_type> && !stl::is_const_v<data_type>) {
            if(auto *const clazz = instance->try_cast<Type>(); clazz && args->allow_cast<data_type>()) {
                stl::invoke(Data, *clazz) = args->cast<data_type>();
                return true;
            }
        }

        return false;
    } else if constexpr(stl::is_pointer_v<decltype(Data)>) {
        using data_type = stl::remove_reference_t<decltype(*Data)>;

        if constexpr(!stl::is_array_v<data_type> && !stl::is_const_v<data_type>) {
            if(args->allow_cast<data_type>()) {
                *Data = args->cast<data_type>();
                return true;
            }
        }

        return false;
    } else {
        return false;
    }
}

/**
 * @brief Sets the value of a given variable.
 * @tparam Type Reflected type to which the variable is associated.
 * @tparam Data The actual variable to set.
 * @param instance An opaque instance of the underlying type, if required.
 * @param value Parameter to use to set the variable.
 * @return True in case of success, false otherwise.
 */
template<typename Type, auto Data>
[[nodiscard]] bool meta_setter(meta_handle instance, meta_any value) {
    return meta_setter<Type, Data>(*instance.operator->(), &value);
}

/**
 * @brief Gets the value of a given variable.
 * @tparam Type Reflected type to which the variable is associated.
 * @tparam Data The actual variable to get.
 * @tparam Policy Optional policy (no policy set by default).
 * @param instance An opaque instance of the underlying type, if required.
 * @param args Parameters to use to set the variable.
 * @return A meta any containing the value of the underlying variable.
 */
template<typename Type, auto Data, meta_policy Policy = as_value_t>
[[nodiscard]] meta_any meta_getter(meta_handle instance, [[maybe_unused]] meta_any *const args) {
    if constexpr(stl::is_member_function_pointer_v<decltype(Data)> || stl::is_function_v<stl::remove_reference_t<stl::remove_pointer_t<decltype(Data)>>>) {
        return internal::meta_invoke<Type, Policy>(*instance.operator->(), Data, args, stl::make_index_sequence<meta_function_helper_t<Type, decltype(Data)>::args_type::size>{});
    } else if constexpr(stl::is_member_object_pointer_v<decltype(Data)>) {
        if constexpr(!stl::is_array_v<stl::remove_cvref_t<stl::invoke_result_t<decltype(Data), Type &>>>) {
            if(auto *clazz = instance->try_cast<Type>(); clazz) {
                return meta_dispatch<Policy>(instance->context(), stl::invoke(Data, *clazz));
            } else if(auto *fallback = instance->try_cast<const Type>(); fallback) {
                return meta_dispatch<Policy>(instance->context(), stl::invoke(Data, *fallback));
            }
        }

        return meta_any{meta_ctx_arg, instance->context()};
    } else if constexpr(stl::is_pointer_v<decltype(Data)>) {
        if constexpr(stl::is_array_v<stl::remove_pointer_t<decltype(Data)>>) {
            return meta_any{meta_ctx_arg, instance->context()};
        } else {
            return meta_dispatch<Policy>(instance->context(), *Data);
        }
    } else {
        return meta_dispatch<Policy>(instance->context(), Data);
    }
}

/**
 * @brief Gets the value of a given variable.
 * @tparam Type Reflected type to which the variable is associated.
 * @tparam Data The actual variable to get.
 * @tparam Policy Optional policy (no policy set by default).
 * @param instance An opaque instance of the underlying type, if required.
 * @return A meta any containing the value of the underlying variable.
 */
template<typename Type, auto Data, meta_policy Policy = as_value_t>
[[nodiscard]] meta_any meta_getter(meta_handle instance) {
    return meta_getter<Type, Data, Policy>(*instance.operator->(), nullptr);
}

/**
 * @brief Tries to _invoke_ an object given a list of erased parameters.
 * @tparam Type Reflected type to which the object to _invoke_ is associated.
 * @tparam Policy Optional policy (no policy set by default).
 * @tparam Candidate The type of the actual object to _invoke_.
 * @param instance An opaque instance of the underlying type, if required.
 * @param candidate The actual object to _invoke_.
 * @param args Parameters to use to _invoke_ the object.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, meta_policy Policy = as_value_t, typename Candidate>
[[nodiscard]] meta_any meta_invoke(meta_handle instance, Candidate &&candidate, meta_any *const args) {
    return internal::meta_invoke<Type, Policy>(*instance.operator->(), stl::forward<Candidate>(candidate), args, stl::make_index_sequence<meta_function_helper_t<Type, stl::remove_reference_t<Candidate>>::args_type::size>{});
}

/**
 * @brief Tries to invoke a function given a list of erased parameters.
 * @tparam Type Reflected type to which the function is associated.
 * @tparam Candidate The actual function to invoke.
 * @tparam Policy Optional policy (no policy set by default).
 * @param instance An opaque instance of the underlying type, if required.
 * @param args Parameters to use to invoke the function.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, auto Candidate, meta_policy Policy = as_value_t>
[[nodiscard]] meta_any meta_invoke(meta_handle instance, meta_any *const args) {
    return internal::meta_invoke<Type, Policy>(*instance.operator->(), Candidate, args, stl::make_index_sequence<meta_function_helper_t<Type, stl::remove_reference_t<decltype(Candidate)>>::args_type::size>{});
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 *
 * @warning
 * The context provided is used only for the return type.<br/>
 * It's up to the caller to bind the arguments to the right context(s).
 *
 * @tparam Type Actual type of the instance to construct.
 * @tparam Args Types of arguments expected.
 * @param ctx The context from which to search for meta types.
 * @param args Parameters to use to construct the instance.
 * @return A meta any containing the new instance, if any.
 */
template<typename Type, typename... Args>
[[nodiscard]] meta_any meta_construct(const meta_ctx &ctx, meta_any *const args) {
    return internal::meta_construct<Type, Args...>(ctx, args, stl::index_sequence_for<Args...>{});
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 * @tparam Type Actual type of the instance to construct.
 * @tparam Args Types of arguments expected.
 * @param args Parameters to use to construct the instance.
 * @return A meta any containing the new instance, if any.
 */
template<typename Type, typename... Args>
[[nodiscard]] meta_any meta_construct(meta_any *const args) {
    return meta_construct<Type, Args...>(locator<meta_ctx>::value_or(), args);
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 *
 * @warning
 * The context provided is used only for the return type.<br/>
 * It's up to the caller to bind the arguments to the right context(s).
 *
 * @tparam Type Reflected type to which the object to _invoke_ is associated.
 * @tparam Policy Optional policy (no policy set by default).
 * @tparam Candidate The type of the actual object to _invoke_.
 * @param ctx The context from which to search for meta types.
 * @param candidate The actual object to _invoke_.
 * @param args Parameters to use to _invoke_ the object.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, typename Policy = as_value_t, typename Candidate>
[[nodiscard]] meta_any meta_construct(const meta_ctx &ctx, Candidate &&candidate, meta_any *const args) {
    if constexpr(meta_function_helper_t<Type, Candidate>::is_static || stl::is_class_v<stl::remove_cvref_t<Candidate>>) {
        meta_any placeholder{meta_ctx_arg, ctx};
        return internal::meta_invoke<Type, Policy>(placeholder, stl::forward<Candidate>(candidate), args, stl::make_index_sequence<meta_function_helper_t<Type, stl::remove_reference_t<Candidate>>::args_type::size>{});
    } else {
        // NOLINTNEXTLINE(cppcoreguidelines-pro-bounds-pointer-arithmetic) - waiting for C++20 (and stl::span)
        return internal::meta_invoke<Type, Policy>(*args, stl::forward<Candidate>(candidate), args + 1u, stl::make_index_sequence<meta_function_helper_t<Type, stl::remove_reference_t<Candidate>>::args_type::size>{});
    }
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 * @tparam Type Reflected type to which the object to _invoke_ is associated.
 * @tparam Policy Optional policy (no policy set by default).
 * @tparam Candidate The type of the actual object to _invoke_.
 * @param candidate The actual object to _invoke_.
 * @param args Parameters to use to _invoke_ the object.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, meta_policy Policy = as_value_t, typename Candidate>
[[nodiscard]] meta_any meta_construct(Candidate &&candidate, meta_any *const args) {
    return meta_construct<Type, Policy>(locator<meta_ctx>::value_or(), stl::forward<Candidate>(candidate), args);
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 *
 * @warning
 * The context provided is used only for the return type.<br/>
 * It's up to the caller to bind the arguments to the right context(s).
 *
 * @tparam Type Reflected type to which the function is associated.
 * @tparam Candidate The actual function to invoke.
 * @tparam Policy Optional policy (no policy set by default).
 * @param ctx The context from which to search for meta types.
 * @param args Parameters to use to invoke the function.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, auto Candidate, meta_policy Policy = as_value_t>
[[nodiscard]] meta_any meta_construct(const meta_ctx &ctx, meta_any *const args) {
    return meta_construct<Type, Policy>(ctx, Candidate, args);
}

/**
 * @brief Tries to construct an instance given a list of erased parameters.
 * @tparam Type Reflected type to which the function is associated.
 * @tparam Candidate The actual function to invoke.
 * @tparam Policy Optional policy (no policy set by default).
 * @param args Parameters to use to invoke the function.
 * @return A meta any containing the returned value, if any.
 */
template<typename Type, auto Candidate, meta_policy Policy = as_value_t>
[[nodiscard]] meta_any meta_construct(meta_any *const args) {
    return meta_construct<Type, Candidate, Policy>(locator<meta_ctx>::value_or(), args);
}

} // namespace entt

#endif
