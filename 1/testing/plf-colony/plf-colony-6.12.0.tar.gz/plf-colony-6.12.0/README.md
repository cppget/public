PLF Colony - Build2 Package
===========================

This repository is only setting up the library and it's tests to be published in https://cppget.org through [Build2](http://build2.org).
We use a git submodule targetting a specific version of the library for each package version.

PLF Colony
----------

 - PLF Colony: https://plflib.org/colony.htm
    - Also contain the change history at the end of the page.
 - Repository: https://github.com/mattreecebentley/plf_colony/

Package Maintainers
-------------------

- A. Joël Lamotte - mjklaim@gmail.com