// file      : cxx/serializer/enumeration/boolean.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#ifndef BOOLEAN_HXX
#define BOOLEAN_HXX

enum boolean
{
  FALSE,
  TRUE
};

#endif // BOOLEAN_HXX
