// file      : cxx/serializer/generated-driver/test-simpl.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test-simpl.hxx"

namespace test
{
  // type_simpl
  //

  void type_simpl::
  pre ()
  {
  }

  int type_simpl::
  value ()
  {
    return 123;
  }

  void type_simpl::
  post ()
  {
  }
}
