// file      : cxx/parser/enumeration/gender.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#ifndef GENDER_HXX
#define GENDER_HXX

enum gender
{
  male,
  female
};

#endif // GENDER_HXX
