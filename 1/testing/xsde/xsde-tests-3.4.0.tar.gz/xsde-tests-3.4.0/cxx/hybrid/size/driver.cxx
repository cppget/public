// file      : cxx/hybrid/size/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test.hxx"
#include "test-pimpl.hxx"
#include "test-simpl.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
