# xsde-tests - XSD/e tests

This package contains tests for `xsde`, the XML Schema to C++ data binding
compiler for mobile and embedded systems.
