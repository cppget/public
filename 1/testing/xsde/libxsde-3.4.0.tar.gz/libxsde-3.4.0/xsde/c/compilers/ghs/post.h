/* file      : xsde/c/compilers/ghs/post.h
 * license   : GNU GPL v2 + exceptions; see accompanying LICENSE file
 */

#ifdef __EDG__
#  pragma ghs endnowarning
#endif
