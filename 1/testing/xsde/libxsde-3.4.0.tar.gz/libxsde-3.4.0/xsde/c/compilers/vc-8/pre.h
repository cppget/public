/* file      : xsde/c/compilers/vc-8/pre.h
 * license   : GNU GPL v2 + exceptions; see accompanying LICENSE file
 */

/* Push warning state. */
#pragma warning (push, 3)

/* Disabled warnings. */
#pragma warning (disable:4996) /* deprecated function */
