/* file      : xsde/c/compilers/vc-8/post.h
 * license   : GNU GPL v2 + exceptions; see accompanying LICENSE file
 */

#pragma warning (pop)
