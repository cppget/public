// file      : xsde/cxx/hybrid/any-type-simpl.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <xsde/cxx/hybrid/any-type-simpl.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace hybrid
    {
      void any_type_simpl::
      pre (const any_type&)
      {
      }
    }
  }
}
