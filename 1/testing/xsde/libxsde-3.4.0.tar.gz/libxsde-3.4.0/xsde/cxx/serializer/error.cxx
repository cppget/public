// file      : xsde/cxx/serializer/error.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <xsde/cxx/serializer/error.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace serializer
    {
      void error::
      true_ ()
      {
      }
    }
  }
}
