// file      : xsde/cxx/parser/context.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <xsde/cxx/config.hxx>

#include <xsde/cxx/parser/context.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace parser
    {
    }
  }
}
