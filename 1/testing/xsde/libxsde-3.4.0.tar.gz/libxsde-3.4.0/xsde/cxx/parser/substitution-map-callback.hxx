// file      : xsde/cxx/parser/substitution-map-callback.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#ifndef XSDE_CXX_PARSER_SUBSTITUTION_MAP_CALLBACK_HXX
#define XSDE_CXX_PARSER_SUBSTITUTION_MAP_CALLBACK_HXX

#include <xsde/cxx/ro-string.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace parser
    {
      void
      parser_smap_callback (
        bool (*callback) (
          const ro_string& root_ns,
          const ro_string& root_name,
          const ro_string& member_ns,
          const ro_string& member_name,
          const char*& type));
    }
  }
}

#endif  // XSDE_CXX_PARSER_SUBSTITUTION_MAP_CALLBACK_HXX
