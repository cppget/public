// file      : xsde/cxx/parser/error.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <xsde/cxx/parser/error.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace parser
    {
      void error::
      true_ ()
      {
      }
    }
  }
}
