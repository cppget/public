// file      : xsde/cxx/compilers/ghs/post.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#ifdef __EDG__
#  pragma ghs endnowarning
#endif
