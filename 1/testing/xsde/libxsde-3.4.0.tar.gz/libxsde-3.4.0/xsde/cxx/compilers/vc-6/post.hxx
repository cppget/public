// file      : xsde/cxx/compilers/vc-6/post.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#pragma warning (pop)
