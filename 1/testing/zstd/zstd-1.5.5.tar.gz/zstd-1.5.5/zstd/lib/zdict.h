/* Thunk that includes real zdict.h from libzstd. */
#include <zdict.h>
