/* Thunk that includes real zstd.h from libzstd. */
#include <zstd.h>
