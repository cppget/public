/* Thunk that includes real zstd_errors.h from libzstd. */
#include <zstd_errors.h>
