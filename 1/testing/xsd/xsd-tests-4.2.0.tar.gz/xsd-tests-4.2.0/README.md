# xsd-tests - tests for XSD compiler

This package contains tests for `xsd`, the XML Schema to C++ data binding
compiler.
