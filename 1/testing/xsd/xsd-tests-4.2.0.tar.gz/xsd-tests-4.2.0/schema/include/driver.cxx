// file      : schema/include/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "includer.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
