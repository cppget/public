// file      : schema/forward/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "test.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
