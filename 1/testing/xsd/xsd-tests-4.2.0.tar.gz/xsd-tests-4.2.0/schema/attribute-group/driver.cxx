// file      : schema/attribute-group/driver.cxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include "global.hxx"

#undef NDEBUG
#include <cassert>

int
main (int, char*[])
{
}
