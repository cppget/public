# libxsd-tests - tests for XSD runtime library

This package contains tests for `libxsd`, the XML Schema to C++ data binding
compiler's runtime library.
